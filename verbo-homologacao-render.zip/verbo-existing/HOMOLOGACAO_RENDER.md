# Homologação do Verbo no Render

**Arquitetura:** Static Site + Web Service Docker + Render Postgres  
**Ambiente:** homologação com integrações sandbox

## Recursos definidos no Blueprint

O arquivo `render.yaml` cria:

1. `verbo-web-hml` — frontend React estático.
2. `verbo-api-hml` — backend Express em Docker.
3. `verbo-db-hml` — PostgreSQL gerenciado.

O frontend recebe rewrite `/* → /index.html` para o React Router. O backend usa `/api/ready` como health check e recebe a conexão interna do PostgreSQL pelo Blueprint.

## Pré-requisito: repositório Git

O Render precisa acessar o projeto em GitHub, GitLab ou Bitbucket.

Antes de enviar:

- Não adicione `.env`.
- Não adicione chaves ou tokens.
- Confirme que `node_modules`, `dist` e logs não estão versionados.
- Mantenha `render.yaml` na raiz.
- Mantenha `.github/workflows/ci.yml`.

## Criar o Blueprint

1. Entre no Render.
2. Selecione **New → Blueprint**.
3. Conecte o repositório.
4. Confirme que o Render encontrou `render.yaml`.
5. Informe os segredos solicitados.
6. Revise nomes e região antes de criar.

Se os nomes `verbo-api-hml` ou `verbo-web-hml` já estiverem ocupados no workspace, altere os nomes e também:

- `FRONTEND_URL` no backend.
- `VITE_API_URL` no frontend.

O frontend precisa ser reconstruído sempre que a URL da API mudar, pois variáveis `VITE_*` são incorporadas no build.

## Segredos obrigatórios

### Inteligência artificial

Escolha apenas um valor para `AI_PROVIDER`:

- `anthropic`
- `openai`
- `gemini`

Depois, preencha a chave correspondente:

- `ANTHROPIC_API_KEY`
- `OPENAI_API_KEY`
- `GEMINI_API_KEY`

As outras chaves podem permanecer vazias. O Blueprint usa `AI_FALLBACK_TO_LOCAL=false` para que erros de homologação sejam visíveis.

### API.Bible

Preencha:

- `BIBLE_API_KEY`
- `BIBLE_ID_ARC`
- `BIBLE_ID_ARA`
- `BIBLE_ID_NVI`
- `BIBLE_ID_NVT`
- `BIBLE_ID_NTLH`

Os IDs devem vir da lista de Bíblias disponível para a chave. Não copie IDs de outra conta sem confirmar licença e acesso.

Se alguma tradução não estiver liberada, há duas opções:

1. Remover temporariamente essa opção do onboarding; ou
2. Usar `BIBLE_FALLBACK_TO_LOCAL=true` durante a configuração inicial.

### Resend

Preencha:

- `RESEND_API_KEY`
- `EMAIL_FROM`

Exemplo:

```text
Verbo <nao-responda@seudominio.com>
```

O domínio do remetente precisa estar validado no provedor para envio real.

### Mercado Pago sandbox

Preencha inicialmente:

- `MERCADO_PAGO_ACCESS_TOKEN` de teste.
- `MERCADO_PAGO_WEBHOOK_SECRET` temporário.

Depois do primeiro deploy do backend:

1. Abra a aplicação de teste no painel do Mercado Pago.
2. Cadastre o webhook:

```text
https://verbo-api-hml.onrender.com/api/webhooks/mercadopago
```

3. Ative `subscription_preapproval`.
4. Copie o segredo de webhook gerado.
5. Substitua `MERCADO_PAGO_WEBHOOK_SECRET` no Render.
6. Faça novo deploy do backend.

Use somente credenciais de teste na homologação.

## Primeiro deploy

O contêiner do backend executa automaticamente:

```text
prisma migrate deploy
prisma:seed
node dist/server.js
```

O seed é idempotente. O health check só retorna sucesso quando o backend consegue consultar o PostgreSQL.

## Verificação de prontidão

Abra:

```text
https://verbo-api-hml.onrender.com/api/ready
```

O resultado esperado deve indicar:

- `database: true`
- `ai.configured: true`
- `bible.configured: true`
- `billing.configured: true`
- `email.configured: true`

O endpoint não expõe chaves.

## Smoke test da homologação

O teste cria uma conta descartável, faz duas gerações externas e exclui a conta ao terminar:

```bash
cd backend
STAGING_API_URL='https://verbo-api-hml.onrender.com/api' npm run test:staging
```

O teste valida:

- PostgreSQL.
- API.Bible real.
- IA externa.
- Persistência.
- Regras de plano.
- Mercado Pago configurado.
- Resend configurado.
- Exclusão da conta de teste.

Ele não inicia checkout nem realiza cobrança.

## CI/CD

O workflow `.github/workflows/ci.yml` executa:

- Lint, typecheck, testes e build do backend.
- Lint, typecheck e build do frontend.
- Auditoria npm.
- Smoke test em PostgreSQL 16 real.

O Blueprint usa `autoDeployTrigger: checksPass`, portanto o Render só deve publicar commits aprovados pelos checks.

## Limitações do plano gratuito

- O PostgreSQL gratuito do Render pode expirar; use somente para uma homologação temporária.
- Serviços gratuitos podem hibernar e apresentar latência na primeira requisição.
- Webhooks e testes de assinatura são mais confiáveis em uma instância que não hiberna.
- Antes do beta com usuários externos, migre banco e backend para planos persistentes.

## Checklist de aprovação

- [ ] CI verde no repositório.
- [ ] Blueprint criado sem erro.
- [ ] Backend `/api/ready` com todas as integrações configuradas.
- [ ] Frontend abre por HTTPS.
- [ ] Cadastro e onboarding concluídos.
- [ ] E-mail de recuperação recebido.
- [ ] Devocional usando `api-bible` e IA externa.
- [ ] PNG e PDF inspecionados manualmente.
- [ ] Mercado Pago sandbox aprovado.
- [ ] Webhook aprovado, pausado e cancelado testados.
- [ ] Exclusão da conta confirmada.
- [ ] Logs sem segredos.
- [ ] Backup ou política de recriação do banco definida.
