/**
 * Sistema de Design — Verbo
 * Conceito: "sala de leitura noturna com páginas iluminadas" — a superfície
 * principal do app é um azul-noite profundo (não o bege genérico), e o
 * "cartão de versículo" em tom pergaminho é o elemento assinatura,
 * usado sempre que um texto bíblico aparece (devocional, post, plano de leitura).
 */
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        night: {
          DEFAULT: '#12162A',
          soft: '#1B2140',
          softer: '#232B52',
        },
        paper: {
          DEFAULT: '#F5EEDC',
          dim: '#EAE0C6',
        },
        gold: {
          DEFAULT: '#C9A24B',
          soft: '#E1C381',
        },
        sage: {
          DEFAULT: '#6F8F72',
          soft: '#A9C2AB',
        },
        rose: {
          DEFAULT: '#B5534A',
          soft: '#D89890',
        },
        ink: '#211D16',
        mist: '#AEB4CE',
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        body: ['"Inter"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      boxShadow: {
        card: '0 12px 32px -12px rgba(9, 12, 26, 0.45)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
    },
  },
  plugins: [],
};
