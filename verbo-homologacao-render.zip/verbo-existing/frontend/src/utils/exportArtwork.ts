import type { Post } from '../api/post.api';

export async function renderArtworkPng(node: HTMLElement, post: Post) {
  const { toPng } = await import('html-to-image');
  await document.fonts.ready;
  const height = post.format === 'FEED' ? 1080 : 1920;
  return toPng(node, {
    cacheBust: true,
    backgroundColor: post.bgColor,
    canvasWidth: 1080,
    canvasHeight: height,
    pixelRatio: 1,
  });
}

export async function downloadArtworkPng(node: HTMLElement, post: Post) {
  const dataUrl = await renderArtworkPng(node, post);
  downloadDataUrl(dataUrl, `${slug(post.title)}-${post.format.toLowerCase()}.png`);
}

export async function downloadArtworkPdf(node: HTMLElement, post: Post) {
  const [{ jsPDF }, dataUrl] = await Promise.all([
    import('jspdf'),
    renderArtworkPng(node, post),
  ]);
  const height = post.format === 'FEED' ? 1080 : 1920;
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [1080, height], hotfixes: ['px_scaling'] });
  pdf.addImage(dataUrl, 'PNG', 0, 0, 1080, height, undefined, 'FAST');
  pdf.save(`${slug(post.title)}-${post.format.toLowerCase()}.pdf`);
}

function downloadDataUrl(dataUrl: string, filename: string) {
  const anchor = document.createElement('a');
  anchor.download = filename;
  anchor.href = dataUrl;
  anchor.click();
}
function slug(value: string) {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}
