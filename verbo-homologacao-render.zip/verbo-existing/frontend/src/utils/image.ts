export async function prepareImage(file: File, options: { maxDimension: number; maxBytes: number; transparent?: boolean }) {
  if (!file.type.startsWith('image/')) throw new Error('Selecione um arquivo de imagem.');
  if (file.size > 10 * 1024 * 1024) throw new Error('A imagem original deve ter no máximo 10 MB.');

  const source = await readAsDataUrl(file);
  const image = await loadImage(source);
  const ratio = Math.min(1, options.maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
  const width = Math.max(1, Math.round(image.naturalWidth * ratio));
  const height = Math.max(1, Math.round(image.naturalHeight * ratio));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Seu navegador não conseguiu processar a imagem.');
  if (!options.transparent) {
    context.fillStyle = '#12162A';
    context.fillRect(0, 0, width, height);
  }
  context.drawImage(image, 0, 0, width, height);

  const mime = options.transparent ? 'image/png' : 'image/jpeg';
  let quality = 0.88;
  let result = canvas.toDataURL(mime, quality);
  while (dataUrlBytes(result) > options.maxBytes && quality > 0.45 && !options.transparent) {
    quality -= 0.1;
    result = canvas.toDataURL(mime, quality);
  }
  if (dataUrlBytes(result) > options.maxBytes) {
    throw new Error(`A imagem processada excede ${Math.round(options.maxBytes / 1024)} KB. Escolha uma imagem mais simples.`);
  }
  return result;
}

function readAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Não foi possível ler o arquivo.'));
    reader.readAsDataURL(file);
  });
}
function loadImage(source: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Formato de imagem não suportado.'));
    image.src = source;
  });
}
function dataUrlBytes(value: string) {
  const base64 = value.split(',')[1] ?? '';
  return Math.ceil((base64.length * 3) / 4);
}
