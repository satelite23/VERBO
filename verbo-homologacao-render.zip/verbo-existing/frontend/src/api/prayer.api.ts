import { api } from './client';

export interface Prayer {
  id: string;
  title: string;
  description?: string | null;
  prayDate: string;
  isAnswered: boolean;
  createdAt: string;
}

export async function listPrayers(month?: number, year?: number) {
  const params = month && year ? { month, year } : undefined;
  const { data } = await api.get<{ data: { prayers: Prayer[] } }>('/prayers', { params });
  return data.data.prayers;
}

export async function createPrayer(payload: { title: string; description?: string; prayDate?: string }) {
  const { data } = await api.post<{ data: { prayer: Prayer } }>('/prayers', payload);
  return data.data.prayer;
}

export async function updatePrayer(id: string, payload: Partial<Prayer>) {
  const { data } = await api.patch<{ data: { prayer: Prayer } }>(`/prayers/${id}`, payload);
  return data.data.prayer;
}

export async function deletePrayer(id: string) {
  await api.delete(`/prayers/${id}`);
}
