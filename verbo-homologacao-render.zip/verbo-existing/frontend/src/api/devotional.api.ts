import { api } from './client';

export interface Devotional {
  id: string;
  title: string;
  theme: string;
  verseRef: string;
  verseText: string;
  bibleVersion: string;
  bibleSource: string;
  bibleCopyright?: string | null;
  aiProvider: string;
  aiModel: string;
  promptVersion: string;
  reflection: string;
  prayer: string;
  question: string;
  createdAt: string;
}

export async function listThemes() {
  const { data } = await api.get<{ data: { themes: string[] } }>('/devotionals/themes');
  return data.data.themes;
}

export async function generateDevotional(theme: string) {
  const { data } = await api.post<{ data: { devotional: Devotional } }>('/devotionals/generate', { theme });
  return data.data.devotional;
}

export async function updateDevotional(id: string, payload: Partial<Pick<Devotional, 'title' | 'verseRef' | 'verseText' | 'reflection' | 'prayer' | 'question'>>) {
  const { data } = await api.patch<{ data: { devotional: Devotional } }>(`/devotionals/${id}`, payload);
  return data.data.devotional;
}

export async function listDevotionals() {
  const { data } = await api.get<{ data: { devotionals: Devotional[] } }>('/devotionals');
  return data.data.devotionals;
}

export async function deleteDevotional(id: string) {
  await api.delete(`/devotionals/${id}`);
}
