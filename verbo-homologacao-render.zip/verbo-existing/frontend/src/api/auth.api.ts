import { api } from './client';

export type ProfileType = 'PERSONAL' | 'CHURCH' | 'CREATOR' | 'MINISTRY';
export type BibleVersion = 'ARC' | 'ARA' | 'NVI' | 'NVT' | 'NTLH';
export type UserGoal = 'DEVOTIONALS' | 'POSTS' | 'PRAYER' | 'READING';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'USER' | 'CHURCH_ADMIN';
  profileType: ProfileType;
  churchName?: string | null;
  bibleVersion: BibleVersion;
  goals: UserGoal[];
  onboardingCompleted: boolean;
  createdAt: string;
}

export interface AuthResponse {
  data: { user: User; token: string };
}

export interface ProfileUpdate {
  name?: string;
  churchName?: string | null;
  profileType?: ProfileType;
  bibleVersion?: BibleVersion;
  goals?: UserGoal[];
  onboardingCompleted?: boolean;
}

export async function registerRequest(payload: {
  name: string;
  email: string;
  password: string;
  churchName?: string;
}) {
  const { data } = await api.post<AuthResponse>('/auth/register', payload);
  return data.data;
}

export async function loginRequest(payload: { email: string; password: string }) {
  const { data } = await api.post<AuthResponse>('/auth/login', payload);
  return data.data;
}

export async function meRequest() {
  const { data } = await api.get<{ data: { user: User } }>('/auth/me');
  return data.data.user;
}

export async function updateMeRequest(payload: ProfileUpdate) {
  const { data } = await api.patch<{ data: { user: User } }>('/auth/me', payload);
  return data.data.user;
}

export async function forgotPasswordRequest(email: string) {
  const { data } = await api.post<{
    message: string;
    data?: { developmentResetUrl?: string };
  }>('/auth/forgot-password', { email });
  return data;
}

export async function resetPasswordRequest(token: string, password: string) {
  const { data } = await api.post<{ message: string }>('/auth/reset-password', { token, password });
  return data;
}

export async function deleteAccountRequest(password: string) {
  await api.delete('/auth/me', { data: { password } });
}
