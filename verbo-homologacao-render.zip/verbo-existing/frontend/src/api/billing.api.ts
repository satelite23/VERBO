import { api } from './client';

export type EffectivePlan = 'FREE' | 'PRO' | 'CHURCH';
export type BillingCycle = 'MONTHLY' | 'ANNUAL';

export interface PlanEntitlements {
  name: string;
  monthlyGenerationLimit: number;
  templates: Array<'illuminated' | 'minimal' | 'editorial' | 'frame'>;
  watermark: boolean;
  customLogo: boolean;
  monthlyPrice: number;
  annualPrice: number;
}

export interface BillingStatus {
  plan: EffectivePlan;
  entitlements: PlanEntitlements;
  usage: { used: number; limit: number; remaining: number; monthStart: string; plan: EffectivePlan };
  catalog: Record<EffectivePlan, PlanEntitlements>;
  billingConfigured: boolean;
  subscription: null | {
    id: string;
    plan: 'PRO' | 'CHURCH';
    billingCycle: BillingCycle;
    status: 'PENDING' | 'ACTIVE' | 'PAUSED' | 'CANCELLED' | 'EXPIRED';
    amount: number;
    currency: string;
    currentPeriodStart?: string | null;
    currentPeriodEnd?: string | null;
    checkoutUrl?: string | null;
    createdAt: string;
    updatedAt: string;
  };
}

export async function getBillingStatus() {
  const { data } = await api.get<{ data: BillingStatus }>('/billing/status');
  return data.data;
}

export async function createCheckout(plan: 'PRO' | 'CHURCH', cycle: BillingCycle) {
  const { data } = await api.post<{ data: { checkoutUrl: string; subscriptionId: string } }>('/billing/checkout', { plan, cycle });
  return data.data;
}

export async function manageSubscription(action: 'pause' | 'resume' | 'cancel') {
  const { data } = await api.post<{ message: string; data: { subscription: BillingStatus['subscription'] } }>('/billing/manage', { action });
  return data;
}
