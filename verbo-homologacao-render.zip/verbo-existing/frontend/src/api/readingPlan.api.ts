import { api } from './client';

export interface ReadingPlanDay {
  id: string;
  dayNumber: number;
  reference: string;
  description?: string | null;
}

export interface ReadingPlan {
  id: string;
  name: string;
  description: string;
  durationDays: number;
  days?: ReadingPlanDay[];
  _count?: { days: number };
}

export interface PlanEnrollment {
  id: string;
  planId: string;
  currentDay: number;
  completedDays: number;
  streak: number;
  lastCheckIn?: string | null;
  startedAt: string;
  completedAt?: string | null;
  plan: ReadingPlan;
  checkIns?: Array<{ dayNumber: number; localDate: string; completedAt: string }>;
}

export async function listPlans() {
  const { data } = await api.get<{ data: { plans: ReadingPlan[] } }>('/reading-plans');
  return data.data.plans;
}

export async function getPlan(id: string) {
  const { data } = await api.get<{ data: { plan: ReadingPlan } }>(`/reading-plans/${id}`);
  return data.data.plan;
}

export async function myEnrollments() {
  const { data } = await api.get<{ data: { enrollments: PlanEnrollment[] } }>('/reading-plans/mine');
  return data.data.enrollments;
}

export async function enrollInPlan(planId: string) {
  const { data } = await api.post<{ data: { enrollment: PlanEnrollment } }>('/reading-plans/enroll', { planId });
  return data.data.enrollment;
}

export async function checkInPlan(planId: string) {
  const { data } = await api.post<{ data: { enrollment: PlanEnrollment } }>('/reading-plans/checkin', { planId });
  return data.data.enrollment;
}
