import { api } from './client';

export type PostFormat = 'FEED' | 'STORY' | 'WHATSAPP';

export interface Post {
  id: string;
  title: string;
  theme: string;
  verseRef: string;
  verseText: string;
  bibleVersion: string;
  bibleSource: string;
  bibleCopyright?: string | null;
  aiProvider: string;
  aiModel: string;
  promptVersion: string;
  caption: string;
  format: PostFormat;
  templateId: 'illuminated' | 'minimal' | 'editorial' | 'frame';
  bgColor: string;
  accentColor: string;
  imageUrl?: string | null;
  logoUrl?: string | null;
  fontFamily: 'fraunces' | 'inter' | 'mono';
  textAlign: 'left' | 'center' | 'right';
  overlayOpacity: number;
  fontScale: number;
  createdAt: string;
}

export async function generatePost(payload: {
  theme: string;
  format?: PostFormat;
  templateId?: string;
  bgColor?: string;
  accentColor?: string;
  fontFamily?: Post['fontFamily'];
  textAlign?: Post['textAlign'];
  overlayOpacity?: number;
  fontScale?: number;
}) {
  const { data } = await api.post<{ data: { post: Post } }>('/posts/generate', payload);
  return data.data.post;
}

export async function listPosts() {
  const { data } = await api.get<{ data: { posts: Post[] } }>('/posts');
  return data.data.posts;
}

export async function updatePost(id: string, payload: Partial<Post>) {
  const { data } = await api.patch<{ data: { post: Post } }>(`/posts/${id}`, payload);
  return data.data.post;
}

export async function deletePost(id: string) {
  await api.delete(`/posts/${id}`);
}
