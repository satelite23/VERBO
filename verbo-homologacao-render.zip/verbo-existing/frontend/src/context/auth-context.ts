import { createContext } from 'react';
import type { ProfileUpdate, User } from '../api/auth.api';

export interface AuthContextValue {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (payload: { name: string; email: string; password: string; churchName?: string }) => Promise<User>;
  updateProfile: (payload: ProfileUpdate) => Promise<User>;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextValue | undefined>(undefined);
