import { ReactNode, useEffect, useState } from 'react';
import { loginRequest, meRequest, ProfileUpdate, registerRequest, updateMeRequest, User } from '../api/auth.api';
import { AuthContext } from './auth-context';

function readStoredSession(): { user: User | null; needsValidation: boolean } {
  const token = localStorage.getItem('verbo_token');
  const storedUser = localStorage.getItem('verbo_user');
  if (!token || !storedUser) return { user: null, needsValidation: false };

  try {
    return { user: JSON.parse(storedUser) as User, needsValidation: true };
  } catch {
    localStorage.removeItem('verbo_token');
    localStorage.removeItem('verbo_user');
    return { user: null, needsValidation: false };
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [initialSession] = useState(readStoredSession);
  const [user, setUser] = useState<User | null>(initialSession.user);
  const [isLoading, setIsLoading] = useState(initialSession.needsValidation);

  useEffect(() => {
    if (!initialSession.needsValidation) return;

    meRequest()
      .then((freshUser) => {
        setUser(freshUser);
        localStorage.setItem('verbo_user', JSON.stringify(freshUser));
      })
      .catch(() => {
        localStorage.removeItem('verbo_token');
        localStorage.removeItem('verbo_user');
        setUser(null);
      })
      .finally(() => setIsLoading(false));
  }, [initialSession.needsValidation]);

  async function login(email: string, password: string) {
    const { user: loggedUser, token } = await loginRequest({ email, password });
    localStorage.setItem('verbo_token', token);
    localStorage.setItem('verbo_user', JSON.stringify(loggedUser));
    setUser(loggedUser);
    return loggedUser;
  }

  async function register(payload: { name: string; email: string; password: string; churchName?: string }) {
    const { user: newUser, token } = await registerRequest(payload);
    localStorage.setItem('verbo_token', token);
    localStorage.setItem('verbo_user', JSON.stringify(newUser));
    setUser(newUser);
    return newUser;
  }

  async function updateProfile(payload: ProfileUpdate) {
    const updatedUser = await updateMeRequest(payload);
    localStorage.setItem('verbo_user', JSON.stringify(updatedUser));
    setUser(updatedUser);
    return updatedUser;
  }

  function logout() {
    localStorage.removeItem('verbo_token');
    localStorage.removeItem('verbo_user');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, updateProfile, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
