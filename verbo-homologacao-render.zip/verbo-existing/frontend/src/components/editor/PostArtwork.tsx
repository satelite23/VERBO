import { forwardRef } from 'react';
import type { Post } from '../../api/post.api';

export const PostArtwork = forwardRef<HTMLDivElement, { post: Post; className?: string; showWatermark?: boolean }>(
  function PostArtwork({ post, className = '', showWatermark = true }, ref) {
    const isStory = post.format === 'STORY' || post.format === 'WHATSAPP';
    const fontClass = post.fontFamily === 'inter' ? 'font-body' : post.fontFamily === 'mono' ? 'font-mono' : 'font-display';
    const alignClass = post.textAlign === 'left' ? 'text-left items-start' : post.textAlign === 'right' ? 'text-right items-end' : 'text-center items-center';
    const verseSize = Math.round((isStory ? 31 : 27) * (post.fontScale / 100));
    const hasImage = Boolean(post.imageUrl);

    return (
      <div
        ref={ref}
        className={`relative isolate overflow-hidden shrink-0 ${isStory ? 'aspect-[9/16]' : 'aspect-square'} ${className}`}
        style={{ width: 360, maxWidth: '100%', backgroundColor: post.bgColor }}
      >
        {post.imageUrl ? <img src={post.imageUrl} alt="" className="absolute inset-0 -z-20 h-full w-full object-cover" /> : null}
        {hasImage ? <div className="absolute inset-0 -z-10" style={{ backgroundColor: post.bgColor, opacity: post.overlayOpacity / 100 }} /> : null}
        {post.templateId === 'frame' ? <div className="absolute inset-5 border pointer-events-none" style={{ borderColor: post.accentColor }} /> : null}
        {post.templateId === 'editorial' ? <div className="absolute left-7 top-8 bottom-8 w-1" style={{ backgroundColor: post.accentColor }} /> : null}

        <div className={`h-full flex flex-col justify-center px-9 py-12 ${alignClass} ${post.templateId === 'editorial' ? 'pl-14' : ''}`}>
          {post.templateId === 'illuminated' ? (
            <div className={`relative w-full rounded-2xl bg-paper text-ink shadow-card px-7 py-8 ${alignClass}`}>
              <div className="absolute left-0 right-0 top-0 h-1 rounded-t-2xl" style={{ background: `linear-gradient(90deg, ${post.accentColor}, #E1C381, ${post.accentColor})` }} />
              <p className="font-mono text-[10px] uppercase tracking-[.14em] text-[#8A6A2B] mb-4">{post.verseRef}</p>
              <p className={`${fontClass} italic leading-[1.35]`} style={{ fontSize: verseSize }}>“{post.verseText}”</p>
            </div>
          ) : (
            <>
              <span className="font-display text-5xl leading-none mb-4" style={{ color: post.accentColor }}>“</span>
              <p className="font-mono text-[10px] uppercase tracking-[.16em] mb-5" style={{ color: post.accentColor }}>{post.verseRef}</p>
              <p className={`${fontClass} italic text-white leading-[1.35] drop-shadow-sm`} style={{ fontSize: verseSize }}>“{post.verseText}”</p>
              <div className="h-px w-16 mt-7" style={{ backgroundColor: post.accentColor }} />
            </>
          )}
        </div>

        <div className="absolute bottom-5 left-7 right-7 flex items-end justify-between gap-4">
          {post.logoUrl ? <img src={post.logoUrl} alt="Logo" className="max-w-[100px] max-h-10 object-contain object-left" /> : <span />}
          {showWatermark ? <span className={`font-display text-sm ${post.templateId === 'illuminated' ? 'text-paper/80 drop-shadow' : 'text-white/75'}`}>Verbo<span style={{ color: post.accentColor }}>.</span></span> : <span />}
        </div>
      </div>
    );
  },
);
