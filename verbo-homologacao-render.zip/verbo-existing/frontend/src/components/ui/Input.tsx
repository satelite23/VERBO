import { InputHTMLAttributes, forwardRef } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(({ label, error, id, className = '', ...rest }, ref) => {
  const inputId = id ?? label.toLowerCase().replace(/\s+/g, '-');

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={inputId} className="text-sm font-medium text-mist">
        {label}
      </label>
      <input id={inputId} ref={ref} className={`input-field ${className}`} {...rest} />
      {error ? <p className="text-sm text-rose-soft">{error}</p> : null}
    </div>
  );
});

Input.displayName = 'Input';
