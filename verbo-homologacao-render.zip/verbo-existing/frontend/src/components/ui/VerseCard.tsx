export function VerseCard({ reference, text }: { reference: string; text: string }) {
  return (
    <div className="verse-card">
      <p className="font-mono text-xs uppercase tracking-widest text-gold/80 mb-2">{reference}</p>
      <p className="font-display text-xl sm:text-2xl leading-snug italic">&ldquo;{text}&rdquo;</p>
    </div>
  );
}
