export function Topbar({ onMenuClick, title }: { onMenuClick: () => void; title: string }) {
  return (
    <header className="lg:hidden sticky top-0 z-20 flex items-center gap-3 bg-night/95 backdrop-blur border-b border-white/5 px-4 py-3">
      <button
        aria-label="Abrir menu"
        onClick={onMenuClick}
        className="p-2 -ml-2 text-paper hover:text-gold transition-colors"
      >
        <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path strokeLinecap="round" d="M4 7h16M4 12h16M4 17h16" />
        </svg>
      </button>
      <span className="font-display text-lg text-paper">{title}</span>
    </header>
  );
}
