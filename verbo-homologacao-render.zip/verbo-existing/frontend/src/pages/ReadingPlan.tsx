import { useEffect, useState } from 'react';
import { AppLayout } from '../components/layout/AppLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import {
  ReadingPlan,
  PlanEnrollment,
  checkInPlan,
  enrollInPlan,
  listPlans,
  myEnrollments,
} from '../api/readingPlan.api';
import { getApiErrorMessage } from '../hooks/useApiError';

export function ReadingPlanPage() {
  const [plans, setPlans] = useState<ReadingPlan[]>([]);
  const [enrollments, setEnrollments] = useState<PlanEnrollment[]>([]);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const [availablePlans, currentEnrollments] = await Promise.all([listPlans(), myEnrollments()]);
        if (!active) return;
        setPlans(availablePlans);
        setEnrollments(currentEnrollments);
      } catch (err) {
        if (active) setError(getApiErrorMessage(err, 'Não foi possível carregar os planos de leitura.'));
      } finally {
        if (active) setIsLoading(false);
      }
    }
    void load();
    return () => { active = false; };
  }, []);

  const enrollmentByPlan = new Map(enrollments.map((e) => [e.planId, e]));

  async function handleEnroll(planId: string) {
    setBusyId(planId);
    setError('');
    try {
      const enrollment = await enrollInPlan(planId);
      setEnrollments((prev) => [...prev.filter((e) => e.planId !== planId), enrollment]);
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível iniciar o plano.'));
    } finally {
      setBusyId(null);
    }
  }

  async function handleCheckIn(planId: string) {
    setBusyId(planId);
    setError('');
    try {
      const enrollment = await checkInPlan(planId);
      setEnrollments((prev) => prev.map((e) => (e.planId === planId ? enrollment : e)));
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível registrar a leitura de hoje.'));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <AppLayout title="Planos de Leitura">
      {error ? <p className="text-sm text-rose-soft mb-4" role="alert">{error}</p> : null}
      {isLoading ? (
        <Card className="text-center py-10"><p className="text-mist">Carregando planos de leitura...</p></Card>
      ) : null}

      {!isLoading ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {plans.map((plan) => {
          const enrollment = enrollmentByPlan.get(plan.id);
          const progressPct = enrollment
            ? Math.min(100, Math.round((enrollment.completedDays / plan.durationDays) * 100))
            : 0;
          const todayKey = new Intl.DateTimeFormat('en-CA', {
            timeZone: 'America/Sao_Paulo',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
          }).format(new Date());
          const readToday = enrollment?.checkIns?.some((checkIn) => checkIn.localDate === todayKey) ?? false;
          const todayReading = enrollment?.plan.days?.find((day) => day.dayNumber === enrollment.currentDay);

          return (
            <Card key={plan.id} className="flex flex-col">
              <h2 className="font-display text-lg text-paper">{plan.name}</h2>
              <p className="text-sm text-mist mt-1.5 flex-1">{plan.description}</p>
              <p className="text-xs font-mono text-gold/80 mt-3">{plan.durationDays} dias</p>

              {enrollment ? (
                <div className="mt-4">
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden mb-2">
                    <div className="h-full bg-gold rounded-full transition-all" style={{ width: `${progressPct}%` }} />
                  </div>
                  <div className="flex items-center justify-between text-xs text-mist mb-3">
                    <span>
                      {enrollment.completedDays} de {plan.durationDays} leituras concluídas
                    </span>
                    {enrollment.streak > 0 && <span className="text-gold">🔥 {enrollment.streak} dias seguidos</span>}
                  </div>

                  {!enrollment.completedAt && todayReading ? (
                    <div className="rounded-lg bg-white/5 border border-white/5 px-3 py-2.5 mb-3">
                      <p className="text-[10px] uppercase tracking-wider text-gold font-mono">Leitura de hoje · dia {enrollment.currentDay}</p>
                      <p className="text-sm text-paper mt-1">{todayReading.reference}</p>
                      {todayReading.description ? <p className="text-xs text-mist mt-0.5">{todayReading.description}</p> : null}
                    </div>
                  ) : null}

                  {enrollment.completedAt ? (
                    <p className="text-sm text-sage text-center py-2">✓ Plano concluído</p>
                  ) : (
                    <Button
                      onClick={() => handleCheckIn(plan.id)}
                      isLoading={busyId === plan.id}
                      disabled={readToday}
                      className="w-full"
                    >
                      {readToday ? 'Leitura de hoje registrada ✓' : 'Marcar leitura de hoje'}
                    </Button>
                  )}
                </div>
              ) : (
                <Button
                  onClick={() => handleEnroll(plan.id)}
                  isLoading={busyId === plan.id}
                  variant="secondary"
                  className="w-full mt-4"
                >
                  Começar plano
                </Button>
              )}
            </Card>
          );
        })}
      </div> : null}
    </AppLayout>
  );
}
