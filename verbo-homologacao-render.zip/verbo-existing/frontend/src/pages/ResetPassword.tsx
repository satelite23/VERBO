import { FormEvent, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { resetPasswordRequest } from '../api/auth.api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { getApiErrorMessage } from '../hooks/useApiError';
import { AuthShell } from './ForgotPassword';

export function ResetPassword() {
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault(); setError('');
    if (password !== confirmation) return setError('As senhas não coincidem.');
    if (!token) return setError('Link de recuperação incompleto. Solicite um novo link.');
    setLoading(true);
    try {
      const response = await resetPasswordRequest(token, password);
      setMessage(response.message);
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível redefinir a senha.'));
    } finally { setLoading(false); }
  }

  return <AuthShell title="Defina uma nova senha" description="Use pelo menos oito caracteres e não reutilize uma senha antiga.">
    {message ? <div className="text-center"><p className="rounded-xl border border-sage/30 bg-sage/10 p-4 text-sm text-sage-soft">{message}</p><Link to="/login" className="btn-primary mt-5">Entrar com a nova senha</Link></div> : <form onSubmit={submit} className="space-y-5"><Input label="Nova senha" type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(event) => setPassword(event.target.value)} /><Input label="Confirmar nova senha" type="password" autoComplete="new-password" minLength={8} required value={confirmation} onChange={(event) => setConfirmation(event.target.value)} />{error ? <p className="text-sm text-rose-soft" role="alert">{error}</p> : null}<Button type="submit" isLoading={loading} className="w-full">Salvar nova senha</Button></form>}
  </AuthShell>;
}
