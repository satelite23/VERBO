import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listDevotionals, type Devotional } from '../api/devotional.api';
import { listPosts, type Post } from '../api/post.api';
import { listPrayers, type Prayer } from '../api/prayer.api';
import { myEnrollments, type PlanEnrollment } from '../api/readingPlan.api';
import { AppLayout } from '../components/layout/AppLayout';
import { Card } from '../components/ui/Card';
import { VerseCard } from '../components/ui/VerseCard';
import { useAuth } from '../hooks/useAuth';

const SHORTCUTS = [
  { to: '/app/devocionais', title: 'Gerar devocional', icon: '📖' },
  { to: '/app/posts', title: 'Criar post', icon: '✦' },
  { to: '/app/oracao', title: 'Registrar oração', icon: '♡' },
  { to: '/app/leitura', title: 'Continuar leitura', icon: '▦' },
];

export function Dashboard() {
  const { user } = useAuth();
  const [devotionals, setDevotionals] = useState<Devotional[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [prayers, setPrayers] = useState<Prayer[]>([]);
  const [enrollments, setEnrollments] = useState<PlanEnrollment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    Promise.allSettled([listDevotionals(), listPosts(), listPrayers(), myEnrollments()])
      .then((results) => {
        if (!active) return;
        if (results[0].status === 'fulfilled') setDevotionals(results[0].value);
        if (results[1].status === 'fulfilled') setPosts(results[1].value);
        if (results[2].status === 'fulfilled') setPrayers(results[2].value);
        if (results[3].status === 'fulfilled') setEnrollments(results[3].value);
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const firstName = user?.name?.split(' ')[0];
  const latest = devotionals[0];
  const activePrayers = prayers.filter((prayer) => !prayer.isAnswered);
  const activePlan = enrollments.find((item) => !item.completedAt) ?? enrollments[0];
  const progress = activePlan ? Math.round((activePlan.completedDays / activePlan.plan.durationDays) * 100) : 0;
  const date = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' }).format(new Date());

  return (
    <AppLayout title="Início">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-7 -mt-3 lg:-mt-2">
        <div><h2 className="font-display text-2xl sm:text-3xl text-paper">Bem-vindo(a) de volta{firstName ? `, ${firstName}` : ''}</h2><p className="text-sm text-mist mt-1 capitalize">{date} · seu momento com a Palavra hoje</p></div>
        <Link className="btn-primary" to="/app/devocionais">+ Novo devocional</Link>
      </div>

      <div className="grid sm:grid-cols-3 gap-3 mb-5">
        <Card><p className="font-display text-3xl text-paper">{activePlan?.completedDays ?? 0}</p><p className="font-mono text-[9px] uppercase tracking-wider text-mist mt-2">dias de leitura concluídos</p></Card>
        <Card><p className="font-display text-3xl text-paper">🔥 {activePlan?.streak ?? 0}</p><p className="font-mono text-[9px] uppercase tracking-wider text-mist mt-2">sequência atual</p></Card>
        <Card><p className="font-display text-3xl text-paper">{activePrayers.length}</p><p className="font-mono text-[9px] uppercase tracking-wider text-mist mt-2">pedidos de oração ativos</p></Card>
      </div>

      {loading ? <Card className="text-center py-12"><p className="text-mist">Organizando sua página inicial...</p></Card> : <div className="grid lg:grid-cols-[1.3fr_.8fr] gap-5">
        <div>{latest ? <article className="card"><p className="font-mono text-[10px] uppercase tracking-widest text-gold mb-3">Devocional mais recente · {latest.theme}</p><h2 className="font-display text-3xl text-paper mb-4">{latest.title}</h2><VerseCard reference={latest.verseRef} text={latest.verseText} /><p className="text-sm text-paper/80 leading-relaxed mt-5 line-clamp-4">{latest.reflection}</p><Link to="/app/devocionais" className="btn-secondary mt-5">Abrir devocionais →</Link></article> : <Card className="text-center py-14"><p className="font-display text-2xl text-paper">Seu primeiro devocional começa com um tema.</p><p className="text-sm text-mist mt-2 mb-5">Escolha aquilo que representa sua semana.</p><Link to="/app/devocionais" className="btn-primary">Criar agora</Link></Card>}</div>

        <aside className="space-y-4">
          <Card>{activePlan ? <><div className="flex justify-between gap-3"><div><p className="font-display text-lg text-paper">{activePlan.plan.name}</p><p className="text-xs text-mist mt-1">{activePlan.completedDays} de {activePlan.plan.durationDays} leituras</p></div><span className="text-sm text-gold">{progress}%</span></div><div className="h-1.5 bg-white/10 rounded-full overflow-hidden mt-4"><div className="h-full bg-gold rounded-full" style={{ width: `${progress}%` }} /></div><Link className="btn-secondary w-full mt-4" to="/app/leitura">Continuar plano</Link></> : <><p className="font-display text-lg text-paper">Plano de leitura</p><p className="text-xs text-mist mt-1 mb-4">Escolha uma jornada para começar.</p><Link className="btn-secondary w-full" to="/app/leitura">Ver planos</Link></>}</Card>
          <Card><div className="flex justify-between"><p className="font-display text-lg text-paper">Orando esta semana</p><Link to="/app/oracao" className="text-xs text-gold">Ver todos</Link></div><div className="space-y-3 mt-4">{activePrayers.slice(0, 3).map((prayer) => <div className="flex items-center gap-3 text-sm text-paper/85" key={prayer.id}><span className="w-4 h-4 rounded-full border-2 border-white/20 shrink-0" />{prayer.title}</div>)}{!activePrayers.length ? <p className="text-xs text-mist">Nenhum pedido ativo.</p> : null}</div></Card>
          <div className="grid grid-cols-2 gap-3"><Card className="!p-4"><p className="font-display text-2xl text-paper">{devotionals.length}</p><p className="text-[10px] text-mist mt-1">devocionais</p></Card><Card className="!p-4"><p className="font-display text-2xl text-paper">{posts.length}</p><p className="text-[10px] text-mist mt-1">posts</p></Card></div>
        </aside>
      </div>}

      <section className="mt-8"><h2 className="font-display text-lg text-paper mb-3">Criar agora</h2><div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{SHORTCUTS.map((item) => <Link key={item.to} to={item.to} className="card !p-4 flex items-center gap-3 hover:border-gold/30 transition-colors"><span className="text-xl text-gold">{item.icon}</span><span className="text-sm text-paper">{item.title}</span></Link>)}</div></section>
    </AppLayout>
  );
}
