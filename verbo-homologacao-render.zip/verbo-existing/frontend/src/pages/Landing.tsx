import { Link } from 'react-router-dom';

const FEATURES = [
  ['Devocionais por tema', 'Transforme uma ideia em uma reflexão estruturada para revisar e personalizar.', '📖'],
  ['Posts para redes', 'Adapte a mesma mensagem para Feed, Stories e WhatsApp.', '✦'],
  ['Pedidos de oração', 'Registre aquilo que está em seu coração e acompanhe respostas.', '♡'],
  ['Planos de leitura', 'Mantenha constância com leituras diárias e progresso visível.', '▦'],
  ['Histórico organizado', 'Encontre e reaproveite o conteúdo que já foi criado.', '◫'],
  ['Sua identidade', 'Prepare a base para cores, templates e a marca da sua igreja.', '◇'],
];

export function Landing() {
  return (
    <div className="min-h-screen bg-night text-paper">
      <div className="bg-gold text-ink text-center text-xs sm:text-sm font-semibold px-4 py-2.5">
        Beta Fundadores · 30 dias Pro para os primeiros 150 usuários, sem cartão
      </div>
      <header className="sticky top-0 z-30 border-b border-white/5 bg-night/90 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto h-[68px] px-5 sm:px-8 flex items-center justify-between">
          <Link to="/" className="font-display text-2xl font-semibold">Verbo<span className="text-gold">.</span></Link>
          <nav className="hidden md:flex items-center gap-7 text-sm text-mist">
            <a href="#recursos" className="hover:text-gold transition-colors">Recursos</a>
            <a href="#como-funciona" className="hover:text-gold transition-colors">Como funciona</a>
            <a href="#abordagem" className="hover:text-gold transition-colors">Nossa abordagem</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/login" className="btn-secondary !px-4 !py-2">Entrar</Link>
            <Link to="/registrar" className="btn-primary !px-4 !py-2">Experimentar <span aria-hidden>→</span></Link>
          </div>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden border-b border-white/5">
          <div className="absolute -top-72 -left-52 w-[700px] h-[600px] rounded-full bg-gold/15 blur-3xl pointer-events-none" />
          <div className="relative max-w-6xl mx-auto px-5 sm:px-8 py-20 lg:py-28 grid lg:grid-cols-[1.08fr_.92fr] gap-14 lg:gap-20 items-center">
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[.18em] text-gold mb-5">Conteúdo cristão com propósito</p>
              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-semibold tracking-tight leading-[1.03]">
                Da sua ideia à mensagem, <em className="text-gold-soft font-medium">sem começar do zero.</em>
              </h1>
              <p className="text-mist text-base sm:text-lg leading-relaxed mt-6 max-w-2xl">
                Crie devocionais, posts, pedidos de oração e planos de leitura. Depois, revise, personalize com sua voz e compartilhe.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 mt-8">
                <Link to="/registrar" className="btn-primary">Criar meu primeiro conteúdo <span aria-hidden>→</span></Link>
                <a href="#como-funciona" className="btn-secondary">Ver como funciona</a>
              </div>
              <p className="text-xs text-mist/70 mt-4">Não é necessário cadastrar cartão para começar.</p>
            </div>

            <div className="verse-card !p-8 sm:!p-10 lg:rotate-1">
              <p className="font-mono text-[10px] uppercase tracking-[.16em] text-[#8A6A2B]">Devocional · esperança</p>
              <h2 className="font-display text-3xl font-semibold mt-4 mb-3">Há luz para o próximo passo</h2>
              <p className="font-mono text-[11px] uppercase tracking-wider text-[#8A6A2B] mb-2">Romanos 15:13</p>
              <blockquote className="font-display italic text-xl sm:text-2xl leading-relaxed">
                “Que o Deus da esperança os encha de toda alegria e paz...”
              </blockquote>
              <p className="text-ink/70 text-sm leading-relaxed mt-5">
                Nem sempre conseguimos enxergar o caminho inteiro. Às vezes, a fé se manifesta na coragem de dar apenas o próximo passo...
              </p>
              <div className="flex justify-between border-t border-ink/10 mt-6 pt-4 text-[10px] text-ink/60">
                <span>Pronto para personalizar</span><span>2 min de leitura</span>
              </div>
            </div>
          </div>
        </section>

        <section id="recursos" className="max-w-6xl mx-auto px-5 sm:px-8 py-20 lg:py-24">
          <p className="font-mono text-[11px] uppercase tracking-[.18em] text-gold mb-4">Tudo em um lugar</p>
          <h2 className="font-display text-4xl sm:text-5xl font-semibold max-w-3xl leading-tight">Um ponto de partida para cada momento da sua comunicação.</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-10">
            {FEATURES.map(([title, text, icon]) => (
              <article className="card min-h-56 group hover:border-gold/30 transition-colors" key={title}>
                <span className="w-11 h-11 rounded-xl bg-gold/10 text-gold grid place-items-center text-xl">{icon}</span>
                <h3 className="font-display text-xl mt-8 group-hover:text-gold transition-colors">{title}</h3>
                <p className="text-sm text-mist leading-relaxed mt-2">{text}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="como-funciona" className="border-y border-white/5 bg-night-soft/25">
          <div className="max-w-6xl mx-auto px-5 sm:px-8 py-20 lg:py-24">
            <p className="font-mono text-[11px] uppercase tracking-[.18em] text-gold mb-4">Simples por intenção</p>
            <h2 className="font-display text-4xl sm:text-5xl font-semibold">Do tema ao conteúdo em três passos.</h2>
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              {[
                ['01 · ESCOLHA', 'Defina o formato', 'Devocional, Feed, Story, WhatsApp, oração ou plano de leitura.'],
                ['02 · CONTEXTUALIZE', 'Informe o tema', 'Comece com uma palavra, uma necessidade ou o assunto da semana.'],
                ['03 · PERSONALIZE', 'Revise e compartilhe', 'Confira referências, ajuste a linguagem e preserve sua voz.'],
              ].map(([number, title, text]) => <div key={number}><p className="font-mono text-[10px] tracking-wider text-gold">{number}</p><h3 className="font-display text-2xl mt-4">{title}</h3><p className="text-sm text-mist leading-relaxed mt-2">{text}</p></div>)}
            </div>
          </div>
        </section>

        <section id="abordagem" className="max-w-6xl mx-auto px-5 sm:px-8 py-20 lg:py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div><p className="font-mono text-[11px] uppercase tracking-[.18em] text-gold mb-4">Criação responsável</p><h2 className="font-display text-4xl sm:text-5xl font-semibold leading-tight">O Verbo ajuda a criar. A mensagem final continua sendo sua.</h2></div>
          <div className="text-mist leading-relaxed space-y-4">
            <p>O produto foi desenhado como apoio editorial, não como piloto automático. Todo conteúdo pode ser editado e deve ser conferido antes de chegar à sua comunidade.</p>
            <ul className="space-y-3 text-sm"><li className="flex gap-3"><span className="text-sage-soft">✓</span>Confira a referência e a tradução bíblica adotada.</li><li className="flex gap-3"><span className="text-sage-soft">✓</span>Adapte a aplicação à realidade da sua comunidade.</li><li className="flex gap-3"><span className="text-sage-soft">✓</span>Reescreva com sua voz, contexto e convicções.</li></ul>
          </div>
        </section>

        <section className="max-w-6xl mx-auto px-5 sm:px-8 pb-24">
          <div className="rounded-[28px] border border-gold/20 bg-gradient-to-br from-gold/10 to-night-soft p-8 sm:p-14 text-center">
            <span className="text-gold text-2xl">✦</span>
            <h2 className="font-display text-4xl sm:text-5xl font-semibold mt-4">Sua próxima mensagem não precisa começar em uma tela vazia.</h2>
            <p className="text-mist max-w-2xl mx-auto mt-4 mb-8">Escolha um tema e experimente o fluxo do Verbo. Os primeiros usuários também poderão influenciar as próximas melhorias.</p>
            <Link to="/registrar" className="btn-primary">Participar do Beta Fundadores <span aria-hidden>→</span></Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/5">
        <div className="max-w-6xl mx-auto px-5 sm:px-8 py-10 flex flex-col sm:flex-row gap-4 justify-between text-xs text-mist/70">
          <span className="font-display text-lg text-paper">Verbo<span className="text-gold">.</span></span>
          <span>© 2026 Verbo · Conteúdo criado para ser revisado e personalizado.</span>
          <div className="flex gap-5"><Link to="/termos">Termos</Link><Link to="/privacidade">Privacidade</Link></div>
        </div>
      </footer>
    </div>
  );
}
