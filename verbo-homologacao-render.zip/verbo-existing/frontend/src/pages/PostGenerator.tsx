import { useEffect, useRef, useState } from 'react';
import { AppLayout } from '../components/layout/AppLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { PostArtwork } from '../components/editor/PostArtwork';
import { deletePost, generatePost, listPosts, Post, PostFormat, updatePost } from '../api/post.api';
import { listThemes } from '../api/devotional.api';
import { getApiErrorMessage } from '../hooks/useApiError';
import { BillingStatus, getBillingStatus } from '../api/billing.api';
import { downloadArtworkPdf, downloadArtworkPng } from '../utils/exportArtwork';
import { prepareImage } from '../utils/image';

const FORMATS: Array<{ value: PostFormat; label: string; size: string }> = [
  { value: 'FEED', label: 'Feed 1:1', size: '1080 × 1080' },
  { value: 'STORY', label: 'Stories 9:16', size: '1080 × 1920' },
  { value: 'WHATSAPP', label: 'WhatsApp 9:16', size: '1080 × 1920' },
];
const PALETTES = [
  { bg: '#12162A', accent: '#C9A24B', name: 'Noite' },
  { bg: '#1B2140', accent: '#E1C381', name: 'Manuscrito' },
  { bg: '#3E5344', accent: '#EAE0C6', name: 'Oliva' },
  { bg: '#5A2A2A', accent: '#E1C381', name: 'Vinho' },
];
const TEMPLATES: Array<{ id: Post['templateId']; label: string; description: string }> = [
  { id: 'illuminated', label: 'Iluminura', description: 'Pergaminho em destaque' },
  { id: 'minimal', label: 'Essencial', description: 'Limpo e contemplativo' },
  { id: 'editorial', label: 'Editorial', description: 'Texto com eixo lateral' },
  { id: 'frame', label: 'Moldura', description: 'Composição clássica' },
];

export function PostGenerator() {
  const artworkRef = useRef<HTMLDivElement>(null);
  const [themes, setThemes] = useState<string[]>([]);
  const [theme, setTheme] = useState('');
  const [format, setFormat] = useState<PostFormat>('FEED');
  const [template, setTemplate] = useState<Post['templateId']>('illuminated');
  const [palette, setPalette] = useState(PALETTES[0]);
  const [current, setCurrent] = useState<Post | null>(null);
  const [history, setHistory] = useState<Post[]>([]);
  const [billing, setBilling] = useState<BillingStatus | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [exporting, setExporting] = useState('');
  const [processingImage, setProcessingImage] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    let active = true;
    Promise.all([listThemes(), listPosts(), getBillingStatus()])
      .then(([availableThemes, posts, billingStatus]) => {
        if (!active) return;
        setThemes(availableThemes);
        setTheme(availableThemes[0] ?? '');
        setHistory(posts);
        setBilling(billingStatus);
        const firstAllowed = TEMPLATES.find((item) => billingStatus.entitlements.templates.includes(item.id));
        if (firstAllowed) setTemplate(firstAllowed.id);
      })
      .catch((caught) => { if (active) setError(getApiErrorMessage(caught, 'Não foi possível carregar seus posts.')); });
    return () => { active = false; };
  }, []);

  async function handleGenerate() {
    if (!theme) return;
    setIsGenerating(true); clearFeedback();
    try {
      const post = await generatePost({
        theme,
        format,
        templateId: template,
        bgColor: palette.bg,
        accentColor: palette.accent,
        fontFamily: 'fraunces',
        textAlign: 'center',
        overlayOpacity: 45,
        fontScale: 100,
      });
      setCurrent(post);
      setHistory((items) => [post, ...items]);
    } catch (caught) { setError(getApiErrorMessage(caught, 'Não foi possível gerar o post.')); }
    finally { setIsGenerating(false); }
  }

  async function handleSave() {
    if (!current) return;
    setIsSaving(true); clearFeedback();
    try {
      const updated = await updatePost(current.id, {
        title: current.title,
        caption: current.caption,
        format: current.format,
        templateId: current.templateId,
        bgColor: current.bgColor,
        accentColor: current.accentColor,
        imageUrl: current.imageUrl ?? null,
        logoUrl: current.logoUrl ?? null,
        fontFamily: current.fontFamily,
        textAlign: current.textAlign,
        overlayOpacity: current.overlayOpacity,
        fontScale: current.fontScale,
      });
      setCurrent(updated);
      setHistory((items) => items.map((item) => item.id === updated.id ? updated : item));
      setNotice('Design e legenda salvos no histórico.');
    } catch (caught) { setError(getApiErrorMessage(caught, 'Não foi possível salvar o post.')); }
    finally { setIsSaving(false); }
  }

  async function handleCopy() {
    if (!current) return;
    await navigator.clipboard.writeText(`${current.verseRef}\n“${current.verseText}”\n\n${current.caption}`);
    setNotice('Legenda e versículo copiados.');
  }

  async function handleExport(kind: 'png' | 'pdf') {
    if (!current || !artworkRef.current) return;
    setExporting(kind); clearFeedback();
    try {
      if (kind === 'png') await downloadArtworkPng(artworkRef.current, current);
      else await downloadArtworkPdf(artworkRef.current, current);
      setNotice(`${kind.toUpperCase()} exportado em alta resolução.`);
    } catch (caught) {
      console.error(caught);
      setError('Não foi possível exportar. Se estiver usando uma imagem externa, tente enviá-la como arquivo.');
    } finally { setExporting(''); }
  }

  async function handleAsset(file: File | undefined, type: 'background' | 'logo') {
    if (!file || !current) return;
    setProcessingImage(type); clearFeedback();
    try {
      const value = await prepareImage(file, type === 'logo'
        ? { maxDimension: 500, maxBytes: 300_000, transparent: true }
        : { maxDimension: 1600, maxBytes: 1_400_000 });
      setCurrent({ ...current, [type === 'logo' ? 'logoUrl' : 'imageUrl']: value });
      setNotice(type === 'logo' ? 'Logo aplicado. Salve para manter no histórico.' : 'Imagem de fundo aplicada.');
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Não foi possível processar a imagem.'); }
    finally { setProcessingImage(''); }
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Excluir este post do histórico?')) return;
    try {
      await deletePost(id);
      setHistory((items) => items.filter((item) => item.id !== id));
      if (current?.id === id) setCurrent(null);
    } catch (caught) { setError(getApiErrorMessage(caught, 'Não foi possível excluir o post.')); }
  }

  function updateCurrent<K extends keyof Post>(field: K, value: Post[K]) {
    setCurrent((item) => item ? { ...item, [field]: value } : item);
  }
  function applyPalette(item: typeof PALETTES[number]) {
    setPalette(item);
    if (current) setCurrent({ ...current, bgColor: item.bg, accentColor: item.accent });
  }
  function clearFeedback() { setError(''); setNotice(''); }

  const allowedTemplates = TEMPLATES.filter((item) =>
    (billing?.entitlements.templates ?? ['illuminated', 'minimal']).includes(item.id),
  );
  const showWatermark = billing?.entitlements.watermark ?? true;
  const canUseCustomLogo = billing?.entitlements.customLogo ?? false;

  return (
    <AppLayout title="Editor de Posts">
      {!current ? (
        <div className="grid lg:grid-cols-[340px_1fr] gap-6">
          <Card className="h-fit space-y-5">
            <div><p className="font-mono text-[10px] uppercase tracking-widest text-gold mb-2">Criar conteúdo visual</p><h2 className="font-display text-xl text-paper">Novo post</h2></div>
            <SelectField label="Tema" value={theme} onChange={setTheme} options={themes.map((item) => ({ value: item, label: item }))} />
            <div><label className="text-sm font-medium text-mist mb-2 block">Formato</label><div className="flex flex-wrap gap-2">{FORMATS.map((item) => <button key={item.value} onClick={() => setFormat(item.value)} className={`px-3 py-1.5 rounded-full text-sm border ${format === item.value ? 'bg-gold text-ink border-gold' : 'border-white/10 text-mist'}`}>{item.label}</button>)}</div></div>
            <div><label className="text-sm font-medium text-mist mb-2 block">Template</label><div className="grid grid-cols-2 gap-2">{allowedTemplates.map((item) => <button key={item.id} onClick={() => setTemplate(item.id)} className={`text-left rounded-lg border p-3 ${template === item.id ? 'border-gold bg-gold/10' : 'border-white/10'}`}><strong className="text-xs text-paper block">{item.label}</strong><span className="text-[10px] text-mist">{item.description}</span></button>)}</div></div>
            <PalettePicker selected={palette.name} onSelect={applyPalette} />
            {billing ? <div className="rounded-lg bg-white/5 p-3 text-[11px] text-mist"><div className="flex justify-between"><span>Plano {billing.entitlements.name}</span><span>{billing.usage.used}/{billing.usage.limit} gerações</span></div><div className="h-1 bg-white/10 rounded-full mt-2"><div className="h-full bg-gold rounded-full" style={{ width: `${Math.min(100, (billing.usage.used / billing.usage.limit) * 100)}%` }} /></div></div> : null}
            <Button onClick={handleGenerate} isLoading={isGenerating} className="w-full">Gerar e abrir editor</Button>
          </Card>
          <Card className="grid place-items-center text-center min-h-[520px]"><div><span className="text-5xl text-gold">◇</span><h2 className="font-display text-3xl text-paper mt-5">Seu estúdio visual começa aqui</h2><p className="text-sm text-mist max-w-md mt-2">Escolha tema, formato e template. Depois, adicione imagem, logo, tipografia e exporte.</p></div></Card>
        </div>
      ) : (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <Button onClick={handleSave} isLoading={isSaving}>Salvar</Button>
            <button className="btn-secondary" onClick={handleCopy}>Copiar texto</button>
            <button className="btn-secondary" onClick={() => handleExport('png')} disabled={Boolean(exporting)}>{exporting === 'png' ? 'Exportando...' : 'Baixar PNG'}</button>
            <button className="btn-secondary" onClick={() => handleExport('pdf')} disabled={Boolean(exporting)}>{exporting === 'pdf' ? 'Exportando...' : 'Baixar PDF'}</button>
            <button className="ml-auto text-sm text-mist hover:text-paper" onClick={() => setCurrent(null)}>← Criar outro</button>
          </div>
          {error ? <p className="rounded-lg border border-rose/30 bg-rose/10 p-3 text-sm text-rose-soft" role="alert">{error}</p> : null}
          {notice ? <p className="rounded-lg border border-sage/30 bg-sage/10 p-3 text-sm text-sage-soft">✓ {notice}</p> : null}

          <div className="grid xl:grid-cols-[330px_minmax(380px,1fr)_300px] gap-5 items-start">
            <aside className="card space-y-5 xl:sticky xl:top-5">
              <h2 className="font-display text-lg text-paper">Design</h2>
              <SelectField label="Formato" value={current.format} onChange={(value) => updateCurrent('format', value as PostFormat)} options={FORMATS.map((item) => ({ value: item.value, label: `${item.label} · ${item.size}` }))} />
              <div><label className="text-xs font-medium text-mist block mb-2">Template</label><div className="grid grid-cols-2 gap-2">{allowedTemplates.map((item) => <button key={item.id} onClick={() => updateCurrent('templateId', item.id)} className={`rounded-lg border p-2.5 text-xs text-left ${current.templateId === item.id ? 'border-gold bg-gold/10 text-paper' : 'border-white/10 text-mist'}`}>{item.label}</button>)}</div></div>
              <PalettePicker selected="" onSelect={applyPalette} />
              <div className="grid grid-cols-2 gap-3"><ColorInput label="Fundo" value={current.bgColor} onChange={(value) => updateCurrent('bgColor', value)} /><ColorInput label="Destaque" value={current.accentColor} onChange={(value) => updateCurrent('accentColor', value)} /></div>
              <SelectField label="Tipografia" value={current.fontFamily} onChange={(value) => updateCurrent('fontFamily', value as Post['fontFamily'])} options={[{ value: 'fraunces', label: 'Fraunces · editorial' }, { value: 'inter', label: 'Inter · contemporânea' }, { value: 'mono', label: 'Plex Mono · técnica' }]} />
              <SelectField label="Alinhamento" value={current.textAlign} onChange={(value) => updateCurrent('textAlign', value as Post['textAlign'])} options={[{ value: 'left', label: 'Esquerda' }, { value: 'center', label: 'Centro' }, { value: 'right', label: 'Direita' }]} />
              <RangeInput label={`Tamanho do texto · ${current.fontScale}%`} min={70} max={140} value={current.fontScale} onChange={(value) => updateCurrent('fontScale', value)} />
              {current.imageUrl ? <RangeInput label={`Escurecer imagem · ${current.overlayOpacity}%`} min={0} max={90} value={current.overlayOpacity} onChange={(value) => updateCurrent('overlayOpacity', value)} /> : null}
            </aside>

            <main className="card min-h-[620px] flex flex-col items-center justify-center overflow-auto">
              <PostArtwork ref={artworkRef} post={canUseCustomLogo ? current : { ...current, logoUrl: null }} showWatermark={showWatermark} className="rounded-2xl shadow-card" />
              <div className="flex flex-wrap justify-center gap-2 mt-4 text-[10px] font-mono uppercase tracking-wider"><span className={current.bibleSource === 'api-bible' ? 'text-sage-soft' : 'text-rose-soft'}>{current.bibleSource === 'api-bible' ? `Bíblia · ${current.bibleVersion}` : 'Texto demonstrativo'}</span><span className="text-mist">Editorial · {current.aiProvider}</span></div>
            </main>

            <aside className="space-y-5">
              <section className="card space-y-4"><h2 className="font-display text-lg text-paper">Imagens e marca</h2><UploadField label={processingImage === 'background' ? 'Processando...' : 'Imagem de fundo'} accept="image/png,image/jpeg,image/webp" onFile={(file) => handleAsset(file, 'background')} disabled={Boolean(processingImage)} />{current.imageUrl ? <button className="text-xs text-rose-soft" onClick={() => updateCurrent('imageUrl', null)}>Remover fundo</button> : null}{canUseCustomLogo ? <><UploadField label={processingImage === 'logo' ? 'Processando...' : 'Logo da igreja/projeto'} accept="image/png,image/webp" onFile={(file) => handleAsset(file, 'logo')} disabled={Boolean(processingImage)} />{current.logoUrl ? <button className="text-xs text-rose-soft" onClick={() => updateCurrent('logoUrl', null)}>Remover logo</button> : null}</> : <a href="/app/plano" className="block rounded-lg border border-gold/20 bg-gold/5 p-3 text-xs text-gold">Logo personalizado está no plano Igreja →</a>}<p className="text-[10px] text-mist/60 leading-relaxed">As imagens são redimensionadas no navegador antes de salvar. PNG preserva transparência do logo.</p></section>
              <section className="card space-y-4"><h2 className="font-display text-lg text-paper">Legenda</h2><input className="input-field" value={current.title} onChange={(event) => updateCurrent('title', event.target.value)} aria-label="Título interno" /><textarea className="input-field min-h-48 resize-y leading-relaxed" value={current.caption} onChange={(event) => updateCurrent('caption', event.target.value)} /><button className="btn-secondary w-full" onClick={handleCopy}>Copiar legenda</button></section>
              <p className="text-[10px] text-mist/60 leading-relaxed px-1">Confira texto bíblico, direitos da imagem e aplicação antes de publicar. O PNG é exportado em 1080 px.</p>
            </aside>
          </div>
        </div>
      )}

      {history.length ? <section className="mt-9"><h2 className="font-display text-lg text-paper mb-3">Histórico visual</h2><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">{history.map((item) => <div key={item.id} className="relative group"><button onClick={() => { setCurrent(item); clearFeedback(); }} className="w-full aspect-square rounded-xl flex items-center justify-center p-3 text-center overflow-hidden relative" style={{ backgroundColor: item.bgColor, backgroundImage: item.imageUrl ? `linear-gradient(rgba(0,0,0,.35),rgba(0,0,0,.35)),url(${item.imageUrl})` : undefined, backgroundSize: 'cover' }}><p className="font-mono text-[9px] uppercase relative" style={{ color: item.accentColor }}>{item.verseRef}</p></button><button onClick={() => handleDelete(item.id)} className="absolute top-1.5 right-1.5 bg-night/85 rounded-full px-2 py-1 text-mist hover:text-rose-soft opacity-0 group-hover:opacity-100" aria-label="Excluir">✕</button></div>)}</div></section> : null}
    </AppLayout>
  );
}

function SelectField({ label, value, onChange, options }: { label: string; value: string; onChange: (value: string) => void; options: Array<{ value: string; label: string }> }) {
  return <div><label className="text-xs font-medium text-mist block mb-1.5">{label}</label><select className="input-field" value={value} onChange={(event) => onChange(event.target.value)}>{options.map((item) => <option value={item.value} key={item.value}>{item.label}</option>)}</select></div>;
}
function PalettePicker({ selected, onSelect }: { selected: string; onSelect: (item: typeof PALETTES[number]) => void }) {
  return <div><label className="text-xs font-medium text-mist block mb-2">Paleta</label><div className="flex gap-2">{PALETTES.map((item) => <button key={item.name} onClick={() => onSelect(item)} aria-label={item.name} title={item.name} className={`h-9 w-9 rounded-full border-2 transition-transform ${selected === item.name ? 'border-gold scale-110' : 'border-transparent'}`} style={{ background: `linear-gradient(135deg, ${item.bg}, ${item.accent})` }} />)}</div></div>;
}
function ColorInput({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return <label className="text-xs text-mist">{label}<input type="color" className="w-full h-10 mt-1 rounded-lg bg-night-softer border border-white/10 p-1" value={value} onChange={(event) => onChange(event.target.value)} /></label>;
}
function RangeInput({ label, min, max, value, onChange }: { label: string; min: number; max: number; value: number; onChange: (value: number) => void }) {
  return <label className="text-xs text-mist block">{label}<input type="range" min={min} max={max} value={value} onChange={(event) => onChange(Number(event.target.value))} className="w-full accent-gold mt-2" /></label>;
}
function UploadField({ label, accept, onFile, disabled }: { label: string; accept: string; onFile: (file?: File) => void; disabled: boolean }) {
  return <label className={`btn-secondary w-full cursor-pointer ${disabled ? 'opacity-50 pointer-events-none' : ''}`}>{label}<input className="sr-only" type="file" accept={accept} disabled={disabled} onChange={(event) => { onFile(event.target.files?.[0]); event.target.value = ''; }} /></label>;
}
