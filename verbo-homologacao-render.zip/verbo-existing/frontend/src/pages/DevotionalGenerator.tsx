import { useEffect, useState } from 'react';
import { AppLayout } from '../components/layout/AppLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { VerseCard } from '../components/ui/VerseCard';
import {
  Devotional,
  deleteDevotional,
  generateDevotional,
  listDevotionals,
  listThemes,
  updateDevotional,
} from '../api/devotional.api';
import { getApiErrorMessage } from '../hooks/useApiError';

const THEME_LABELS: Record<string, string> = {
  ansiedade: 'Ansiedade', gratidao: 'Gratidão', esperanca: 'Esperança', fe: 'Fé', paz: 'Paz',
  amor: 'Amor', forca: 'Força', luto: 'Luto', proposito: 'Propósito', sabedoria: 'Sabedoria',
};

export function DevotionalGenerator() {
  const [themes, setThemes] = useState<string[]>([]);
  const [selectedTheme, setSelectedTheme] = useState('');
  const [current, setCurrent] = useState<Devotional | null>(null);
  const [history, setHistory] = useState<Devotional[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const [availableThemes, devotionals] = await Promise.all([listThemes(), listDevotionals()]);
        if (!active) return;
        setThemes(availableThemes);
        setSelectedTheme(availableThemes[0] ?? '');
        setHistory(devotionals);
      } catch (err) {
        if (active) setError(getApiErrorMessage(err, 'Não foi possível carregar seus devocionais.'));
      }
    }
    void load();
    return () => { active = false; };
  }, []);

  async function handleGenerate() {
    if (!selectedTheme) return;
    setIsGenerating(true); setError(''); setNotice('');
    try {
      const devotional = await generateDevotional(selectedTheme);
      setCurrent(devotional);
      setHistory((previous) => [devotional, ...previous]);
    } catch (err) { setError(getApiErrorMessage(err, 'Não foi possível gerar o devocional.')); }
    finally { setIsGenerating(false); }
  }

  async function handleSave() {
    if (!current) return;
    setIsSaving(true); setError(''); setNotice('');
    try {
      const updated = await updateDevotional(current.id, current);
      setCurrent(updated);
      setHistory((items) => items.map((item) => item.id === updated.id ? updated : item));
      setNotice('Alterações salvas no histórico.');
    } catch (err) { setError(getApiErrorMessage(err, 'Não foi possível salvar as alterações.')); }
    finally { setIsSaving(false); }
  }

  async function handleCopy() {
    if (!current) return;
    await navigator.clipboard.writeText(formatDevotional(current));
    setNotice('Devocional copiado.');
  }

  function handleDownload() {
    if (!current) return;
    const blob = new Blob([formatDevotional(current)], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${slug(current.title)}.txt`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Excluir este devocional do histórico?')) return;
    try {
      await deleteDevotional(id);
      setHistory((items) => items.filter((item) => item.id !== id));
      if (current?.id === id) setCurrent(null);
    } catch (err) { setError(getApiErrorMessage(err, 'Não foi possível excluir o devocional.')); }
  }

  function updateField<K extends keyof Devotional>(field: K, value: Devotional[K]) {
    setCurrent((item) => item ? { ...item, [field]: value } : item);
  }

  return (
    <AppLayout title="Devocionais">
      <div className="grid lg:grid-cols-[330px_1fr] gap-6">
        <Card className="h-fit lg:sticky lg:top-6">
          <p className="font-mono text-[10px] uppercase tracking-widest text-gold mb-2">Criar conteúdo</p>
          <h2 className="font-display text-xl text-paper mb-4">Novo devocional</h2>
          <label className="text-sm font-medium text-mist mb-2 block">Tema</label>
          <div className="flex flex-wrap gap-2 mb-5">{themes.map((theme) => <button key={theme} onClick={() => setSelectedTheme(theme)} className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${selectedTheme === theme ? 'bg-gold text-ink border-gold' : 'border-white/10 text-mist hover:border-gold/50 hover:text-paper'}`}>{THEME_LABELS[theme] ?? theme}</button>)}</div>
          <p className="text-[11px] text-mist/70 leading-relaxed mb-4">O Verbo cria uma primeira versão. Confira a referência, ajuste o contexto e preserve sua voz.</p>
          <Button onClick={handleGenerate} isLoading={isGenerating} className="w-full">Gerar devocional</Button>
        </Card>

        <div className="space-y-6 min-w-0">
          {error ? <p className="rounded-lg border border-rose/30 bg-rose/10 p-3 text-sm text-rose-soft" role="alert">{error}</p> : null}
          {notice ? <p className="rounded-lg border border-sage/30 bg-sage/10 p-3 text-sm text-sage-soft">✓ {notice}</p> : null}
          {current ? <Card>
            <div className="flex flex-wrap gap-2 pb-5 mb-5 border-b border-white/5"><Button onClick={handleSave} isLoading={isSaving}>Salvar</Button><button className="btn-secondary" onClick={handleCopy}>Copiar</button><button className="btn-secondary" onClick={handleDownload}>Baixar .txt</button><span className="ml-auto self-center rounded-full bg-gold/10 text-gold text-xs px-3 py-1.5">{THEME_LABELS[current.theme] ?? current.theme}</span></div>
            <div className="space-y-5">
              <div><label className="text-xs font-medium text-mist block mb-1.5">Título</label><input className="input-field font-display !text-2xl" value={current.title} onChange={(event) => updateField('title', event.target.value)} /></div>
              <VerseCard reference={current.verseRef} text={current.verseText} />
              <div className="flex flex-wrap gap-2 text-[10px] font-mono uppercase tracking-wider"><span className={`rounded-full px-2.5 py-1 ${current.bibleSource === 'api-bible' ? 'bg-sage/15 text-sage-soft' : 'bg-rose/10 text-rose-soft'}`}>{current.bibleSource === 'api-bible' ? `Fonte bíblica · ${current.bibleVersion}` : 'Texto demonstrativo · revisar'}</span><span className="rounded-full bg-white/5 text-mist px-2.5 py-1">Editorial · {current.aiProvider}</span></div>
              {current.bibleCopyright ? <p className="text-[10px] text-mist/60">{current.bibleCopyright}</p> : null}
              <div className="grid sm:grid-cols-[180px_1fr] gap-3"><div><label className="text-xs font-medium text-mist block mb-1.5">Referência</label><input className="input-field" value={current.verseRef} onChange={(event) => updateField('verseRef', event.target.value)} /></div><div><label className="text-xs font-medium text-mist block mb-1.5">Texto bíblico — confira a tradução</label><textarea className="input-field resize-y min-h-20 font-display italic" value={current.verseText} onChange={(event) => updateField('verseText', event.target.value)} /></div></div>
              <EditorArea label="Reflexão" value={current.reflection} onChange={(value) => updateField('reflection', value)} rows={8} />
              <EditorArea label="Oração" value={current.prayer} onChange={(value) => updateField('prayer', value)} rows={4} />
              <EditorArea label="Pergunta para aplicação" value={current.question} onChange={(value) => updateField('question', value)} rows={3} />
              <p className="text-[11px] text-mist/60 leading-relaxed">Revise referências, tradução, contexto e aplicação antes de publicar. O Verbo é um apoio editorial e não substitui estudo ou orientação pastoral.</p>
            </div>
          </Card> : <Card className="text-center py-16"><span className="text-4xl text-gold">✦</span><h2 className="font-display text-2xl text-paper mt-4">Seu conteúdo aparecerá aqui</h2><p className="text-sm text-mist mt-2">Escolha um tema e gere uma primeira versão editável.</p></Card>}

          {history.length > 0 ? <section><h2 className="font-display text-lg text-paper mb-3">Histórico</h2><div className="space-y-2">{history.map((item) => <div key={item.id} className="flex items-center justify-between gap-3 bg-night-soft border border-white/5 rounded-lg px-4 py-3"><button onClick={() => { setCurrent(item); setNotice(''); }} className="text-left min-w-0 flex-1"><p className="text-sm font-medium text-paper truncate">{item.title}</p><p className="text-xs text-mist truncate">{item.verseRef}</p></button><button onClick={() => handleDelete(item.id)} aria-label="Excluir devocional" className="text-mist hover:text-rose-soft shrink-0">✕</button></div>)}</div></section> : null}
        </div>
      </div>
    </AppLayout>
  );
}

function EditorArea({ label, value, onChange, rows }: { label: string; value: string; onChange: (value: string) => void; rows: number }) {
  return <div><label className="text-xs font-medium text-mist block mb-1.5">{label}</label><textarea className="input-field resize-y leading-relaxed" rows={rows} value={value} onChange={(event) => onChange(event.target.value)} /></div>;
}

function formatDevotional(item: Devotional) {
  return [item.title, `${item.verseRef}\n“${item.verseText}”`, `Reflexão\n${item.reflection}`, `Oração\n${item.prayer}`, `Pergunta para aplicação\n${item.question}`].join('\n\n');
}
function slug(value: string) { return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }
