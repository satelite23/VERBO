import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { BibleVersion, ProfileType, UserGoal } from '../api/auth.api';
import { deleteAccountRequest } from '../api/auth.api';
import { AppLayout } from '../components/layout/AppLayout';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { useAuth } from '../hooks/useAuth';
import { getApiErrorMessage } from '../hooks/useApiError';

const GOALS: Array<{ id: UserGoal; label: string }> = [
  { id: 'DEVOTIONALS', label: 'Devocionais' },
  { id: 'POSTS', label: 'Posts' },
  { id: 'PRAYER', label: 'Oração' },
  { id: 'READING', label: 'Leitura' },
];

export function Settings() {
  const { user, updateProfile, logout } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState(user?.name ?? '');
  const [churchName, setChurchName] = useState(user?.churchName ?? '');
  const [profileType, setProfileType] = useState<ProfileType>(user?.profileType ?? 'PERSONAL');
  const [bibleVersion, setBibleVersion] = useState<BibleVersion>(user?.bibleVersion ?? 'ARC');
  const [goals, setGoals] = useState<UserGoal[]>(user?.goals ?? []);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  function toggleGoal(goal: UserGoal) {
    setGoals((current) => current.includes(goal) ? current.filter((item) => item !== goal) : [...current, goal]);
  }

  async function save() {
    setSaving(true); setError(''); setMessage('');
    try {
      await updateProfile({ name, churchName: churchName || null, profileType, bibleVersion, goals });
      setMessage('Configurações salvas.');
    } catch (err) { setError(getApiErrorMessage(err, 'Não foi possível salvar.')); }
    finally { setSaving(false); }
  }

  async function removeAccount() {
    const password = window.prompt('Para excluir sua conta e todos os dados, informe sua senha atual:');
    if (!password) return;
    if (!window.confirm('Esta ação é permanente. Deseja realmente excluir sua conta?')) return;
    try {
      await deleteAccountRequest(password);
      logout();
      navigate('/');
    } catch (err) { setError(getApiErrorMessage(err, 'Não foi possível excluir sua conta.')); }
  }

  return <AppLayout title="Configurações">
    <div className="grid lg:grid-cols-[1fr_300px] gap-6 items-start">
      <section className="card space-y-6">
        <div><h2 className="font-display text-2xl text-paper">Seu perfil</h2><p className="text-sm text-mist mt-1">Personalize as sugestões e os formatos mostrados no Verbo.</p></div>
        <div className="grid sm:grid-cols-2 gap-4"><Input label="Nome" value={name} onChange={(event) => setName(event.target.value)} /><Input label="E-mail" value={user?.email ?? ''} disabled /></div>
        <div className="grid sm:grid-cols-2 gap-4"><div><label className="text-sm font-medium text-mist block mb-1.5">Perfil de uso</label><select className="input-field" value={profileType} onChange={(event) => setProfileType(event.target.value as ProfileType)}><option value="PERSONAL">Uso individual</option><option value="CHURCH">Comunicação de igreja</option><option value="CREATOR">Criador de conteúdo</option><option value="MINISTRY">Liderança ou ministério</option></select></div><Input label="Igreja ou projeto (opcional)" value={churchName} onChange={(event) => setChurchName(event.target.value)} /></div>
        <div><label className="text-sm font-medium text-mist block mb-1.5">Tradução bíblica preferida</label><select className="input-field" value={bibleVersion} onChange={(event) => setBibleVersion(event.target.value as BibleVersion)}><option value="ARC">ARC</option><option value="ARA">ARA</option><option value="NVI">NVI</option><option value="NVT">NVT</option><option value="NTLH">NTLH</option></select><p className="text-[11px] text-mist/60 mt-2">A seleção será aplicada integralmente após a conexão da fonte bíblica licenciada.</p></div>
        <div><label className="text-sm font-medium text-mist block mb-3">Objetivos</label><div className="flex flex-wrap gap-2">{GOALS.map((goal) => <button key={goal.id} onClick={() => toggleGoal(goal.id)} className={`rounded-full border px-3 py-2 text-sm ${goals.includes(goal.id) ? 'bg-gold text-ink border-gold' : 'text-mist border-white/10'}`}>{goals.includes(goal.id) ? '✓ ' : ''}{goal.label}</button>)}</div></div>
        {error ? <p className="text-sm text-rose-soft" role="alert">{error}</p> : null}{message ? <p className="text-sm text-sage-soft">{message}</p> : null}
        <Button onClick={save} isLoading={saving}>Salvar alterações</Button>
      </section>

      <aside className="space-y-4">
        <section className="card"><h2 className="font-display text-lg text-paper">Conta</h2><p className="text-xs text-mist mt-2 mb-4">Use o e-mail de recuperação para trocar sua senha com segurança.</p><a className="btn-secondary w-full" href="/esqueci-senha">Alterar senha</a></section>
        <section className="card border-rose/20"><h2 className="font-display text-lg text-rose-soft">Zona de risco</h2><p className="text-xs text-mist mt-2 mb-4">A exclusão remove permanentemente conteúdos, pedidos e progresso.</p><button onClick={removeAccount} className="w-full rounded-full border border-rose/40 text-rose-soft px-4 py-2.5 text-sm hover:bg-rose/10">Excluir minha conta</button></section>
      </aside>
    </div>
  </AppLayout>;
}
