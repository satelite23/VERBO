import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { useAuth } from '../hooks/useAuth';
import { getApiErrorMessage } from '../hooks/useApiError';

export function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', churchName: '' });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      await register({
        name: form.name,
        email: form.email,
        password: form.password,
        churchName: form.churchName || undefined,
      });
      navigate('/onboarding');
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível criar sua conta.'));
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-night flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="font-display text-4xl text-paper">
            Verbo<span className="text-gold">.</span>
          </h1>
          <p className="text-mist mt-2">Crie sua conta e comece a produzir hoje mesmo.</p>
        </div>

        <form onSubmit={handleSubmit} className="card space-y-5">
          <Input label="Nome" required value={form.name} onChange={(e) => update('name', e.target.value)} />
          <Input
            label="E-mail"
            type="email"
            autoComplete="email"
            required
            value={form.email}
            onChange={(e) => update('email', e.target.value)}
          />
          <Input
            label="Senha"
            type="password"
            autoComplete="new-password"
            minLength={8}
            required
            value={form.password}
            onChange={(e) => update('password', e.target.value)}
          />
          <Input
            label="Igreja/Ministério (opcional)"
            value={form.churchName}
            onChange={(e) => update('churchName', e.target.value)}
          />

          <label className="flex items-start gap-2 text-xs text-mist leading-relaxed"><input type="checkbox" required className="mt-0.5 accent-gold" /><span>Li e concordo com os <Link to="/termos" className="text-gold hover:underline">Termos de uso</Link> e a <Link to="/privacidade" className="text-gold hover:underline">Política de privacidade</Link>.</span></label>
          {error ? <p className="text-sm text-rose-soft" role="alert">{error}</p> : null}

          <Button type="submit" isLoading={isLoading} className="w-full">
            Criar conta
          </Button>
        </form>

        <p className="text-center text-sm text-mist mt-6">
          Já tem conta?{' '}
          <Link to="/login" className="text-gold hover:underline">
            Entrar
          </Link>
        </p>
      </div>
    </div>
  );
}
