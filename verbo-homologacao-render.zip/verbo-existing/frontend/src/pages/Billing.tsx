import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { BillingCycle, BillingStatus, createCheckout, getBillingStatus, manageSubscription } from '../api/billing.api';
import { AppLayout } from '../components/layout/AppLayout';
import { Button } from '../components/ui/Button';
import { getApiErrorMessage } from '../hooks/useApiError';

const FEATURES = {
  FREE: ['3 gerações por mês', 'Templates Iluminura e Essencial', 'Exportação com marca Verbo', 'Planos de leitura e oração'],
  PRO: ['Até 300 gerações por mês', 'Todos os templates', 'Exportação sem marca-d’água', 'PNG e PDF em alta resolução'],
  CHURCH: ['Até 1.000 gerações por mês', 'Todos os templates', 'Logo da igreja ou projeto', 'Exportação sem marca-d’água'],
};

export function Billing() {
  const [params] = useSearchParams();
  const [data, setData] = useState<BillingStatus | null>(null);
  const [cycle, setCycle] = useState<BillingCycle>('MONTHLY');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState(params.get('retorno') ? 'Pagamento recebido. Aguardando confirmação segura do Mercado Pago.' : '');

  useEffect(() => { void load(); }, []);
  async function load() {
    try { setData(await getBillingStatus()); }
    catch (caught) { setError(getApiErrorMessage(caught, 'Não foi possível carregar os planos.')); }
  }

  async function subscribe(plan: 'PRO' | 'CHURCH') {
    setBusy(plan); setError(''); setMessage('');
    try {
      const checkout = await createCheckout(plan, cycle);
      window.location.href = checkout.checkoutUrl;
    } catch (caught) { setError(getApiErrorMessage(caught, 'Não foi possível abrir o checkout.')); setBusy(''); }
  }

  async function manage(action: 'pause' | 'resume' | 'cancel') {
    if (action === 'cancel' && !window.confirm('Deseja cancelar a assinatura? Seu acesso poderá permanecer até o fim do período informado pelo provedor.')) return;
    setBusy(action); setError(''); setMessage('');
    try {
      const response = await manageSubscription(action);
      setMessage(response.message);
      await load();
    } catch (caught) { setError(getApiErrorMessage(caught, 'Não foi possível alterar a assinatura.')); }
    finally { setBusy(''); }
  }

  const percentage = data ? Math.min(100, Math.round((data.usage.used / data.usage.limit) * 100)) : 0;
  return <AppLayout title="Planos e assinatura">
    <header className="text-center max-w-2xl mx-auto mb-8 -mt-2"><p className="font-mono text-[10px] uppercase tracking-widest text-gold">Planos do Verbo</p><h2 className="font-display text-4xl text-paper mt-2">Escolha o ritmo da sua criação.</h2><p className="text-sm text-mist mt-3">Comece gratuitamente e assine quando o Verbo fizer sentido em sua rotina.</p></header>

    {error ? <p className="max-w-3xl mx-auto rounded-lg border border-rose/30 bg-rose/10 p-3 text-sm text-rose-soft mb-5">{error}</p> : null}
    {message ? <p className="max-w-3xl mx-auto rounded-lg border border-sage/30 bg-sage/10 p-3 text-sm text-sage-soft mb-5">{message}</p> : null}

    {data ? <>
      <section className="card max-w-3xl mx-auto mb-7"><div className="flex flex-wrap justify-between gap-4"><div><p className="text-xs text-mist">Plano atual</p><p className="font-display text-2xl text-paper">{data.entitlements.name}</p></div><div className="text-right"><p className="text-xs text-mist">Uso neste mês</p><p className="text-sm text-paper">{data.usage.used} de {data.usage.limit} gerações</p></div></div><div className="h-2 bg-white/10 rounded-full overflow-hidden mt-4"><div className="h-full bg-gold rounded-full" style={{ width: `${percentage}%` }} /></div>
        {data.subscription ? <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-white/5"><span className="text-xs text-mist">Assinatura: <strong className="text-paper">{statusLabel(data.subscription.status)}</strong></span>{data.subscription.status === 'ACTIVE' ? <><button className="btn-secondary !py-1.5 !px-3 text-xs" onClick={() => manage('pause')} disabled={Boolean(busy)}>Pausar</button><button className="rounded-full border border-rose/30 text-rose-soft px-3 py-1.5 text-xs" onClick={() => manage('cancel')} disabled={Boolean(busy)}>Cancelar</button></> : null}{data.subscription.status === 'PAUSED' ? <button className="btn-primary !py-1.5 !px-3 text-xs" onClick={() => manage('resume')} disabled={Boolean(busy)}>Retomar</button> : null}{data.subscription.status === 'PENDING' && data.subscription.checkoutUrl ? <a className="btn-primary !py-1.5 !px-3 text-xs" href={data.subscription.checkoutUrl}>Continuar pagamento</a> : null}</div> : null}
      </section>

      <div className="flex justify-center mb-7"><div className="inline-flex rounded-full border border-white/10 bg-night-soft p-1"><button onClick={() => setCycle('MONTHLY')} className={`rounded-full px-5 py-2 text-sm ${cycle === 'MONTHLY' ? 'bg-gold text-ink' : 'text-mist'}`}>Mensal</button><button onClick={() => setCycle('ANNUAL')} className={`rounded-full px-5 py-2 text-sm ${cycle === 'ANNUAL' ? 'bg-gold text-ink' : 'text-mist'}`}>Anual · economize</button></div></div>

      <div className="grid lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
        {(['FREE', 'PRO', 'CHURCH'] as const).map((plan) => {
          const item = data.catalog[plan];
          const current = data.plan === plan;
          const amount = cycle === 'MONTHLY' ? item.monthlyPrice : item.annualPrice;
          return <article key={plan} className={`card flex flex-col ${plan === 'PRO' ? 'border-gold/50 shadow-card' : ''}`}><div className="flex justify-between"><div><h3 className="font-display text-2xl text-paper">{item.name}</h3><p className="text-xs text-mist mt-1">{plan === 'FREE' ? 'Para conhecer o Verbo.' : plan === 'PRO' ? 'Para criadores e líderes.' : 'Para comunicação de igreja.'}</p></div>{plan === 'PRO' ? <span className="rounded-full bg-gold/15 text-gold text-[10px] px-2 py-1 h-fit">POPULAR</span> : null}</div><p className="font-display text-4xl text-paper mt-6">{amount ? formatMoney(amount) : 'R$ 0'} {amount ? <span className="font-body text-xs text-mist">/{cycle === 'MONTHLY' ? 'mês' : 'ano'}</span> : null}</p>{cycle === 'ANNUAL' && amount ? <p className="text-[10px] text-sage-soft mt-1">equivale a {formatMoney(amount / 12)}/mês</p> : null}<ul className="space-y-3 my-6 flex-1">{FEATURES[plan].map((feature) => <li className="flex gap-2 text-sm text-mist" key={feature}><span className="text-sage-soft">✓</span>{feature}</li>)}</ul>{current ? <button className="btn-secondary w-full" disabled>Plano atual</button> : plan === 'FREE' ? <button className="btn-secondary w-full" disabled>Gratuito</button> : <Button className="w-full" onClick={() => subscribe(plan)} isLoading={busy === plan} disabled={!data.billingConfigured}>Assinar {item.name}</Button>}</article>;
        })}
      </div>
      {!data.billingConfigured ? <p className="max-w-3xl mx-auto text-center text-xs text-gold mt-5">Checkout em modo de configuração. Adicione as credenciais do Mercado Pago no backend para liberar assinaturas.</p> : null}
    </> : <div className="card max-w-3xl mx-auto text-center py-12"><p className="text-mist">Carregando planos...</p></div>}
  </AppLayout>;
}

function formatMoney(value: number) { return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value); }
function statusLabel(status: NonNullable<BillingStatus['subscription']>['status']) { return ({ PENDING: 'aguardando pagamento', ACTIVE: 'ativa', PAUSED: 'pausada', CANCELLED: 'cancelada', EXPIRED: 'expirada' } as const)[status]; }
