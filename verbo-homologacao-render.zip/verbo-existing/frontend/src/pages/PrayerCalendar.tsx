import { FormEvent, useEffect, useState } from 'react';
import { AppLayout } from '../components/layout/AppLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { createPrayer, deletePrayer, listPrayers, Prayer, updatePrayer } from '../api/prayer.api';
import { getApiErrorMessage } from '../hooks/useApiError';

export function PrayerCalendar() {
  const [prayers, setPrayers] = useState<Prayer[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    listPrayers()
      .then((items) => { if (active) setPrayers(items); })
      .catch((err) => { if (active) setError(getApiErrorMessage(err, 'Não foi possível carregar os pedidos.')); });
    return () => { active = false; };
  }, []);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setIsSaving(true);
    setError('');
    try {
      const prayer = await createPrayer({ title, description: description || undefined });
      setPrayers((prev) => [prayer, ...prev]);
      setTitle('');
      setDescription('');
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível salvar o pedido de oração.'));
    } finally {
      setIsSaving(false);
    }
  }

  async function toggleAnswered(prayer: Prayer) {
    try {
      const updated = await updatePrayer(prayer.id, { isAnswered: !prayer.isAnswered });
      setPrayers((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível atualizar o pedido.'));
    }
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Excluir este pedido de oração?')) return;
    try {
      await deletePrayer(id);
      setPrayers((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível excluir o pedido.'));
    }
  }

  const pending = prayers.filter((p) => !p.isAnswered);
  const answered = prayers.filter((p) => p.isAnswered);

  return (
    <AppLayout title="Calendário de Oração">
      <div className="grid lg:grid-cols-[340px_1fr] gap-6">
        <Card className="h-fit lg:sticky lg:top-6">
          <h2 className="font-display text-lg text-paper mb-4">Novo pedido de oração</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input label="Título" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex: Saúde da minha família" />
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-mist">Detalhes (opcional)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="input-field resize-none"
              />
            </div>
            {error ? <p className="text-sm text-rose-soft" role="alert">{error}</p> : null}
            <Button type="submit" isLoading={isSaving} className="w-full">
              Adicionar ao calendário
            </Button>
          </form>
        </Card>

        <div className="space-y-8 min-w-0">
          <section>
            <h2 className="font-display text-lg text-paper mb-3">
              Orando ({pending.length})
            </h2>
            {pending.length === 0 ? (
              <Card className="text-center py-8">
                <p className="text-mist text-sm">Nenhum pedido pendente. Adicione um ao lado.</p>
              </Card>
            ) : (
              <div className="space-y-2">
                {pending.map((prayer) => (
                  <PrayerItem key={prayer.id} prayer={prayer} onToggle={toggleAnswered} onDelete={handleDelete} />
                ))}
              </div>
            )}
          </section>

          {answered.length > 0 && (
            <section>
              <h2 className="font-display text-lg text-paper mb-3">Respondidas ({answered.length})</h2>
              <div className="space-y-2">
                {answered.map((prayer) => (
                  <PrayerItem key={prayer.id} prayer={prayer} onToggle={toggleAnswered} onDelete={handleDelete} />
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </AppLayout>
  );
}

function PrayerItem({
  prayer,
  onToggle,
  onDelete,
}: {
  prayer: Prayer;
  onToggle: (p: Prayer) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="flex items-start gap-3 bg-night-soft border border-white/5 rounded-lg px-4 py-3">
      <button
        onClick={() => onToggle(prayer)}
        aria-label={prayer.isAnswered ? 'Marcar como pendente' : 'Marcar como respondida'}
        className={`mt-0.5 h-5 w-5 shrink-0 rounded-full border-2 flex items-center justify-center transition-colors ${
          prayer.isAnswered ? 'bg-sage border-sage' : 'border-mist/40 hover:border-gold'
        }`}
      >
        {prayer.isAnswered && (
          <svg viewBox="0 0 24 24" className="h-3 w-3 text-night" fill="none" stroke="currentColor" strokeWidth="3">
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        )}
      </button>

      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium ${prayer.isAnswered ? 'text-mist line-through' : 'text-paper'}`}>
          {prayer.title}
        </p>
        {prayer.description ? <p className="text-xs text-mist mt-0.5">{prayer.description}</p> : null}
      </div>

      <button
        onClick={() => onDelete(prayer.id)}
        aria-label="Excluir pedido de oração"
        className="text-mist hover:text-rose-soft transition-colors shrink-0"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 7h14M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m-8 0 1 12a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1l1-12" />
        </svg>
      </button>
    </div>
  );
}
