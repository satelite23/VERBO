import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { useAuth } from '../hooks/useAuth';
import { getApiErrorMessage } from '../hooks/useApiError';

export function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      const loggedUser = await login(email, password);
      navigate(loggedUser.onboardingCompleted ? '/app' : '/onboarding');
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível entrar. Verifique seus dados.'));
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-night flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="font-display text-4xl text-paper">
            Verbo<span className="text-gold">.</span>
          </h1>
          <p className="text-mist mt-2">Entre para continuar criando conteúdo que edifica.</p>
        </div>

        <form onSubmit={handleSubmit} className="card space-y-5">
          <Input
            label="E-mail"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            label="Senha"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <div className="text-right -mt-2"><Link to="/esqueci-senha" className="text-xs text-gold hover:underline">Esqueci minha senha</Link></div>
          {error ? <p className="text-sm text-rose-soft" role="alert">{error}</p> : null}

          <Button type="submit" isLoading={isLoading} className="w-full">
            Entrar
          </Button>
        </form>

        <p className="text-center text-sm text-mist mt-6">
          Ainda não tem conta?{' '}
          <Link to="/registrar" className="text-gold hover:underline">
            Criar conta
          </Link>
        </p>
      </div>
    </div>
  );
}
