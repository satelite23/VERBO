import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { BibleVersion, ProfileType, UserGoal } from '../api/auth.api';
import { generateDevotional, type Devotional } from '../api/devotional.api';
import { VerseCard } from '../components/ui/VerseCard';
import { useAuth } from '../hooks/useAuth';
import { getApiErrorMessage } from '../hooks/useApiError';

const PROFILE_OPTIONS: Array<{ id: ProfileType; title: string; text: string }> = [
  { id: 'PERSONAL', title: 'Rotina individual', text: 'Devocionais, oração e leitura para sua caminhada.' },
  { id: 'CHURCH', title: 'Comunicação de igreja', text: 'Conteúdo para redes sociais e planejamento da equipe.' },
  { id: 'CREATOR', title: 'Criação de conteúdo', text: 'Ideias e formatos para comunicar com constância.' },
  { id: 'MINISTRY', title: 'Liderança ou ministério', text: 'Materiais para células, grupos e ministérios.' },
];
const GOALS: Array<{ id: UserGoal; label: string }> = [
  { id: 'DEVOTIONALS', label: 'Criar devocionais' },
  { id: 'POSTS', label: 'Preparar posts' },
  { id: 'PRAYER', label: 'Organizar orações' },
  { id: 'READING', label: 'Manter um plano de leitura' },
];
const VERSIONS: Array<{ id: BibleVersion; label: string }> = [
  { id: 'ARC', label: 'Almeida Revista e Corrigida (ARC)' },
  { id: 'ARA', label: 'Almeida Revista e Atualizada (ARA)' },
  { id: 'NVI', label: 'Nova Versão Internacional (NVI)' },
  { id: 'NVT', label: 'Nova Versão Transformadora (NVT)' },
  { id: 'NTLH', label: 'Nova Tradução na Linguagem de Hoje (NTLH)' },
];

export function Onboarding() {
  const navigate = useNavigate();
  const { user, updateProfile } = useAuth();
  const [step, setStep] = useState(0);
  const [profileType, setProfileType] = useState<ProfileType>(user?.profileType ?? 'PERSONAL');
  const [bibleVersion, setBibleVersion] = useState<BibleVersion>(user?.bibleVersion ?? 'ARC');
  const [goals, setGoals] = useState<UserGoal[]>(user?.goals?.length ? user.goals : ['DEVOTIONALS']);
  const [devotional, setDevotional] = useState<Devotional | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  function toggleGoal(goal: UserGoal) {
    setGoals((current) => current.includes(goal) ? current.filter((item) => item !== goal) : [...current, goal]);
  }

  async function finishProfile() {
    setIsSaving(true);
    setError('');
    setStep(2);
    try {
      await updateProfile({ profileType, bibleVersion, goals, onboardingCompleted: true });
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível salvar seu perfil. Tente novamente.'));
      setStep(1);
      setIsSaving(false);
      return;
    }

    try {
      const firstDevotional = await generateDevotional('esperanca');
      setDevotional(firstDevotional);
    } catch (err) {
      setError(getApiErrorMessage(err, 'Seu perfil foi salvo, mas não foi possível preparar o devocional agora.'));
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <main className="min-h-screen bg-night px-4 py-8 sm:py-12 grid place-items-center">
      <div className="w-full max-w-3xl">
        <div className="flex items-center justify-between mb-8">
          <span className="font-display text-2xl text-paper">Verbo<span className="text-gold">.</span></span>
          <div className="flex gap-2">{[0, 1, 2].map((item) => <span key={item} className={`w-9 h-1 rounded-full ${item <= step ? 'bg-gold' : 'bg-white/10'}`} />)}</div>
        </div>

        <section className="card !p-6 sm:!p-9">
          {step === 0 ? <>
            <p className="font-mono text-[10px] uppercase tracking-widest text-gold mb-3">Passo 1 de 3</p>
            <h1 className="font-display text-3xl sm:text-4xl text-paper">Como você pretende usar o Verbo?</h1>
            <p className="text-mist mt-2 mb-7">Isso nos ajuda a priorizar formatos e sugestões relevantes para sua rotina.</p>
            <div className="grid sm:grid-cols-2 gap-3">{PROFILE_OPTIONS.map((option) => <button key={option.id} onClick={() => setProfileType(option.id)} className={`text-left rounded-xl border p-4 transition-colors ${profileType === option.id ? 'border-gold bg-gold/10' : 'border-white/10 bg-night-softer hover:border-gold/50'}`}><strong className="text-paper block">{option.title}</strong><span className="text-xs text-mist leading-relaxed block mt-1">{option.text}</span></button>)}</div>
            <div className="flex justify-end mt-7"><button className="btn-primary" onClick={() => setStep(1)}>Continuar <span>→</span></button></div>
          </> : null}

          {step === 1 ? <>
            <p className="font-mono text-[10px] uppercase tracking-widest text-gold mb-3">Passo 2 de 3</p>
            <h1 className="font-display text-3xl sm:text-4xl text-paper">Personalize seu ponto de partida.</h1>
            <p className="text-mist mt-2 mb-7">Escolha sua tradução preferida e o que deseja fazer primeiro.</p>
            <label className="text-sm font-medium text-mist block mb-2">Tradução bíblica preferida</label>
            <select className="input-field" value={bibleVersion} onChange={(event) => setBibleVersion(event.target.value as BibleVersion)}>{VERSIONS.map((version) => <option value={version.id} key={version.id}>{version.label}</option>)}</select>
            <p className="text-[11px] text-mist/70 mt-2">A preferência será usada quando a fonte bíblica licenciada estiver conectada. Durante o beta, confira sempre o texto exibido.</p>
            <div className="mt-7"><label className="text-sm font-medium text-mist block mb-3">Seus objetivos</label><div className="grid sm:grid-cols-2 gap-3">{GOALS.map((goal) => <button key={goal.id} onClick={() => toggleGoal(goal.id)} className={`text-left rounded-xl border p-4 transition-colors ${goals.includes(goal.id) ? 'border-gold bg-gold/10 text-paper' : 'border-white/10 bg-night-softer text-mist'}`}><span className="mr-2 text-sage-soft">{goals.includes(goal.id) ? '✓' : '○'}</span>{goal.label}</button>)}</div></div>
            {error ? <p className="text-sm text-rose-soft mt-5" role="alert">{error}</p> : null}
            <div className="flex justify-between mt-7"><button className="btn-secondary" onClick={() => setStep(0)}>Voltar</button><button className="btn-primary" disabled={!goals.length} onClick={finishProfile}>Preparar meu primeiro devocional</button></div>
          </> : null}

          {step === 2 ? <>
            <p className="font-mono text-[10px] uppercase tracking-widest text-gold mb-3">Seu primeiro conteúdo</p>
            {isSaving ? <div className="text-center py-16"><span className="inline-block w-9 h-9 rounded-full border-2 border-gold border-t-transparent animate-spin" /><h2 className="font-display text-2xl text-paper mt-5">Preparando um devocional sobre esperança...</h2><p className="text-sm text-mist mt-2">Seu perfil já está sendo organizado.</p></div> : devotional ? <>
              <h1 className="font-display text-3xl sm:text-4xl text-paper">Prontinho — este é o seu primeiro devocional.</h1>
              <p className="text-mist mt-2 mb-6">Leia, revise e depois experimente criar um com o tema da sua semana.</p>
              <VerseCard reference={devotional.verseRef} text={devotional.verseText} />
              <h2 className="font-display text-2xl text-paper mt-6">{devotional.title}</h2>
              <p className="text-paper/85 leading-relaxed mt-3">{devotional.reflection}</p>
              <div className="flex justify-end mt-7"><button className="btn-primary" onClick={() => navigate('/app')}>Entrar no Verbo <span>→</span></button></div>
            </> : <div className="py-10 text-center"><p className="text-rose-soft">{error}</p><button className="btn-primary mt-5" onClick={() => navigate('/app')}>Entrar no Verbo</button></div>}
          </> : null}
        </section>
      </div>
    </main>
  );
}
