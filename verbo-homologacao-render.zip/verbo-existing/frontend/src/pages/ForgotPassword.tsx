import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { forgotPasswordRequest } from '../api/auth.api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { getApiErrorMessage } from '../hooks/useApiError';

export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [developmentUrl, setDevelopmentUrl] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true); setError(''); setDevelopmentUrl('');
    try {
      const response = await forgotPasswordRequest(email);
      setMessage(response.message);
      setDevelopmentUrl(response.data?.developmentResetUrl ?? '');
    } catch (err) {
      setError(getApiErrorMessage(err, 'Não foi possível enviar as instruções.'));
    } finally { setLoading(false); }
  }

  return <AuthShell title="Recuperar senha" description="Informe seu e-mail para receber um link seguro.">
    {message ? <div className="rounded-xl border border-sage/30 bg-sage/10 p-4 text-sm text-sage-soft leading-relaxed">{message}{developmentUrl ? <a className="block text-gold underline mt-3 break-all" href={developmentUrl}>Abrir link de desenvolvimento</a> : null}</div> : <form onSubmit={submit} className="space-y-5"><Input label="E-mail" type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} />{error ? <p className="text-sm text-rose-soft">{error}</p> : null}<Button type="submit" isLoading={loading} className="w-full">Enviar instruções</Button></form>}
    <Link to="/login" className="block text-center text-sm text-gold mt-6 hover:underline">Voltar para entrar</Link>
  </AuthShell>;
}

export function AuthShell({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return <main className="min-h-screen bg-night grid lg:grid-cols-2"><section className="hidden lg:flex bg-[#0B0E1C] p-14 flex-col justify-between"><Link to="/" className="font-display text-2xl text-paper">Verbo<span className="text-gold">.</span></Link><div><blockquote className="font-display italic text-4xl text-paper leading-snug">“Lâmpada para os meus pés é a tua palavra e luz para o meu caminho.”</blockquote><p className="font-mono text-xs tracking-widest text-gold uppercase mt-5">Salmos 119:105</p></div><span className="text-xs text-mist/60">Um espaço para criar com calma e propósito.</span></section><section className="grid place-items-center px-5 py-12"><div className="w-full max-w-md"><Link to="/" className="lg:hidden font-display text-2xl text-paper block mb-10">Verbo<span className="text-gold">.</span></Link><p className="font-mono text-[10px] tracking-widest text-gold uppercase mb-3">Acesso à sua conta</p><h1 className="font-display text-4xl text-paper">{title}</h1><p className="text-mist mt-2 mb-8">{description}</p><div className="card">{children}</div></div></section></main>;
}
