import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { ForgotPassword } from './pages/ForgotPassword';
import { ResetPassword } from './pages/ResetPassword';
import { Onboarding } from './pages/Onboarding';
import { Dashboard } from './pages/Dashboard';
import { DevotionalGenerator } from './pages/DevotionalGenerator';
import { PostGenerator } from './pages/PostGenerator';
import { PrayerCalendar } from './pages/PrayerCalendar';
import { ReadingPlanPage } from './pages/ReadingPlan';
import { Settings } from './pages/Settings';
import { Privacy, Terms } from './pages/Legal';
import { Billing } from './pages/Billing';

function Private({ children }: { children: React.ReactNode }) {
  return <ProtectedRoute>{children}</ProtectedRoute>;
}

export function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/registrar" element={<Register />} />
          <Route path="/esqueci-senha" element={<ForgotPassword />} />
          <Route path="/redefinir-senha" element={<ResetPassword />} />
          <Route path="/termos" element={<Terms />} />
          <Route path="/privacidade" element={<Privacy />} />
          <Route path="/onboarding" element={<ProtectedRoute requireOnboarding={false}><Onboarding /></ProtectedRoute>} />

          <Route path="/app" element={<Private><Dashboard /></Private>} />
          <Route path="/app/devocionais" element={<Private><DevotionalGenerator /></Private>} />
          <Route path="/app/posts" element={<Private><PostGenerator /></Private>} />
          <Route path="/app/oracao" element={<Private><PrayerCalendar /></Private>} />
          <Route path="/app/leitura" element={<Private><ReadingPlanPage /></Private>} />
          <Route path="/app/configuracoes" element={<Private><Settings /></Private>} />
          <Route path="/app/plano" element={<Private><Billing /></Private>} />

          <Route path="/devocionais" element={<Navigate to="/app/devocionais" replace />} />
          <Route path="/posts" element={<Navigate to="/app/posts" replace />} />
          <Route path="/oracao" element={<Navigate to="/app/oracao" replace />} />
          <Route path="/leitura" element={<Navigate to="/app/leitura" replace />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
