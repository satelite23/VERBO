# QA ponta a ponta — Verbo

**Data:** 14 de julho de 2026  
**Resultado:** aprovado no ambiente disponível

## Ambiente executado

O sandbox não oferece Docker, então o teste equivalente foi executado com:

- Debian 13.
- Node.js 20.
- PostgreSQL 17 local e isolado.
- Banco `verbo_e2e` criado exclusivamente para QA.
- Backend compilado e iniciado em modo de teste.
- Frontend compilado e servido pelo Vite Preview.
- IA, Bíblia e pagamentos em modo local/desconfigurado, sem credenciais reais.

## Banco de dados

As cinco migrações foram aplicadas em um banco vazio:

1. Schema inicial.
2. Perfil, onboarding e recuperação de senha.
3. Proveniência de Bíblia e IA.
4. Editor visual.
5. Planos e assinaturas.

Resultado:

- 5/5 migrações concluídas.
- Seed idempotente executado.
- 3 planos criados.
- 127 dias de leitura criados: 90 + 30 + 7.

## Fluxo HTTP real

O script `backend/scripts/e2e-smoke.mjs` executa 12 etapas e 20 asserções:

1. Saúde da API.
2. Cadastro e bloqueio de elevação para `CHURCH_ADMIN`.
3. Onboarding, perfil e tradução bíblica.
4. Geração e edição de devocional.
5. Geração e edição de post.
6. Bloqueio de template premium e logo para plano Gratuito.
7. Criação, resposta, listagem e exclusão de oração.
8. Listagem de planos, matrícula e check-in idempotente.
9. Catálogo do plano Gratuito e checkout desabilitado sem credenciais.
10. Limite de três gerações aplicado pelo backend.
11. Recuperação de senha e revogação do JWT anterior.
12. Login com nova senha, isolamento dos dados e exclusão da conta.

**Resultado atualizado esperado:** `QA E2E aprovado: 20 asserções.`

## Integridade e cascata

Depois da exclusão da conta de QA, o PostgreSQL confirmou:

| Tabela | Registros de usuário restantes |
|---|---:|
| Usuários | 0 |
| Devocionais | 0 |
| Posts | 0 |
| Pedidos de oração | 0 |

Os dados de sistema permaneceram:

- Planos: 3.
- Dias de leitura: 127.
- Migrações aplicadas: 5.

Isso confirma a exclusão em cascata dos dados pessoais sem apagar o catálogo do produto.

## Frontend

- Instalação limpa com `npm ci`.
- Build de produção aprovado.
- Página raiz servida com sucesso.
- Rota SPA `/app/posts` retornou o shell do React corretamente.
- Assets de exportação permanecem separados por carregamento dinâmico.

## Testes automatizados existentes

Além do smoke test real:

- 26/26 testes Vitest/Supertest aprovados.
- Lint do backend aprovado.
- Typecheck do backend aprovado.
- Build do backend aprovado.
- Lint do frontend aprovado.
- Typecheck do frontend aprovado.
- Build do frontend aprovado.
- Auditorias npm sem vulnerabilidades conhecidas.

## Scripts adicionados

### Rodar QA local

```bash
cd backend
DATABASE_URL='postgresql://usuario:senha@localhost:5432/verbo_qa?schema=public' \
JWT_SECRET='um-segredo-com-mais-de-32-caracteres' \
npm run test:e2e
```

O script:

- Instala dependências.
- Gera o Prisma Client.
- Aplica migrações.
- Executa seed.
- Compila o backend.
- Inicia a API temporariamente.
- Executa o smoke test.
- Encerra o servidor ao terminar.

## Limitações restantes

Não foram testados nesta rodada:

- Construção real das imagens Docker, porque o sandbox não tem daemon Docker.
- Checkout sandbox do Mercado Pago, pois não foram fornecidas credenciais.
- Webhook público real, pois não há domínio de homologação.
- API.Bible real e traduções licenciadas.
- Provedores externos de IA.
- Envio real pelo Resend.
- Exportação visual PNG/PDF em navegador gráfico; o bundle e as rotas foram validados, mas falta inspeção manual do arquivo.

## Próxima etapa recomendada

**Homologação online**, com banco gerenciado e credenciais de teste:

1. Definir provedor de deploy.
2. Criar PostgreSQL de homologação.
3. Configurar domínio e HTTPS.
4. Executar migrações.
5. Configurar Mercado Pago sandbox e webhook público.
6. Conectar um provedor de IA e uma tradução licenciada.
7. Realizar inspeção visual no navegador e em celular.
8. Registrar evidências e aprovar o checklist de lançamento.
