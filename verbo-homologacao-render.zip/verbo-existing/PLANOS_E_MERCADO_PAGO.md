# Planos e Mercado Pago — Verbo

> **Atualização:** o QA real com PostgreSQL também foi concluído. Consulte `QA_PONTA_A_PONTA.md`.

**Data:** 14 de julho de 2026  
**Status:** implementação concluída; ativação real depende de credenciais sandbox/produção

## Catálogo inicial

| Plano | Gerações/mês | Templates | Marca-d’água | Logo próprio |
|---|---:|---|---|---|
| Gratuito | 3 | Iluminura e Essencial | Sim | Não |
| Pro | 300 | Todos | Não | Não |
| Igreja | 1.000 | Todos | Não | Sim |

### Preços padrão

- Pro mensal: R$ 29,90.
- Pro anual: R$ 251,16.
- Igreja mensal: R$ 99,90.
- Igreja anual: R$ 839,16.

Todos os valores e limites são configuráveis por variáveis de ambiente.

## Fluxo de assinatura

```text
Usuário autenticado escolhe plano/ciclo
                  ↓
Backend cria assinatura PENDING no PostgreSQL
                  ↓
Backend chama POST /preapproval no Mercado Pago
                  ↓
Usuário é redirecionado ao init_point
                  ↓
Mercado Pago envia webhook assinado
                  ↓
Backend valida HMAC e consulta /preapproval/{id}
                  ↓
Assinatura local muda para ACTIVE/PAUSED/CANCELLED
                  ↓
Permissões e limites passam a refletir o plano
```

## Segurança

- Access token fica somente no backend.
- Checkout exige usuário autenticado.
- Cada tentativa recebe referência externa aleatória.
- Requisição usa chave de idempotência.
- Webhook valida `x-signature` com HMAC SHA-256.
- Manifesto inclui `data.id`, `x-request-id` e timestamp.
- Após validar o webhook, o backend consulta a assinatura diretamente no Mercado Pago.
- Referência externa retornada precisa corresponder ao registro local.
- Eventos são registrados com chave única para evitar processamento duplicado.
- Produção rejeita webhook se o segredo não estiver configurado.

## Gerenciamento

- Pausar assinatura.
- Retomar assinatura.
- Cancelar assinatura.
- Continuar checkout pendente.
- Acompanhar estado atual e período.
- Preservar acesso cancelado até o fim do período quando a data estiver disponível.

## Integração no produto

- Página `/app/plano` com preços mensais e anuais.
- Barra de consumo mensal.
- Estado da assinatura.
- Checkout desabilitado quando o ambiente não tem credenciais.
- Templates premium bloqueados no backend.
- Logo personalizado bloqueado fora do plano Igreja.
- Marca Verbo aplicada ao plano Gratuito durante exportação.
- Limite de geração calculado no backend, não apenas na interface.

## Endpoints

- `GET /api/billing/status`
- `POST /api/billing/checkout`
- `POST /api/billing/manage`
- `POST /api/webhooks/mercadopago`

## Configuração necessária

```env
MERCADO_PAGO_ACCESS_TOKEN=
MERCADO_PAGO_WEBHOOK_SECRET=
PRO_MONTHLY_CENTS=2990
PRO_ANNUAL_CENTS=25116
CHURCH_MONTHLY_CENTS=9990
CHURCH_ANNUAL_CENTS=83916
PRO_GENERATION_LIMIT=300
CHURCH_GENERATION_LIMIT=1000
```

No painel do Mercado Pago, cadastrar:

```text
https://seu-dominio.com/api/webhooks/mercadopago
```

Tópico: `subscription_preapproval`.

## Referências oficiais

- Criar assinatura: https://www.mercadopago.com.br/developers/pt/reference/subscriptions/_preapproval/post
- Webhooks e assinatura secreta: https://www.mercadopago.com.br/developers/pt/docs/checkout-api/additional-content/your-integrations/notifications/webhooks

## Testes

Foram validados:

- Regras dos três planos.
- Preços mensais e anuais.
- Restrições de template e logo.
- Payload de criação da assinatura.
- Cabeçalho de autorização.
- Recorrência mensal.
- Mapeamento de estados.
- Validação e rejeição de assinatura HMAC.

## Pendências externas

- Criar ou selecionar aplicação no Mercado Pago.
- Obter credenciais de teste.
- Configurar webhook público de homologação.
- Simular assinatura aprovada, pausada e cancelada.
- Confirmar política fiscal, reembolso e descrição comercial.
- Executar fluxo real com PostgreSQL e Docker.
