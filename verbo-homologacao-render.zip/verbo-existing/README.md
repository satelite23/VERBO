# Verbo — Gerador de Mensagens e Devocionais Bíblicos

Aplicação full stack para criar devocionais, posts para redes sociais, pedidos de oração e acompanhar planos de leitura bíblica.

> **Estado atual:** base estabilizada com adaptadores prontos para API.Bible, Anthropic, OpenAI e Gemini. Sem chaves, o aplicativo permanece funcional em modo local demonstrativo. Editor de imagem, pagamentos e recursos comerciais seguem para as próximas fases.

## Stack

| Camada | Tecnologia |
|---|---|
| Frontend | React 18, TypeScript, Vite 8, Tailwind CSS e React Router |
| Backend | Node.js 20, Express e TypeScript |
| Banco de dados | PostgreSQL 16 e Prisma ORM |
| Autenticação | JWT HS256 e bcrypt |
| Validação | Zod |
| Testes | Vitest e Supertest |
| Contêineres | Docker Compose, Node e Nginx |

## Funcionalidades disponíveis

- Landing page pública e páginas legais do beta.
- Cadastro, login e recuperação de senha.
- Onboarding por perfil, objetivo e tradução bíblica preferida.
- Dashboard com devocional recente, leitura, orações e atividade.
- Geração editorial configurável por modo local, Anthropic, OpenAI ou Gemini.
- Fonte bíblica configurável por modo demonstrativo ou API.Bible.
- Proveniência registrada em cada conteúdo: fonte, tradução, provedor, modelo e prompt.
- Edição, cópia e download de devocionais.
- Editor visual com quatro templates, paletas, tipografia, alinhamento e escala.
- Upload e redimensionamento de imagem de fundo e logo.
- Preview para Feed, Story e WhatsApp.
- Exportação em PNG de 1080 px e PDF.
- Histórico de devocionais e posts.
- Pedidos de oração e marcação como respondidos.
- Planos de leitura com leitura do dia, progresso, sequência e check-ins.
- Perfil, preferências e exclusão de conta.
- Planos Gratuito, Pro e Igreja com limites e recursos próprios.
- Checkout e recorrência pelo Mercado Pago.
- Webhook assinado, pausa, retomada e cancelamento.
- Marca-d’água e templates condicionados ao plano.
- Interface responsiva baseada no sistema visual Night, Parchment e Gold.

## Estrutura

```text
verbo-existing/
├── backend/
│   ├── prisma/
│   │   ├── migrations/          # Migração inicial versionada
│   │   ├── schema.prisma
│   │   └── seed.ts              # Planos bíblicos em ordem correta
│   ├── src/
│   │   ├── config/
│   │   ├── controllers/
│   │   ├── data/verses.json     # Somente demonstração
│   │   ├── middlewares/
│   │   ├── routes/
│   │   ├── services/
│   │   └── utils/
│   └── tests/
├── frontend/
│   ├── nginx.conf
│   └── src/
│       ├── api/
│       ├── components/
│       ├── context/
│       ├── hooks/
│       └── pages/
├── .env.example
└── docker-compose.yml
```

## Pré-requisitos

- Docker com Compose; ou
- Node.js 20.19 ou superior e PostgreSQL 16.

## Executar com Docker

1. Crie o arquivo de ambiente da raiz:

```bash
cp .env.example .env
```

2. Substitua obrigatoriamente no `.env`:

- `POSTGRES_PASSWORD`
- `JWT_SECRET` — mínimo de 32 caracteres

3. Inicie os serviços:

```bash
docker compose up --build
```

O backend aplica a migração e o seed automaticamente. Acesse:

- Aplicação: `http://localhost:5173`
- API: `http://localhost:4000/api`
- Saúde da API: `http://localhost:4000/api/health`

O frontend é compilado e servido pelo Nginx. Requisições para `/api` são encaminhadas ao backend.

## Execução manual

### Backend

```bash
cd backend
cp .env.example .env
# Ajuste DATABASE_URL e JWT_SECRET
npm install
npx prisma generate
npx prisma migrate deploy
npm run prisma:seed
npm run dev
```

API: `http://localhost:4000/api`.

### Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Aplicação: `http://localhost:5173`.

## Qualidade e validação

### Backend

```bash
cd backend
npm run lint
npm run typecheck
npm test
npm run build
npm audit
```

### Frontend

```bash
cd frontend
npm run lint
npm run typecheck
npm run build
npm audit
```

### Smoke test com PostgreSQL real

Use um banco exclusivo de QA:

```bash
cd backend
DATABASE_URL='postgresql://usuario:senha@localhost:5432/verbo_qa?schema=public' \
JWT_SECRET='um-segredo-com-mais-de-32-caracteres' \
npm run test:e2e
```

O script aplica migrações e seed, inicia a API temporariamente e valida 12 etapas do cadastro à exclusão da conta. Nunca aponte esse comando para um banco de produção.

A base possui 26 testes automatizados para:

- Datas e sequência no fuso `America/Sao_Paulo`.
- Distribuição dos capítulos nos planos de leitura.
- UUIDs dos planos padrão.
- Bloqueio de elevação de privilégio no cadastro público.
- Validação de senha.
- Proteção JWT e revogação por versão de sessão.
- Isolamento de listagens por usuário.
- Atualização segura de perfil sem alteração de papel administrativo.
- Contrato da API.Bible e limpeza do texto retornado.
- Saída estruturada da IA e fallback para conteúdo local.
- Rejeição de imagens SVG ou formatos não permitidos no editor.
- Regras e preços dos planos.
- Restrição de templates premium.
- Payload de criação da assinatura.
- Mapeamento de status do Mercado Pago.
- Assinatura HMAC e rejeição de webhook alterado.

## Endpoints principais

| Método | Rota | Descrição | Autenticação |
|---|---|---|---|
| GET | `/api/health` | Saúde da API | Não |
| POST | `/api/auth/register` | Cria uma conta `USER` | Não |
| POST | `/api/auth/login` | Autentica | Não |
| POST | `/api/auth/forgot-password` | Solicita recuperação de senha | Não |
| POST | `/api/auth/reset-password` | Define nova senha por token | Não |
| GET | `/api/auth/me` | Usuário atual | Sim |
| PATCH | `/api/auth/me` | Atualiza perfil e onboarding | Sim |
| DELETE | `/api/auth/me` | Exclui conta após confirmar senha | Sim |
| GET | `/api/devotionals/themes` | Temas disponíveis | Sim |
| POST | `/api/devotionals/generate` | Gera e salva devocional | Sim |
| GET | `/api/devotionals` | Histórico de devocionais | Sim |
| PATCH | `/api/devotionals/:id` | Edita devocional próprio | Sim |
| DELETE | `/api/devotionals/:id` | Exclui devocional próprio | Sim |
| POST | `/api/posts/generate` | Gera post | Sim |
| GET | `/api/posts` | Histórico de posts | Sim |
| PATCH | `/api/posts/:id` | Edita post próprio | Sim |
| DELETE | `/api/posts/:id` | Exclui post próprio | Sim |
| POST | `/api/prayers` | Cria pedido | Sim |
| GET | `/api/prayers` | Lista pedidos | Sim |
| PATCH | `/api/prayers/:id` | Edita ou marca como respondido | Sim |
| DELETE | `/api/prayers/:id` | Exclui pedido próprio | Sim |
| GET | `/api/reading-plans` | Lista planos | Sim |
| GET | `/api/reading-plans/mine` | Matrículas e check-ins | Sim |
| POST | `/api/reading-plans/enroll` | Inicia plano | Sim |
| POST | `/api/reading-plans/checkin` | Registra leitura do dia | Sim |
| GET | `/api/billing/status` | Plano, uso, catálogo e assinatura | Sim |
| POST | `/api/billing/checkout` | Cria checkout recorrente | Sim |
| POST | `/api/billing/manage` | Pausa, retoma ou cancela | Sim |
| POST | `/api/webhooks/mercadopago` | Recebe atualização assinada | Assinatura HMAC |

Rotas autenticadas usam `Authorization: Bearer <token>`.

## Segurança aplicada

- Contas públicas sempre recebem o papel `USER`.
- E-mails são normalizados antes do cadastro e login.
- Senhas exigem no mínimo oito caracteres e usam bcrypt com custo 12.
- JWT assinado com HS256, emissor e público definidos.
- Versão de sessão revoga tokens anteriores após redefinição de senha.
- Tokens de recuperação são aleatórios, armazenados apenas como hash e expiram em 30 minutos.
- `JWT_SECRET` curto bloqueia a inicialização em produção.
- Rate limit específico para login/cadastro e limite geral para a API.
- Helmet, CORS restrito, limite de corpo e validação Zod.
- Consultas de conteúdo filtram pelo usuário autenticado.
- Nginx serve o frontend de produção; o servidor de desenvolvimento do Vite não é exposto.
- Migrações Prisma estão versionadas.

### Risco conhecido de autenticação

O MVP ainda mantém o JWT no `localStorage`. Antes da publicação ampla, a autenticação deverá migrar para cookies `HttpOnly`, `Secure` e `SameSite`, com estratégia de renovação e revogação de sessão.

## Planos e Mercado Pago

O catálogo inicial contém:

- **Gratuito:** 3 gerações/mês, dois templates e marca Verbo.
- **Pro:** R$ 29,90/mês ou preço anual configurável, 300 gerações, todos os templates e sem marca-d’água.
- **Igreja:** R$ 99,90/mês ou preço anual configurável, 1.000 gerações, logo personalizado e sem marca-d’água.

Configure `MERCADO_PAGO_ACCESS_TOKEN` e `MERCADO_PAGO_WEBHOOK_SECRET`. No painel do Mercado Pago, registre a URL pública:

```text
https://seu-dominio.com/api/webhooks/mercadopago
```

Ative o tópico de assinaturas `subscription_preapproval`. O backend valida `x-signature`, consulta a assinatura diretamente no provedor e processa eventos de forma idempotente.

Preços e limites são configuráveis por variáveis de ambiente. Nenhum checkout é liberado sem o access token.

## Recuperação de senha

Configure `RESEND_API_KEY` e `EMAIL_FROM` para enviar links reais. Sem essa chave e fora de produção, a API devolve um link de desenvolvimento na própria resposta para permitir testes locais. Em produção, o token nunca é devolvido ao navegador.

Os tokens expiram em 30 minutos, ficam armazenados somente como hash e a redefinição incrementa a versão da sessão, revogando JWTs anteriores.

## Fonte bíblica

O backend suporta:

- `BIBLE_PROVIDER=local`: usa resumos demonstrativos e marca o conteúdo como `local-demo`/`DEMO`.
- `BIBLE_PROVIDER=api_bible`: busca a passagem pelo ID canônico no endpoint de passagens da API.Bible.

Para API.Bible, configure `BIBLE_API_KEY` e o ID liberado para cada tradução (`BIBLE_ID_ARC`, `BIBLE_ID_ARA`, `BIBLE_ID_NVI`, `BIBLE_ID_NVT`, `BIBLE_ID_NTLH`). Os IDs variam conforme as traduções disponíveis na conta e não são inventados pelo aplicativo.

Se a fonte externa falhar e `BIBLE_FALLBACK_TO_LOCAL=true`, o conteúdo continua com um aviso explícito de demonstração. Em modo estrito, a geração é interrompida.

## Inteligência artificial

Defina `AI_PROVIDER` como `local`, `anthropic`, `openai` ou `gemini` e configure a chave correspondente. O serviço:

1. Obtém primeiro a referência e o texto da camada bíblica.
2. Envia o texto verificado à IA apenas como contexto editorial.
3. Proíbe o modelo de criar ou alterar versículos.
4. Exige JSON e valida a saída com Zod.
5. Registra provedor, modelo e versão do prompt no conteúdo.
6. Usa templates locais se o provedor falhar e `AI_FALLBACK_TO_LOCAL=true`.

O limite inicial é controlado por `GENERATION_LIMIT_MONTHLY` e soma devocionais e posts do usuário no mês.

## Próximas fases

1. Armazenamento de imagens em R2/S3 para substituir Data URLs em escala.
2. Verificação de e-mail e migração para cookies seguros.
3. Notificações e analytics de produto.
4. QA com PostgreSQL/Docker e credenciais sandbox.
5. Deploy de homologação e checklist de publicação.
