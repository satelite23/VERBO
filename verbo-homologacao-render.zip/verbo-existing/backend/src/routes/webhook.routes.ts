import { Router } from 'express';
import { mercadoPagoWebhook } from '../controllers/mercado-pago-webhook.controller';

const router = Router();
router.post('/mercadopago', mercadoPagoWebhook);
export default router;
