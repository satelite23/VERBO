import { Router } from 'express';
import * as controller from '../controllers/devotional.controller';
import { authGuard } from '../middlewares/auth.middleware';

const router = Router();

router.use(authGuard);

router.get('/themes', controller.listThemes);
router.post('/generate', controller.generate);
router.get('/', controller.list);
router.get('/:id', controller.getOne);
router.patch('/:id', controller.update);
router.delete('/:id', controller.remove);

export default router;
