import { Router } from 'express';
import { authGuard } from '../middlewares/auth.middleware';
import * as controller from '../controllers/billing.controller';

const router = Router();
router.use(authGuard);
router.get('/status', controller.status);
router.post('/checkout', controller.checkout);
router.post('/manage', controller.manage);
export default router;
