import { Router } from 'express';
import authRoutes from './auth.routes';
import devotionalRoutes from './devotional.routes';
import postRoutes from './post.routes';
import prayerRoutes from './prayer.routes';
import readingPlanRoutes from './readingPlan.routes';
import billingRoutes from './billing.routes';
import webhookRoutes from './webhook.routes';
import { readiness } from '../controllers/system.controller';

const router = Router();

router.get('/health', (_req, res) => res.json({ success: true, message: 'API do Verbo no ar 🙏' }));
router.get('/ready', readiness);

router.use('/auth', authRoutes);
router.use('/devotionals', devotionalRoutes);
router.use('/posts', postRoutes);
router.use('/prayers', prayerRoutes);
router.use('/reading-plans', readingPlanRoutes);
router.use('/billing', billingRoutes);
router.use('/webhooks', webhookRoutes);

export default router;
