import { Router } from 'express';
import * as controller from '../controllers/post.controller';
import { authGuard } from '../middlewares/auth.middleware';

const router = Router();

router.use(authGuard);

router.post('/generate', controller.generate);
router.get('/', controller.list);
router.patch('/:id', controller.update);
router.delete('/:id', controller.remove);

export default router;
