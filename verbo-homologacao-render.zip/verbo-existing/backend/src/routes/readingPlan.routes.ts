import { Router } from 'express';
import * as controller from '../controllers/readingPlan.controller';
import { authGuard } from '../middlewares/auth.middleware';

const router = Router();

router.use(authGuard);

router.get('/', controller.listPlans);
router.get('/mine', controller.myEnrollments);
router.get('/:id', controller.getPlan);
router.post('/enroll', controller.enroll);
router.post('/checkin', controller.checkIn);

export default router;
