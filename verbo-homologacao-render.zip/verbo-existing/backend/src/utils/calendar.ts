export function localDateKey(date: Date, timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);

  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

export function dayDistance(previous: Date, current: Date, timeZone: string): number {
  const toOrdinal = (date: Date) => {
    const [year, month, day] = localDateKey(date, timeZone).split('-').map(Number);
    return Math.floor(Date.UTC(year, month - 1, day) / 86_400_000);
  };
  return toOrdinal(current) - toOrdinal(previous);
}

export function isNextLocalDay(previous: Date, current: Date, timeZone: string) {
  return dayDistance(previous, current, timeZone) === 1;
}
