import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { prisma } from '../config/db';
import { AppError } from '../utils/AppError';

export interface AuthPayload {
  id: string;
  email: string;
  role: 'USER' | 'CHURCH_ADMIN';
  sessionVersion: number;
}

declare global {
  // Express usa namespace para permitir module augmentation do Request.
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthPayload;
    }
  }
}

export async function authGuard(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return next(new AppError('Não autorizado. Faça login para continuar.', 401));
  }

  const token = header.slice('Bearer '.length).trim();
  try {
    const payload = jwt.verify(token, env.jwtSecret, {
      algorithms: ['HS256'],
      issuer: 'verbo-api',
      audience: 'verbo-app',
    }) as AuthPayload;

    const user = await prisma.user.findUnique({
      where: { id: payload.id },
      select: { id: true, email: true, role: true, sessionVersion: true },
    });
    if (!user || user.sessionVersion !== payload.sessionVersion) {
      return next(new AppError('Sessão revogada. Faça login novamente.', 401));
    }

    req.user = user;
    return next();
  } catch (error) {
    if (error instanceof AppError) return next(error);
    return next(new AppError('Sessão inválida ou expirada. Faça login novamente.', 401));
  }
}

/** Restringe uma rota a determinados papéis. */
export function requireRole(...roles: AuthPayload['role'][]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(new AppError('Você não tem permissão para essa ação.', 403));
    }
    return next();
  };
}
