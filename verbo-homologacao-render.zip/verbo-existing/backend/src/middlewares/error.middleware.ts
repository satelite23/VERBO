import { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { AppError } from '../utils/AppError';
import { env } from '../config/env';

export function notFoundHandler(req: Request, _res: Response, next: NextFunction) {
  next(new AppError(`Rota não encontrada: ${req.method} ${req.originalUrl}`, 404));
}

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  // Erros de validação do Zod
  if (err instanceof ZodError) {
    return res.status(422).json({
      success: false,
      message: 'Dados inválidos.',
      errors: err.issues.map((issue) => ({
        campo: issue.path.join('.'),
        mensagem: issue.message,
      })),
    });
  }

  // Erros de negócio conhecidos (AppError)
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      success: false,
      message: err.message,
    });
  }

  // Erro de e-mail duplicado do Prisma
  if (typeof err === 'object' && err !== null && 'code' in err && (err as { code: string }).code === 'P2002') {
    return res.status(409).json({
      success: false,
      message: 'Já existe um registro com esses dados (ex: e-mail já cadastrado).',
    });
  }

  // Erro não tratado — não vaza detalhes internos em produção
  console.error('Erro inesperado:', err);
  return res.status(500).json({
    success: false,
    message: 'Erro interno do servidor. Tente novamente mais tarde.',
    ...(env.isProd ? {} : { detalhe: err instanceof Error ? err.message : String(err) }),
  });
}
