import app from './app';
import { env } from './config/env';
import { prisma } from './config/db';

async function bootstrap() {
  try {
    await prisma.$connect();
    console.log('✅ Conectado ao banco de dados.');

    const server = app.listen(env.port, () => {
      console.log(`🚀 API do Verbo rodando em http://localhost:${env.port}/api`);
      console.log(`   Ambiente: ${env.nodeEnv}`);
    });

    let shuttingDown = false;
    const shutdown = async (signal: string) => {
      if (shuttingDown) return;
      shuttingDown = true;
      console.log(`\n${signal} recebido. Encerrando com segurança...`);
      server.close(async () => {
        await prisma.$disconnect();
        process.exit(0);
      });
      setTimeout(() => process.exit(1), 10_000).unref();
    };

    process.on('SIGINT', () => void shutdown('SIGINT'));
    process.on('SIGTERM', () => void shutdown('SIGTERM'));
  } catch (error) {
    console.error('❌ Falha ao iniciar o servidor:', error);
    await prisma.$disconnect();
    process.exit(1);
  }
}

void bootstrap();
