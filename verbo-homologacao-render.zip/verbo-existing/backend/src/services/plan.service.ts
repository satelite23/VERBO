import { prisma } from '../config/db';
import { env } from '../config/env';
import { AppError } from '../utils/AppError';

export type EffectivePlan = 'FREE' | 'PRO' | 'CHURCH';
export type VisualTemplate = 'illuminated' | 'minimal' | 'editorial' | 'frame';

const ALL_TEMPLATES: VisualTemplate[] = ['illuminated', 'minimal', 'editorial', 'frame'];

export function planCatalog() {
  return {
    FREE: {
      name: 'Gratuito',
      monthlyGenerationLimit: env.generationLimitMonthly,
      templates: ['illuminated', 'minimal'] as VisualTemplate[],
      watermark: true,
      customLogo: false,
      monthlyPrice: 0,
      annualPrice: 0,
    },
    PRO: {
      name: 'Pro',
      monthlyGenerationLimit: env.proGenerationLimit,
      templates: ALL_TEMPLATES,
      watermark: false,
      customLogo: false,
      monthlyPrice: env.proMonthlyCents / 100,
      annualPrice: env.proAnnualCents / 100,
    },
    CHURCH: {
      name: 'Igreja',
      monthlyGenerationLimit: env.churchGenerationLimit,
      templates: ALL_TEMPLATES,
      watermark: false,
      customLogo: true,
      monthlyPrice: env.churchMonthlyCents / 100,
      annualPrice: env.churchAnnualCents / 100,
    },
  } as const;
}

export async function getPlanContext(userId: string) {
  const subscription = await prisma.subscription.findUnique({ where: { userId } });
  let plan: EffectivePlan = 'FREE';

  if (subscription) {
    const activeNow = subscription.status === 'ACTIVE';
    const cancelledButPaid = subscription.status === 'CANCELLED'
      && Boolean(subscription.currentPeriodEnd && subscription.currentPeriodEnd > new Date());
    if (activeNow || cancelledButPaid) plan = subscription.plan;
  }

  const entitlements = planCatalog()[plan];
  return { plan, entitlements, subscription };
}

export async function assertVisualCapabilities(
  userId: string,
  update: { templateId?: string; logoUrl?: string | null },
) {
  const context = await getPlanContext(userId);
  if (update.templateId && !context.entitlements.templates.includes(update.templateId as VisualTemplate)) {
    throw new AppError(`O template selecionado requer um plano superior ao ${context.entitlements.name}.`, 403);
  }
  if (update.logoUrl && !context.entitlements.customLogo) {
    throw new AppError('Logo personalizado está disponível no plano Igreja.', 403);
  }
  return context;
}

export function getPlanAmount(plan: 'PRO' | 'CHURCH', cycle: 'MONTHLY' | 'ANNUAL') {
  const cents = plan === 'PRO'
    ? cycle === 'MONTHLY' ? env.proMonthlyCents : env.proAnnualCents
    : cycle === 'MONTHLY' ? env.churchMonthlyCents : env.churchAnnualCents;
  return cents / 100;
}
