import { z } from 'zod';
import versesData from '../data/verses.json';
import { env } from '../config/env';
import { AppError } from '../utils/AppError';

export interface Verse {
  ref: string;
  texto: string;
  version: string;
  requestedVersion: string;
  source: 'api-bible' | 'local-demo';
  passageId?: string;
  copyright?: string;
  fumsId?: string;
}

type LocalVerse = { ref: string; texto: string };
const TEMAS = versesData.temas as Record<string, LocalVerse[]>;
export const TEMAS_DISPONIVEIS = Object.keys(TEMAS);

const PASSAGE_IDS: Record<string, string> = {
  'Filipenses 4:6-7': 'PHP.4.6-PHP.4.7',
  '1 Pedro 5:7': '1PE.5.7',
  'Mateus 6:34': 'MAT.6.34',
  '1 Tessalonicenses 5:18': '1TH.5.18',
  'Salmos 107:1': 'PSA.107.1',
  'Colossenses 3:15': 'COL.3.15',
  'Jeremias 29:11': 'JER.29.11',
  'Romanos 15:13': 'ROM.15.13',
  'Salmos 42:11': 'PSA.42.11',
  'Hebreus 11:1': 'HEB.11.1',
  'Marcos 11:24': 'MRK.11.24',
  '2 Coríntios 5:7': '2CO.5.7',
  'João 14:27': 'JHN.14.27',
  'Isaías 26:3': 'ISA.26.3',
  'Salmos 29:11': 'PSA.29.11',
  '1 Coríntios 13:4': '1CO.13.4',
  '1 João 4:19': '1JN.4.19',
  'João 3:16': 'JHN.3.16',
  'Isaías 41:10': 'ISA.41.10',
  'Filipenses 4:13': 'PHP.4.13',
  'Josué 1:9': 'JOS.1.9',
  'Salmos 34:18': 'PSA.34.18',
  'Mateus 5:4': 'MAT.5.4',
  'Apocalipse 21:4': 'REV.21.4',
  'Romanos 8:28': 'ROM.8.28',
  'Efésios 2:10': 'EPH.2.10',
  'Provérbios 19:21': 'PRO.19.21',
  'Tiago 1:5': 'JAS.1.5',
  'Provérbios 3:5-6': 'PRO.3.5-PRO.3.6',
  'Provérbios 9:10': 'PRO.9.10',
};

const apiBibleResponseSchema = z.object({
  data: z.object({
    id: z.string().optional(),
    reference: z.string(),
    content: z.string(),
    copyright: z.string().optional().default(''),
  }),
  meta: z.object({ fumsId: z.string().optional() }).optional(),
});

export async function getVerseByTheme(theme: string, requestedVersion = 'ARC'): Promise<Verse> {
  const key = normalizeTheme(theme);
  const pool = TEMAS[key];
  if (!pool?.length) {
    throw new AppError(`Tema "${theme}" não encontrado. Temas disponíveis: ${TEMAS_DISPONIVEIS.join(', ')}`, 404);
  }

  const local = pool[Math.floor(Math.random() * pool.length)];
  const passageId = PASSAGE_IDS[local.ref];

  if (env.bibleProvider === 'api_bible') {
    try {
      const external = await fetchVerseFromExternalApi(local.ref, requestedVersion, passageId);
      if (external) return external;
      if (!env.bibleFallbackToLocal) throw new AppError('Fonte bíblica indisponível para a tradução selecionada.', 503);
    } catch (error) {
      if (!env.bibleFallbackToLocal) throw error;
      console.error('Falha na fonte bíblica; usando demonstração local:', error instanceof Error ? error.message : error);
    }
  }

  return {
    ref: local.ref,
    texto: local.texto,
    version: 'DEMO',
    requestedVersion,
    source: 'local-demo',
    passageId,
    copyright: 'Texto resumido para demonstração. Não corresponde a uma tradução bíblica oficial.',
  };
}

export function isBibleApiConfigured(version?: string): boolean {
  const hasVersion = version ? Boolean(env.bibleIds[version]) : Object.values(env.bibleIds).some(Boolean);
  return env.bibleProvider === 'api_bible' && Boolean(env.bibleApiKey && hasVersion);
}

export async function fetchVerseFromExternalApi(
  reference: string,
  version: string,
  passageId = PASSAGE_IDS[reference],
): Promise<Verse | null> {
  const bibleId = env.bibleIds[version];
  if (!isBibleApiConfigured(version) || !bibleId || !passageId) return null;

  const baseUrl = env.bibleApiBaseUrl.replace(/\/$/, '');
  const params = new URLSearchParams({
    'content-type': 'text',
    'include-notes': 'false',
    'include-titles': 'false',
    'include-chapter-numbers': 'false',
    'include-verse-numbers': 'true',
    'include-verse-spans': 'false',
  });
  const response = await fetch(
    `${baseUrl}/bibles/${encodeURIComponent(bibleId)}/passages/${encodeURIComponent(passageId)}?${params}`,
    {
      headers: { 'api-key': env.bibleApiKey },
      signal: AbortSignal.timeout(env.aiTimeoutMs),
    },
  );

  if (!response.ok) {
    throw new AppError(`A fonte bíblica respondeu com status ${response.status}.`, 502);
  }

  const parsed = apiBibleResponseSchema.parse(await response.json());
  return {
    ref: parsed.data.reference || reference,
    texto: cleanBibleText(parsed.data.content),
    version,
    requestedVersion: version,
    source: 'api-bible',
    passageId,
    copyright: parsed.data.copyright,
    fumsId: parsed.meta?.fumsId,
  };
}

export function getBibleStatus() {
  return {
    provider: env.bibleProvider,
    fallbackEnabled: env.bibleFallbackToLocal,
    configuredVersions: Object.entries(env.bibleIds)
      .filter(([, id]) => Boolean(id))
      .map(([version]) => version),
  };
}

function normalizeTheme(theme: string) {
  return theme.toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function cleanBibleText(value: string) {
  return value
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}
