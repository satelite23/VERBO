import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { AuthPayload } from '../middlewares/auth.middleware';

export function signToken(payload: AuthPayload): string {
  return jwt.sign(payload, env.jwtSecret, {
    algorithm: 'HS256',
    expiresIn: env.jwtExpiresIn,
    issuer: 'verbo-api',
    audience: 'verbo-app',
  } as jwt.SignOptions);
}
