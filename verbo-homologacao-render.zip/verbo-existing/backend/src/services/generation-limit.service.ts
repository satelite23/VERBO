import { prisma } from '../config/db';
import { AppError } from '../utils/AppError';
import { getPlanContext } from './plan.service';

export async function getMonthlyUsage(userId: string) {
  const now = new Date();
  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const [devotionals, posts, context] = await Promise.all([
    prisma.devotional.count({ where: { userId, createdAt: { gte: monthStart } } }),
    prisma.post.count({ where: { userId, createdAt: { gte: monthStart } } }),
    getPlanContext(userId),
  ]);
  const used = devotionals + posts;
  const limit = context.entitlements.monthlyGenerationLimit;
  return {
    used,
    limit,
    remaining: Math.max(0, limit - used),
    monthStart: monthStart.toISOString(),
    plan: context.plan,
  };
}

export async function assertGenerationAvailable(userId: string) {
  const usage = await getMonthlyUsage(userId);
  if (usage.used >= usage.limit) {
    throw new AppError(`Você atingiu o limite de ${usage.limit} gerações do plano ${usage.plan} neste mês.`, 429);
  }
  return usage;
}
