import { env } from '../config/env';

export async function sendPasswordResetEmail(input: {
  email: string;
  name: string;
  token: string;
}): Promise<{ sent: boolean; resetUrl: string }> {
  const frontendUrl = env.frontendUrl.split(',')[0].replace(/\/$/, '');
  const resetUrl = `${frontendUrl}/redefinir-senha?token=${encodeURIComponent(input.token)}`;

  if (!env.resendApiKey) return { sent: false, resetUrl };

  const safeName = escapeHtml(input.name);
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.resendApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: env.emailFrom,
      to: [input.email],
      subject: 'Redefina sua senha do Verbo',
      text: `Olá, ${input.name}. Use este link para redefinir sua senha: ${resetUrl}. O link expira em 30 minutos.`,
      html: `<p>Olá, ${safeName}.</p><p>Recebemos uma solicitação para redefinir sua senha do Verbo.</p><p><a href="${resetUrl}">Definir nova senha</a></p><p>O link expira em 30 minutos. Se você não fez esta solicitação, ignore este e-mail.</p>`,
    }),
    signal: AbortSignal.timeout(15_000),
  });

  if (!response.ok) {
    const details = await response.text();
    console.error('Falha ao enviar e-mail de recuperação:', response.status, details.slice(0, 300));
    return { sent: false, resetUrl };
  }
  return { sent: true, resetUrl };
}

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;',
  })[character] ?? character);
}
