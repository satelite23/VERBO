import { randomUUID } from 'node:crypto';
import { env } from '../config/env';
import { AppError } from '../utils/AppError';

export interface MercadoPagoPreapproval {
  id: string;
  status: string;
  reason?: string;
  external_reference?: string;
  init_point?: string;
  payer_email?: string;
  next_payment_date?: string;
  date_created?: string;
  last_modified?: string;
  auto_recurring?: {
    frequency?: number;
    frequency_type?: string;
    transaction_amount?: number;
    currency_id?: string;
    start_date?: string;
    end_date?: string;
  };
}

export async function createPreapproval(input: {
  email: string;
  reason: string;
  externalReference: string;
  amount: number;
  cycle: 'MONTHLY' | 'ANNUAL';
}) {
  ensureConfigured();
  return mercadoRequest<MercadoPagoPreapproval>('/preapproval', {
    method: 'POST',
    headers: { 'X-Idempotency-Key': randomUUID() },
    body: JSON.stringify({
      reason: input.reason,
      external_reference: input.externalReference,
      payer_email: input.email,
      back_url: `${env.frontendUrl.split(',')[0].replace(/\/$/, '')}/app/plano?retorno=mercadopago`,
      auto_recurring: {
        frequency: input.cycle === 'MONTHLY' ? 1 : 12,
        frequency_type: 'months',
        transaction_amount: input.amount,
        currency_id: 'BRL',
      },
      status: 'pending',
    }),
  });
}

export async function getPreapproval(id: string) {
  ensureConfigured();
  return mercadoRequest<MercadoPagoPreapproval>(`/preapproval/${encodeURIComponent(id)}`, { method: 'GET' });
}

export async function updatePreapproval(id: string, status: 'paused' | 'authorized' | 'cancelled') {
  ensureConfigured();
  return mercadoRequest<MercadoPagoPreapproval>(`/preapproval/${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: JSON.stringify({ status }),
  });
}

export function isMercadoPagoConfigured() {
  return Boolean(env.mercadoPagoAccessToken);
}

async function mercadoRequest<T>(path: string, init: RequestInit): Promise<T> {
  const response = await fetch(`https://api.mercadopago.com${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${env.mercadoPagoAccessToken}`,
      'Content-Type': 'application/json',
      ...(init.headers ?? {}),
    },
    signal: AbortSignal.timeout(20_000),
  });
  const body = await response.json().catch(() => ({})) as { message?: string; error?: string } & T;
  if (!response.ok) {
    console.error('Mercado Pago API:', response.status, body);
    throw new AppError(body.message ?? body.error ?? 'Falha na comunicação com o Mercado Pago.', 502);
  }
  return body;
}

function ensureConfigured() {
  if (!isMercadoPagoConfigured()) {
    throw new AppError('Mercado Pago ainda não foi configurado neste ambiente.', 503);
  }
}
