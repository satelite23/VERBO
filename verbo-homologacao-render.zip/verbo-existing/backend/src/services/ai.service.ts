import { z } from 'zod';
import { env } from '../config/env';
import { AppError } from '../utils/AppError';
import { getVerseByTheme, Verse } from './bible.service';

export interface GenerationMeta {
  provider: string;
  model: string;
  promptVersion: string;
}

export interface DevotionalContent extends GenerationMeta {
  title: string;
  verse: Verse;
  reflection: string;
  prayer: string;
  question: string;
}

export interface PostCaptionContent extends GenerationMeta {
  verse: Verse;
  caption: string;
}

const devotionalEditorialSchema = z.object({
  title: z.string().trim().min(4).max(180),
  reflection: z.string().trim().min(80).max(5000),
  prayer: z.string().trim().min(20).max(1500),
  question: z.string().trim().min(10).max(500),
});
const postEditorialSchema = z.object({
  caption: z.string().trim().min(20).max(2200),
});

const DEVOTIONAL_PROMPT_VERSION = 'devotional-v2';
const POST_PROMPT_VERSION = 'post-v2';

const REFLECOES_BASE: Record<string, string> = {
  ansiedade: 'Em meio às pressões do dia a dia, é fácil deixar a mente correr para o que pode dar errado. Mas a Palavra nos convida a trocar a preocupação pela confiança: não porque os problemas somem, mas porque não os enfrentamos sozinhos. Entregar a ansiedade a Deus é um ato diário — é escolher, a cada pensamento inquieto, lembrar de quem está no controle.',
  gratidao: 'A gratidão muda a forma como enxergamos o que vivemos. Quando escolhemos agradecer mesmo no meio da dificuldade, não estamos ignorando a dor — estamos reconhecendo que há mais na nossa história do que aquilo que dói agora. Um coração agradecido enxerga a fidelidade de Deus nos detalhes do cotidiano.',
  esperanca: 'Esperança bíblica não é otimismo ingênuo — é confiança firmada em quem Deus é. Mesmo quando o cenário não muda de imediato, a esperança sustenta porque olha além das circunstâncias presentes. Ela nos dá forças para continuar dando o próximo passo, mesmo sem ver o caminho inteiro.',
  fe: 'Fé não é ausência de dúvida, é a decisão de confiar mesmo sem enxergar tudo com clareza. Ela cresce no exercício diário de entregar o controle e obedecer com humildade. Cada passo de fé fortalece o próximo.',
  paz: 'A paz que a Palavra oferece não depende de um ambiente sem conflitos — ela nasce de um coração ancorado em algo maior que a instabilidade ao redor. É possível atravessar tempestades com um centro estável, firmado na presença de Deus.',
  amor: 'O amor descrito nas Escrituras vai além do sentimento — é decisão, ação e paciência praticada no cotidiano. Amar como fomos amados primeiro nos convida a olhar para o outro com generosidade e verdade.',
  forca: 'Força nem sempre significa não sentir cansaço — muitas vezes significa continuar mesmo cansado, apoiado em algo maior que a própria capacidade. Não precisamos gerar essa força sozinhos; ela é renovada em quem busca a presença de Deus.',
  luto: 'A dor da perda é real e merece espaço para ser sentida, não escondida. A Palavra não pede pressa no processo — ela oferece companhia dentro dele. Há consolo mesmo quando as perguntas ainda não têm resposta.',
  proposito: 'Nem sempre enxergamos o propósito enquanto o vivemos — muitas vezes ele só faz sentido olhando para trás. Confiar que há um plano maior, mesmo nos períodos de incerteza, sustenta o próximo passo.',
  sabedoria: 'Sabedoria bíblica começa com humildade — reconhecer que não temos todas as respostas e buscar direção fora de nós mesmos. É um convite diário a pedir, ouvir e ajustar o caminho.',
};
const ORACOES_BASE: Record<string, string> = {
  ansiedade: 'Senhor, hoje entrego a Ti os pensamentos que insistem em me inquietar. Ensina-me a confiar no Teu cuidado e a viver um dia de cada vez. Amém.',
  gratidao: 'Senhor, obrigado por tudo o que tens feito, mesmo aquilo que ainda não entendo. Abre meus olhos para reconhecer a Tua bondade nos detalhes de hoje. Amém.',
  esperanca: 'Senhor, quando o cenário parecer difícil, lembra-me de que a esperança em Ti não decepciona. Renova minhas forças para continuar caminhando. Amém.',
  fe: 'Senhor, aumenta a minha fé. Ajuda-me a confiar mesmo quando não vejo o caminho inteiro à frente. Amém.',
  paz: 'Senhor, acalma o meu coração hoje. Que a Tua paz guarde minha mente e minhas emoções. Amém.',
  amor: 'Senhor, ensina-me a amar com paciência, generosidade e verdade. Amém.',
  forca: 'Senhor, nos dias em que minhas forças não bastam, lembra-me de buscar em Ti o sustento para continuar. Amém.',
  luto: 'Senhor, conforta o meu coração nesse momento de dor. Que eu perceba a Tua presença mesmo quando as palavras faltam. Amém.',
  proposito: 'Senhor, ajuda-me a caminhar com fidelidade, mesmo quando ainda não compreendo todo o propósito. Amém.',
  sabedoria: 'Senhor, concede-me sabedoria para as decisões de hoje. Que eu busque a Tua direção antes de agir. Amém.',
};
const PERGUNTAS_BASE: Record<string, string> = {
  ansiedade: 'O que você pode entregar a Deus em oração hoje, em vez de carregar sozinho?',
  gratidao: 'Quais três coisas simples de hoje você pode agradecer agora?',
  esperanca: 'Em que área da sua vida você precisa renovar a esperança hoje?',
  fe: 'Que passo de fé você pode dar nesta semana?',
  paz: 'O que tem roubado sua paz e como você pode apresentar isso em oração?',
  amor: 'Como você pode demonstrar amor prático a alguém ainda hoje?',
  forca: 'Em que situação você tem tentado seguir apenas com suas próprias forças?',
  luto: 'Que espaço você tem dado para processar sua dor diante de Deus?',
  proposito: 'Que talento ou experiência pode ser colocado a serviço de outras pessoas?',
  sabedoria: 'Qual decisão você precisa levar a Deus em oração antes de agir?',
};

export async function generateDevotional(
  theme: string,
  userName?: string,
  bibleVersion = 'ARC',
): Promise<DevotionalContent> {
  const verse = await getVerseByTheme(theme, bibleVersion);
  const local = buildLocalDevotional(theme, verse, userName);
  if (env.aiProvider === 'local') return local;

  const prompt = buildDevotionalPrompt(theme, verse, userName);
  try {
    const generation = await callProvider(prompt, 'devotional');
    const editorial = devotionalEditorialSchema.parse(parseJson(generation.text));
    return { ...editorial, verse, provider: generation.provider, model: generation.model, promptVersion: DEVOTIONAL_PROMPT_VERSION };
  } catch (error) {
    return fallbackOrThrow(error, local, 'devocional');
  }
}

export async function generatePostCaption(theme: string, bibleVersion = 'ARC'): Promise<PostCaptionContent> {
  const verse = await getVerseByTheme(theme, bibleVersion);
  const local = buildLocalPost(theme, verse);
  if (env.aiProvider === 'local') return local;

  const prompt = buildPostPrompt(theme, verse);
  try {
    const generation = await callProvider(prompt, 'post');
    const editorial = postEditorialSchema.parse(parseJson(generation.text));
    return { ...editorial, verse, provider: generation.provider, model: generation.model, promptVersion: POST_PROMPT_VERSION };
  } catch (error) {
    return fallbackOrThrow(error, local, 'post');
  }
}

export function getAiStatus() {
  return {
    provider: env.aiProvider,
    fallbackEnabled: env.aiFallbackToLocal,
    model: resolveProviderModel(env.aiProvider),
    configured: isProviderConfigured(env.aiProvider),
  };
}

function buildLocalDevotional(theme: string, verse: Verse, userName?: string): DevotionalContent {
  const key = slugTheme(theme);
  const greeting = userName ? `${userName}, ` : '';
  return {
    title: `Devocional: ${capitalize(theme)}`,
    verse,
    reflection: `${greeting}${REFLECOES_BASE[key] ?? REFLECOES_BASE.fe}`,
    prayer: ORACOES_BASE[key] ?? ORACOES_BASE.fe,
    question: PERGUNTAS_BASE[key] ?? PERGUNTAS_BASE.fe,
    provider: 'local',
    model: 'template-v1',
    promptVersion: DEVOTIONAL_PROMPT_VERSION,
  };
}

function buildLocalPost(theme: string, verse: Verse): PostCaptionContent {
  const key = slugTheme(theme);
  const templates: Record<string, string> = {
    ansiedade: 'Respire. Você não precisa carregar tudo sozinho hoje. Reserve alguns minutos para apresentar suas preocupações em oração e dar um passo de cada vez. 🕊️',
    gratidao: 'Hoje escolho perceber os motivos para agradecer — inclusive os pequenos sinais de cuidado que a pressa costuma esconder. 🙏',
    esperanca: 'Nem sempre vemos o caminho inteiro, mas podemos caminhar com esperança e fidelidade no próximo passo. ✨',
    fe: 'Um passo de fé de cada vez. Confiança também se constrói nas pequenas decisões do cotidiano.',
    paz: 'Que a paz guarde seu coração hoje. Desacelere, respire e apresente em oração aquilo que você não consegue controlar. 🕊️',
    amor: 'Amados primeiro, somos convidados a transformar o amor em paciência, verdade e cuidado prático. ❤️',
    forca: 'Nos dias difíceis, reconhecer o cansaço também pode ser o começo de buscar ajuda e renovar as forças.',
    luto: 'A dor merece espaço e cuidado. Não há necessidade de atravessar o luto com pressa ou sozinho. 🤍',
    proposito: 'O propósito também se revela na fidelidade às pequenas responsabilidades de hoje.',
    sabedoria: 'Antes de agir, pare, escute e peça sabedoria para escolher o próximo passo.',
  };
  return { verse, caption: templates[key] ?? templates.fe, provider: 'local', model: 'template-v1', promptVersion: POST_PROMPT_VERSION };
}

function buildDevotionalPrompt(theme: string, verse: Verse, userName?: string) {
  return `${EDITORIAL_RULES}\n\nTAREFA: escreva um devocional em português do Brasil.\nTema: ${theme}\nNome do leitor, se útil: ${userName ?? 'não informado'}\nReferência verificada: ${verse.ref}\nTexto bíblico fornecido pela fonte: ${verse.texto}\n\nNão reescreva nem cite outro versículo. Produza somente um objeto JSON com: title, reflection, prayer, question.`;
}

function buildPostPrompt(theme: string, verse: Verse) {
  return `${EDITORIAL_RULES}\n\nTAREFA: escreva uma legenda curta para rede social em português do Brasil.\nTema: ${theme}\nReferência verificada: ${verse.ref}\nTexto bíblico fornecido pela fonte: ${verse.texto}\n\nA legenda deve ter de 300 a 800 caracteres, parágrafos curtos, aplicação concreta e no máximo dois emojis. Não inclua hashtags. Produza somente um objeto JSON com o campo caption.`;
}

const EDITORIAL_RULES = `Você é um assistente editorial cristão. O texto bíblico já foi fornecido por uma fonte separada e não pode ser alterado, completado ou inventado. Escreva com tom pastoral, responsável e não denominacional. Evite promessas absolutas, culpa, manipulação, diagnóstico, aconselhamento clínico e afirmações de que Deus garantirá resultados materiais. Não atribua novas falas a Deus. Não substitua cuidado pastoral ou profissional. Entregue JSON válido, sem markdown.`;

async function callProvider(prompt: string, kind: 'devotional' | 'post') {
  const provider = env.aiProvider;
  if (!isProviderConfigured(provider)) throw new Error(`Provedor de IA "${provider}" não configurado.`);
  if (provider === 'anthropic') return callAnthropic(prompt);
  if (provider === 'openai') return callOpenAI(prompt);
  if (provider === 'gemini') return callGemini(prompt, kind);
  throw new Error(`Provedor de IA não suportado: ${provider}.`);
}

async function callAnthropic(prompt: string) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': env.anthropicApiKey,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: env.anthropicModel,
      max_tokens: 1400,
      temperature: 0.5,
      messages: [{ role: 'user', content: prompt }],
    }),
    signal: AbortSignal.timeout(env.aiTimeoutMs),
  });
  const data = await response.json() as { content?: Array<{ type: string; text?: string }>; error?: { message?: string } };
  if (!response.ok) throw new Error(data.error?.message ?? `Anthropic: status ${response.status}`);
  const text = data.content?.find((block) => block.type === 'text')?.text;
  if (!text) throw new Error('Anthropic não retornou texto.');
  return { text, provider: 'anthropic', model: env.anthropicModel };
}

async function callOpenAI(prompt: string) {
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.openAiApiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: env.openAiModel, input: prompt, max_output_tokens: 1400 }),
    signal: AbortSignal.timeout(env.aiTimeoutMs),
  });
  const data = await response.json() as {
    output_text?: string;
    output?: Array<{ content?: Array<{ type?: string; text?: string }> }>;
    error?: { message?: string };
  };
  if (!response.ok) throw new Error(data.error?.message ?? `OpenAI: status ${response.status}`);
  const text = data.output_text ?? data.output?.flatMap((item) => item.content ?? []).find((item) => item.type === 'output_text')?.text;
  if (!text) throw new Error('OpenAI não retornou texto.');
  return { text, provider: 'openai', model: env.openAiModel };
}

async function callGemini(prompt: string, kind: 'devotional' | 'post') {
  const responseSchema = kind === 'devotional'
    ? { type: 'object', properties: { title: { type: 'string' }, reflection: { type: 'string' }, prayer: { type: 'string' }, question: { type: 'string' } }, required: ['title', 'reflection', 'prayer', 'question'] }
    : { type: 'object', properties: { caption: { type: 'string' } }, required: ['caption'] };
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(env.geminiModel)}:generateContent`, {
    method: 'POST',
    headers: { 'x-goog-api-key': env.geminiApiKey, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.5, maxOutputTokens: 1400, responseMimeType: 'application/json', responseSchema },
    }),
    signal: AbortSignal.timeout(env.aiTimeoutMs),
  });
  const data = await response.json() as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    error?: { message?: string };
  };
  if (!response.ok) throw new Error(data.error?.message ?? `Gemini: status ${response.status}`);
  const text = data.candidates?.[0]?.content?.parts?.map((part) => part.text ?? '').join('');
  if (!text) throw new Error('Gemini não retornou texto.');
  return { text, provider: 'gemini', model: env.geminiModel };
}

function isProviderConfigured(provider: string) {
  if (provider === 'local') return true;
  if (provider === 'anthropic') return Boolean(env.anthropicApiKey);
  if (provider === 'openai') return Boolean(env.openAiApiKey);
  if (provider === 'gemini') return Boolean(env.geminiApiKey);
  return false;
}
function resolveProviderModel(provider: string) {
  if (provider === 'anthropic') return env.anthropicModel;
  if (provider === 'openai') return env.openAiModel;
  if (provider === 'gemini') return env.geminiModel;
  return 'template-v1';
}
function parseJson(text: string) {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/```$/i, '').trim();
  return JSON.parse(cleaned) as unknown;
}
function fallbackOrThrow<T extends GenerationMeta>(error: unknown, local: T, kind: string): T {
  console.error(`Falha na geração externa de ${kind}:`, error instanceof Error ? error.message : error);
  if (!env.aiFallbackToLocal) throw new AppError('O serviço de geração está temporariamente indisponível.', 502);
  return { ...local, provider: 'local-fallback' };
}
function slugTheme(theme: string) { return theme.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
function capitalize(text: string) { return text.charAt(0).toUpperCase() + text.slice(1); }
