import { createHmac, timingSafeEqual } from 'node:crypto';
import { Request, Response } from 'express';
import { Prisma } from '@prisma/client';
import { prisma } from '../config/db';
import { env } from '../config/env';
import { catchAsync } from '../utils/catchAsync';
import { AppError } from '../utils/AppError';
import { getPreapproval } from '../services/mercado-pago.service';
import { mapMercadoPagoStatus } from './billing.controller';

interface WebhookBody {
  id?: string | number;
  type?: string;
  action?: string;
  data?: { id?: string | number };
}

export const mercadoPagoWebhook = catchAsync(async (req: Request, res: Response) => {
  const body = req.body as WebhookBody;
  const queryDataId = String(req.query['data.id'] ?? '');
  const dataId = queryDataId || String(body.data?.id ?? '');
  if (!dataId || !verifyMercadoPagoSignature(req, dataId)) {
    throw new AppError('Assinatura de webhook inválida.', 401);
  }

  const type = String(req.query.type ?? body.type ?? 'unknown');
  if (type !== 'subscription_preapproval') {
    return res.json({ success: true, received: true, ignored: true });
  }

  const requestId = req.header('x-request-id') ?? 'no-request-id';
  const eventKey = `${requestId}:${type}:${dataId}:${body.action ?? 'update'}`;
  const processed = await prisma.billingEvent.findUnique({ where: { providerEventKey: eventKey } });
  if (processed) return res.json({ success: true, received: true, duplicate: true });

  const preapproval = await getPreapproval(dataId);
  const subscription = await prisma.subscription.findFirst({
    where: {
      OR: [
        { providerSubscriptionId: preapproval.id },
        ...(preapproval.external_reference ? [{ externalReference: preapproval.external_reference }] : []),
      ],
    },
  });
  if (!subscription) {
    throw new AppError('Assinatura correspondente não encontrada.', 404);
  }
  if (preapproval.external_reference && preapproval.external_reference !== subscription.externalReference) {
    throw new AppError('Referência externa da assinatura não confere.', 409);
  }

  const payload = preapproval as unknown as Prisma.InputJsonValue;
  await prisma.$transaction([
    prisma.subscription.update({
      where: { id: subscription.id },
      data: {
        providerSubscriptionId: preapproval.id,
        status: mapMercadoPagoStatus(preapproval.status),
        amount: preapproval.auto_recurring?.transaction_amount ?? subscription.amount,
        currency: preapproval.auto_recurring?.currency_id ?? subscription.currency,
        currentPeriodStart: parseDate(preapproval.auto_recurring?.start_date),
        currentPeriodEnd: parseDate(preapproval.next_payment_date),
        providerPayload: payload,
      },
    }),
    prisma.billingEvent.create({
      data: {
        providerEventKey: eventKey,
        type: `${type}:${body.action ?? 'update'}`,
        payload: body as unknown as Prisma.InputJsonValue,
      },
    }),
  ]);

  return res.json({ success: true, received: true });
});

export function verifyMercadoPagoSignature(req: Request, dataId: string) {
  const secret = env.mercadoPagoWebhookSecret;
  if (!secret) return !env.isProd;

  const signature = req.header('x-signature') ?? '';
  const requestId = req.header('x-request-id') ?? '';
  const values = Object.fromEntries(signature.split(',').map((part) => {
    const [key, ...rest] = part.trim().split('=');
    return [key, rest.join('=')];
  }));
  if (!values.ts || !values.v1) return false;

  const manifest = [
    dataId ? `id:${dataId.toLowerCase()};` : '',
    requestId ? `request-id:${requestId};` : '',
    `ts:${values.ts};`,
  ].join('');
  const expected = createHmac('sha256', secret).update(manifest).digest('hex');
  const received = values.v1;
  if (expected.length !== received.length) return false;
  return timingSafeEqual(Buffer.from(expected), Buffer.from(received));
}

function parseDate(value?: string) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}
