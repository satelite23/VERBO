import { Request, Response } from 'express';
import { prisma } from '../config/db';
import { env } from '../config/env';
import { catchAsync } from '../utils/catchAsync';
import { getAiStatus } from '../services/ai.service';
import { getBibleStatus } from '../services/bible.service';
import { isMercadoPagoConfigured } from '../services/mercado-pago.service';

export const readiness = catchAsync(async (_req: Request, res: Response) => {
  await prisma.$queryRaw`SELECT 1`;
  const ai = getAiStatus();
  const bible = getBibleStatus();
  res.json({
    success: true,
    status: 'ready',
    data: {
      database: true,
      integrations: {
        ai: { provider: ai.provider, configured: ai.configured, fallbackEnabled: ai.fallbackEnabled },
        bible: {
          provider: bible.provider,
          configured: bible.provider === 'local' || bible.configuredVersions.length > 0,
          configuredVersions: bible.configuredVersions,
          fallbackEnabled: bible.fallbackEnabled,
        },
        billing: { provider: 'mercado_pago', configured: isMercadoPagoConfigured() },
        email: { provider: 'resend', configured: Boolean(env.resendApiKey) },
      },
    },
  });
});
