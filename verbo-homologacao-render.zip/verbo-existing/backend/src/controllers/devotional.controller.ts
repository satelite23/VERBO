import { Request, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../config/db';
import { catchAsync } from '../utils/catchAsync';
import { AppError } from '../utils/AppError';
import { generateDevotional } from '../services/ai.service';
import { getBibleStatus, TEMAS_DISPONIVEIS } from '../services/bible.service';
import { getAiStatus } from '../services/ai.service';
import { assertGenerationAvailable } from '../services/generation-limit.service';

const generateSchema = z.object({
  theme: z
    .string()
    .trim()
    .min(2, 'Informe um tema (ex: gratidão, fé, ansiedade)')
    .max(120),
});

const updateSchema = z.object({
  title: z.string().trim().min(2).max(180).optional(),
  verseRef: z.string().trim().min(2).max(100).optional(),
  verseText: z.string().trim().min(2).max(1000).optional(),
  reflection: z.string().trim().min(10).max(10000).optional(),
  prayer: z.string().trim().min(2).max(5000).optional(),
  question: z.string().trim().min(2).max(1000).optional(),
});

export const listThemes = catchAsync(async (_req: Request, res: Response) => {
  res.json({
    success: true,
    data: { themes: TEMAS_DISPONIVEIS, bible: getBibleStatus(), ai: getAiStatus() },
  });
});

export const generate = catchAsync(async (req: Request, res: Response) => {
  const { theme } = generateSchema.parse(req.body);

  await assertGenerationAvailable(req.user!.id);
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  const content = await generateDevotional(theme, user?.name, user?.bibleVersion ?? 'ARC');

  const devotional = await prisma.devotional.create({
    data: {
      userId: req.user!.id,
      title: content.title,
      theme,
      verseRef: content.verse.ref,
      verseText: content.verse.texto,
      bibleVersion: content.verse.version,
      bibleSource: content.verse.source,
      bibleCopyright: content.verse.copyright,
      reflection: content.reflection,
      prayer: content.prayer,
      question: content.question,
      aiProvider: content.provider,
      aiModel: content.model,
      promptVersion: content.promptVersion,
    },
  });

  res.status(201).json({ success: true, data: { devotional, persisted: true } });
});

export const list = catchAsync(async (req: Request, res: Response) => {
  const devotionals = await prisma.devotional.findMany({
    where: { userId: req.user!.id },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, data: { devotionals } });
});

export const getOne = catchAsync(async (req: Request, res: Response) => {
  const devotional = await prisma.devotional.findFirst({
    where: { id: req.params.id, userId: req.user!.id },
  });
  if (!devotional) throw new AppError('Devocional não encontrado.', 404);
  res.json({ success: true, data: { devotional } });
});

export const update = catchAsync(async (req: Request, res: Response) => {
  const data = updateSchema.parse(req.body);
  const existing = await prisma.devotional.findFirst({
    where: { id: req.params.id, userId: req.user!.id },
  });
  if (!existing) throw new AppError('Devocional não encontrado.', 404);

  const devotional = await prisma.devotional.update({ where: { id: existing.id }, data });
  res.json({ success: true, message: 'Devocional atualizado.', data: { devotional } });
});

export const remove = catchAsync(async (req: Request, res: Response) => {
  const devotional = await prisma.devotional.findFirst({
    where: { id: req.params.id, userId: req.user!.id },
  });
  if (!devotional) throw new AppError('Devocional não encontrado.', 404);

  await prisma.devotional.delete({ where: { id: devotional.id } });
  res.json({ success: true, message: 'Devocional removido.' });
});
