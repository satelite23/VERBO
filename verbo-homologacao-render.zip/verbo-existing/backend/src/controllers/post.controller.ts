import { Request, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../config/db';
import { catchAsync } from '../utils/catchAsync';
import { AppError } from '../utils/AppError';
import { generatePostCaption } from '../services/ai.service';
import { assertGenerationAvailable } from '../services/generation-limit.service';
import { assertVisualCapabilities } from '../services/plan.service';

const hexColor = z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Cor inválida. Use o formato #RRGGBB.');
const templateId = z.enum(['illuminated', 'minimal', 'editorial', 'frame']);
const fontFamily = z.enum(['fraunces', 'inter', 'mono']);
const textAlign = z.enum(['left', 'center', 'right']);
const format = z.enum(['FEED', 'STORY', 'WHATSAPP']);

function assetUrl(maxLength: number) {
  return z.string().max(maxLength).refine(
    (value) => /^data:image\/(png|jpeg|webp);base64,/i.test(value) || /^https:\/\//i.test(value),
    'Imagem inválida. Use PNG, JPEG ou WebP.',
  );
}

const generateSchema = z.object({
  theme: z.string().trim().min(2).max(120),
  format: format.default('FEED'),
  templateId: templateId.default('illuminated'),
  bgColor: hexColor.default('#12162A'),
  accentColor: hexColor.default('#C9A24B'),
  fontFamily: fontFamily.default('fraunces'),
  textAlign: textAlign.default('center'),
  overlayOpacity: z.number().int().min(0).max(90).default(45),
  fontScale: z.number().int().min(70).max(140).default(100),
});

const updateSchema = z.object({
  title: z.string().trim().min(2).max(180).optional(),
  caption: z.string().trim().min(1).max(5000).optional(),
  templateId: templateId.optional(),
  bgColor: hexColor.optional(),
  accentColor: hexColor.optional(),
  format: format.optional(),
  imageUrl: assetUrl(2_000_000).nullable().optional(),
  logoUrl: assetUrl(350_000).nullable().optional(),
  fontFamily: fontFamily.optional(),
  textAlign: textAlign.optional(),
  overlayOpacity: z.number().int().min(0).max(90).optional(),
  fontScale: z.number().int().min(70).max(140).optional(),
});

export const generate = catchAsync(async (req: Request, res: Response) => {
  const data = generateSchema.parse(req.body);
  await assertVisualCapabilities(req.user!.id, { templateId: data.templateId });
  await assertGenerationAvailable(req.user!.id);
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  const content = await generatePostCaption(data.theme, user?.bibleVersion ?? 'ARC');

  const post = await prisma.post.create({
    data: {
      userId: req.user!.id,
      title: `Post: ${data.theme}`,
      theme: data.theme,
      verseRef: content.verse.ref,
      verseText: content.verse.texto,
      bibleVersion: content.verse.version,
      bibleSource: content.verse.source,
      bibleCopyright: content.verse.copyright,
      caption: content.caption,
      aiProvider: content.provider,
      aiModel: content.model,
      promptVersion: content.promptVersion,
      format: data.format,
      templateId: data.templateId,
      bgColor: data.bgColor,
      accentColor: data.accentColor,
      fontFamily: data.fontFamily,
      textAlign: data.textAlign,
      overlayOpacity: data.overlayOpacity,
      fontScale: data.fontScale,
    },
  });

  res.status(201).json({ success: true, data: { post } });
});

export const list = catchAsync(async (req: Request, res: Response) => {
  const posts = await prisma.post.findMany({
    where: { userId: req.user!.id },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, data: { posts } });
});

export const update = catchAsync(async (req: Request, res: Response) => {
  const data = updateSchema.parse(req.body);
  await assertVisualCapabilities(req.user!.id, { templateId: data.templateId, logoUrl: data.logoUrl });
  const existing = await prisma.post.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!existing) throw new AppError('Post não encontrado.', 404);

  const post = await prisma.post.update({ where: { id: existing.id }, data });
  res.json({ success: true, data: { post } });
});

export const remove = catchAsync(async (req: Request, res: Response) => {
  const existing = await prisma.post.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!existing) throw new AppError('Post não encontrado.', 404);

  await prisma.post.delete({ where: { id: existing.id } });
  res.json({ success: true, message: 'Post removido.' });
});
