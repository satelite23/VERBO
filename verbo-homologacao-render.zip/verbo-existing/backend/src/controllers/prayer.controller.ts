import { Request, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../config/db';
import { catchAsync } from '../utils/catchAsync';
import { AppError } from '../utils/AppError';

const createSchema = z.object({
  title: z.string().trim().min(2, 'Informe um título para o pedido de oração').max(180),
  description: z.string().trim().max(2000).optional(),
  prayDate: z.coerce.date().optional(),
});

const updateSchema = z.object({
  title: z.string().trim().min(2).max(180).optional(),
  description: z.string().trim().max(2000).nullable().optional(),
  isAnswered: z.boolean().optional(),
  prayDate: z.coerce.date().optional(),
});

const filterSchema = z.object({
  month: z.coerce.number().int().min(1).max(12).optional(),
  year: z.coerce.number().int().min(2000).max(2200).optional(),
}).refine((data) => Boolean(data.month) === Boolean(data.year), {
  message: 'Informe mês e ano juntos.',
});

export const create = catchAsync(async (req: Request, res: Response) => {
  const data = createSchema.parse(req.body);

  const prayer = await prisma.prayerRequest.create({
    data: {
      userId: req.user!.id,
      title: data.title,
      description: data.description || null,
      prayDate: data.prayDate ?? new Date(),
    },
  });

  res.status(201).json({ success: true, data: { prayer } });
});

/** Lista pedidos, opcionalmente filtrando por mês/ano para a visão de calendário. */
export const list = catchAsync(async (req: Request, res: Response) => {
  const { month, year } = filterSchema.parse(req.query);
  const where: { userId: string; prayDate?: { gte: Date; lte: Date } } = { userId: req.user!.id };

  if (month && year) {
    const start = new Date(year, month - 1, 1);
    const end = new Date(year, month, 0, 23, 59, 59, 999);
    where.prayDate = { gte: start, lte: end };
  }

  const prayers = await prisma.prayerRequest.findMany({
    where,
    orderBy: [{ isAnswered: 'asc' }, { prayDate: 'asc' }],
  });

  res.json({ success: true, data: { prayers } });
});

export const update = catchAsync(async (req: Request, res: Response) => {
  const data = updateSchema.parse(req.body);
  const existing = await prisma.prayerRequest.findFirst({
    where: { id: req.params.id, userId: req.user!.id },
  });
  if (!existing) throw new AppError('Pedido de oração não encontrado.', 404);

  const prayer = await prisma.prayerRequest.update({
    where: { id: existing.id },
    data: {
      ...data,
      ...(data.isAnswered === undefined
        ? {}
        : { answeredAt: data.isAnswered ? existing.answeredAt ?? new Date() : null }),
    },
  });
  res.json({ success: true, data: { prayer } });
});

export const remove = catchAsync(async (req: Request, res: Response) => {
  const existing = await prisma.prayerRequest.findFirst({
    where: { id: req.params.id, userId: req.user!.id },
  });
  if (!existing) throw new AppError('Pedido de oração não encontrado.', 404);

  await prisma.prayerRequest.delete({ where: { id: existing.id } });
  res.json({ success: true, message: 'Pedido de oração removido.' });
});
