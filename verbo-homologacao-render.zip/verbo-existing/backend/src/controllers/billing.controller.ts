import { randomUUID } from 'node:crypto';
import { Request, Response } from 'express';
import { Prisma } from '@prisma/client';
import { z } from 'zod';
import { prisma } from '../config/db';
import { catchAsync } from '../utils/catchAsync';
import { AppError } from '../utils/AppError';
import { getMonthlyUsage } from '../services/generation-limit.service';
import { getPlanAmount, getPlanContext, planCatalog } from '../services/plan.service';
import {
  createPreapproval,
  isMercadoPagoConfigured,
  updatePreapproval,
} from '../services/mercado-pago.service';

const checkoutSchema = z.object({
  plan: z.enum(['PRO', 'CHURCH']),
  cycle: z.enum(['MONTHLY', 'ANNUAL']).default('MONTHLY'),
});
const manageSchema = z.object({ action: z.enum(['pause', 'resume', 'cancel']) });

export const status = catchAsync(async (req: Request, res: Response) => {
  const [context, usage] = await Promise.all([
    getPlanContext(req.user!.id),
    getMonthlyUsage(req.user!.id),
  ]);

  res.json({
    success: true,
    data: {
      plan: context.plan,
      entitlements: context.entitlements,
      usage,
      catalog: planCatalog(),
      billingConfigured: isMercadoPagoConfigured(),
      subscription: context.subscription ? serializeSubscription(context.subscription) : null,
    },
  });
});

export const checkout = catchAsync(async (req: Request, res: Response) => {
  const { plan, cycle } = checkoutSchema.parse(req.body);
  if (!isMercadoPagoConfigured()) throw new AppError('Mercado Pago ainda não foi configurado neste ambiente.', 503);
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  if (!user) throw new AppError('Usuário não encontrado.', 404);

  const current = await prisma.subscription.findUnique({ where: { userId: user.id } });
  if (current?.status === 'ACTIVE') {
    throw new AppError('Você já possui uma assinatura ativa. Cancele ou altere a assinatura atual antes de iniciar outra.', 409);
  }

  const amount = getPlanAmount(plan, cycle);
  const externalReference = randomUUID();
  const pending = await prisma.subscription.upsert({
    where: { userId: user.id },
    update: {
      plan,
      billingCycle: cycle,
      status: 'PENDING',
      provider: 'mercado_pago',
      providerSubscriptionId: null,
      externalReference,
      checkoutUrl: null,
      amount,
      currency: 'BRL',
      providerPayload: Prisma.JsonNull,
      currentPeriodStart: null,
      currentPeriodEnd: null,
    },
    create: {
      userId: user.id,
      plan,
      billingCycle: cycle,
      status: 'PENDING',
      provider: 'mercado_pago',
      externalReference,
      amount,
      currency: 'BRL',
    },
  });

  const preapproval = await createPreapproval({
    email: user.email,
    reason: `Verbo ${plan === 'PRO' ? 'Pro' : 'Igreja'} — ${cycle === 'MONTHLY' ? 'mensal' : 'anual'}`,
    externalReference: pending.externalReference,
    amount,
    cycle,
  });
  if (!preapproval.init_point) throw new AppError('O Mercado Pago não retornou o endereço do checkout.', 502);

  await prisma.subscription.update({
    where: { id: pending.id },
    data: {
      providerSubscriptionId: preapproval.id,
      checkoutUrl: preapproval.init_point,
      providerPayload: preapproval as unknown as Prisma.InputJsonValue,
    },
  });

  res.status(201).json({
    success: true,
    data: { checkoutUrl: preapproval.init_point, subscriptionId: pending.id },
  });
});

export const manage = catchAsync(async (req: Request, res: Response) => {
  const { action } = manageSchema.parse(req.body);
  const subscription = await prisma.subscription.findUnique({ where: { userId: req.user!.id } });
  if (!subscription?.providerSubscriptionId) throw new AppError('Assinatura não encontrada.', 404);

  const providerStatus = action === 'pause' ? 'paused' : action === 'resume' ? 'authorized' : 'cancelled';
  const preapproval = await updatePreapproval(subscription.providerSubscriptionId, providerStatus);
  const updated = await prisma.subscription.update({
    where: { id: subscription.id },
    data: {
      status: mapMercadoPagoStatus(preapproval.status),
      currentPeriodStart: parseDate(preapproval.auto_recurring?.start_date),
      currentPeriodEnd: parseDate(preapproval.next_payment_date),
      providerPayload: preapproval as unknown as Prisma.InputJsonValue,
    },
  });

  res.json({ success: true, message: manageMessage(action), data: { subscription: serializeSubscription(updated) } });
});

export function mapMercadoPagoStatus(status: string) {
  if (status === 'authorized') return 'ACTIVE' as const;
  if (status === 'paused') return 'PAUSED' as const;
  if (status === 'cancelled') return 'CANCELLED' as const;
  return 'PENDING' as const;
}

export function serializeSubscription(subscription: {
  id: string;
  plan: string;
  billingCycle: string;
  status: string;
  amount: Prisma.Decimal;
  currency: string;
  currentPeriodStart: Date | null;
  currentPeriodEnd: Date | null;
  checkoutUrl: string | null;
  createdAt: Date;
  updatedAt: Date;
}) {
  return {
    id: subscription.id,
    plan: subscription.plan,
    billingCycle: subscription.billingCycle,
    status: subscription.status,
    amount: Number(subscription.amount),
    currency: subscription.currency,
    currentPeriodStart: subscription.currentPeriodStart,
    currentPeriodEnd: subscription.currentPeriodEnd,
    checkoutUrl: subscription.checkoutUrl,
    createdAt: subscription.createdAt,
    updatedAt: subscription.updatedAt,
  };
}

function parseDate(value?: string) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}
function manageMessage(action: 'pause' | 'resume' | 'cancel') {
  if (action === 'pause') return 'Assinatura pausada.';
  if (action === 'resume') return 'Assinatura retomada.';
  return 'Assinatura cancelada.';
}
