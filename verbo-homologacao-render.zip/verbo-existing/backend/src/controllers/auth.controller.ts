import { createHash, randomBytes } from 'node:crypto';
import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '../config/db';
import { env } from '../config/env';
import { catchAsync } from '../utils/catchAsync';
import { AppError } from '../utils/AppError';
import { signToken } from '../services/token.service';
import { sendPasswordResetEmail } from '../services/email.service';

const normalizedEmail = z
  .string()
  .trim()
  .email('E-mail inválido')
  .max(254, 'E-mail muito longo')
  .transform((email) => email.toLowerCase());

const passwordSchema = z
  .string()
  .min(8, 'Senha deve ter ao menos 8 caracteres')
  .max(128, 'Senha muito longa');

const registerSchema = z.object({
  name: z.string().trim().min(2, 'Nome deve ter ao menos 2 caracteres').max(100),
  email: normalizedEmail,
  password: passwordSchema,
  churchName: z.string().trim().max(120).optional(),
});

const loginSchema = z.object({
  email: normalizedEmail,
  password: z.string().min(1, 'Informe a senha').max(128),
});

const profileSchema = z.object({
  name: z.string().trim().min(2).max(100).optional(),
  churchName: z.string().trim().max(120).nullable().optional(),
  profileType: z.enum(['PERSONAL', 'CHURCH', 'CREATOR', 'MINISTRY']).optional(),
  bibleVersion: z.enum(['ARC', 'ARA', 'NVI', 'NVT', 'NTLH']).optional(),
  goals: z.array(z.enum(['DEVOTIONALS', 'POSTS', 'PRAYER', 'READING'])).max(4).optional(),
  onboardingCompleted: z.boolean().optional(),
});

const forgotPasswordSchema = z.object({ email: normalizedEmail });
const resetPasswordSchema = z.object({
  token: z.string().min(40).max(200),
  password: passwordSchema,
});
const deleteAccountSchema = z.object({ password: z.string().min(1).max(128) });

type PublicUserSource = {
  id: string;
  name: string;
  email: string;
  role: string;
  profileType: string;
  churchName: string | null;
  bibleVersion: string;
  goals: string[];
  onboardingCompleted: boolean;
  sessionVersion: number;
  createdAt: Date;
};

function toPublicUser(user: PublicUserSource) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    profileType: user.profileType,
    churchName: user.churchName,
    bibleVersion: user.bibleVersion,
    goals: user.goals,
    onboardingCompleted: user.onboardingCompleted,
    createdAt: user.createdAt,
  };
}

export const register = catchAsync(async (req: Request, res: Response) => {
  const data = registerSchema.parse(req.body);
  const existing = await prisma.user.findUnique({ where: { email: data.email } });
  if (existing) throw new AppError('Já existe uma conta com esse e-mail.', 409);

  const passwordHash = await bcrypt.hash(data.password, 12);
  const user = await prisma.user.create({
    data: {
      name: data.name,
      email: data.email,
      passwordHash,
      churchName: data.churchName || null,
      role: 'USER',
    },
  });

  const token = signToken({
    id: user.id,
    email: user.email,
    role: user.role,
    sessionVersion: user.sessionVersion,
  });

  res.status(201).json({
    success: true,
    message: 'Conta criada com sucesso.',
    data: { user: toPublicUser(user), token },
  });
});

export const login = catchAsync(async (req: Request, res: Response) => {
  const data = loginSchema.parse(req.body);
  const user = await prisma.user.findUnique({ where: { email: data.email } });

  if (!user) {
    await bcrypt.compare(data.password, '$2a$12$LJS8Z2n3EufQrYrzF.WuAu.tOtfGguSMMTsf2lMoWYRb8.umgpSPW');
    throw new AppError('E-mail ou senha incorretos.', 401);
  }

  const passwordMatches = await bcrypt.compare(data.password, user.passwordHash);
  if (!passwordMatches) throw new AppError('E-mail ou senha incorretos.', 401);

  const token = signToken({
    id: user.id,
    email: user.email,
    role: user.role,
    sessionVersion: user.sessionVersion,
  });

  res.json({
    success: true,
    message: 'Login realizado com sucesso.',
    data: { user: toPublicUser(user), token },
  });
});

export const me = catchAsync(async (req: Request, res: Response) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  if (!user) throw new AppError('Usuário não encontrado.', 404);
  res.json({ success: true, data: { user: toPublicUser(user) } });
});

export const updateMe = catchAsync(async (req: Request, res: Response) => {
  const data = profileSchema.parse(req.body);
  const user = await prisma.user.update({
    where: { id: req.user!.id },
    data: {
      ...data,
      ...(data.churchName === '' ? { churchName: null } : {}),
    },
  });
  res.json({ success: true, message: 'Perfil atualizado.', data: { user: toPublicUser(user) } });
});

export const forgotPassword = catchAsync(async (req: Request, res: Response) => {
  const { email } = forgotPasswordSchema.parse(req.body);
  const user = await prisma.user.findUnique({ where: { email } });

  let developmentResetUrl: string | undefined;
  if (user) {
    const token = randomBytes(32).toString('hex');
    const tokenHash = hashResetToken(token);
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000);

    await prisma.$transaction([
      prisma.passwordResetToken.deleteMany({
        where: { userId: user.id, OR: [{ usedAt: { not: null } }, { expiresAt: { lt: new Date() } }] },
      }),
      prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash, expiresAt } }),
    ]);

    const delivery = await sendPasswordResetEmail({ email: user.email, name: user.name, token });
    if (!env.isProd && !delivery.sent) developmentResetUrl = delivery.resetUrl;
  }

  res.json({
    success: true,
    message: 'Se existir uma conta com esse e-mail, enviaremos as instruções de recuperação.',
    ...(!env.isProd && developmentResetUrl ? { data: { developmentResetUrl } } : {}),
  });
});

export const resetPassword = catchAsync(async (req: Request, res: Response) => {
  const { token, password } = resetPasswordSchema.parse(req.body);
  const tokenHash = hashResetToken(token);
  const resetToken = await prisma.passwordResetToken.findUnique({
    where: { tokenHash },
    include: { user: true },
  });

  if (!resetToken || resetToken.usedAt || resetToken.expiresAt <= new Date()) {
    throw new AppError('Link inválido ou expirado. Solicite um novo link.', 400);
  }

  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.$transaction([
    prisma.user.update({
      where: { id: resetToken.userId },
      data: { passwordHash, sessionVersion: { increment: 1 } },
    }),
    prisma.passwordResetToken.update({
      where: { id: resetToken.id },
      data: { usedAt: new Date() },
    }),
  ]);

  res.json({ success: true, message: 'Senha atualizada. Entre novamente com a nova senha.' });
});

export const deleteMe = catchAsync(async (req: Request, res: Response) => {
  const { password } = deleteAccountSchema.parse(req.body);
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    throw new AppError('Senha incorreta.', 401);
  }
  await prisma.user.delete({ where: { id: user.id } });
  res.json({ success: true, message: 'Conta e dados associados foram excluídos.' });
});

function hashResetToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}
