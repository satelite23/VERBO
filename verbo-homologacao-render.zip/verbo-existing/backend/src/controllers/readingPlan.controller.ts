import { Request, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../config/db';
import { env } from '../config/env';
import { catchAsync } from '../utils/catchAsync';
import { AppError } from '../utils/AppError';
import { isNextLocalDay, localDateKey } from '../utils/calendar';

export const listPlans = catchAsync(async (_req: Request, res: Response) => {
  const plans = await prisma.readingPlan.findMany({
    orderBy: { durationDays: 'asc' },
    include: { _count: { select: { days: true } } },
  });
  res.json({ success: true, data: { plans } });
});

export const getPlan = catchAsync(async (req: Request, res: Response) => {
  const plan = await prisma.readingPlan.findUnique({
    where: { id: req.params.id },
    include: { days: { orderBy: { dayNumber: 'asc' } } },
  });
  if (!plan) throw new AppError('Plano de leitura não encontrado.', 404);
  res.json({ success: true, data: { plan } });
});

const enrollSchema = z.object({ planId: z.string().uuid('Plano inválido.') });

export const enroll = catchAsync(async (req: Request, res: Response) => {
  const { planId } = enrollSchema.parse(req.body);

  const plan = await prisma.readingPlan.findUnique({ where: { id: planId } });
  if (!plan) throw new AppError('Plano de leitura não encontrado.', 404);

  const enrollment = await prisma.userPlanEnrollment.upsert({
    where: { userId_planId: { userId: req.user!.id, planId } },
    update: {},
    create: { userId: req.user!.id, planId },
    include: {
      plan: { include: { days: { orderBy: { dayNumber: 'asc' } } } },
      checkIns: { orderBy: { dayNumber: 'asc' } },
    },
  });

  res.status(201).json({ success: true, data: { enrollment } });
});

export const myEnrollments = catchAsync(async (req: Request, res: Response) => {
  const enrollments = await prisma.userPlanEnrollment.findMany({
    where: { userId: req.user!.id },
    orderBy: { startedAt: 'desc' },
    include: {
      plan: { include: { days: { orderBy: { dayNumber: 'asc' } } } },
      checkIns: { orderBy: { dayNumber: 'asc' }, select: { dayNumber: true, localDate: true, completedAt: true } },
    },
  });
  res.json({ success: true, data: { enrollments } });
});

/** Registra a leitura do dia, mantém a trilha de conclusão e atualiza a sequência. */
export const checkIn = catchAsync(async (req: Request, res: Response) => {
  const { planId } = enrollSchema.parse(req.body);

  const enrollment = await prisma.userPlanEnrollment.findUnique({
    where: { userId_planId: { userId: req.user!.id, planId } },
    include: { plan: true },
  });
  if (!enrollment) throw new AppError('Você ainda não iniciou esse plano.', 404);
  if (enrollment.completedAt || enrollment.completedDays >= enrollment.plan.durationDays) {
    return res.json({ success: true, message: 'Plano já concluído.', data: { enrollment } });
  }

  const now = new Date();
  const today = localDateKey(now, env.timeZone);
  const existingToday = await prisma.readingCheckIn.findUnique({
    where: { enrollmentId_localDate: { enrollmentId: enrollment.id, localDate: today } },
  });
  if (existingToday) {
    return res.json({ success: true, message: 'Leitura de hoje já registrada.', data: { enrollment } });
  }

  const completedDays = enrollment.completedDays + 1;
  const isCompleted = completedDays >= enrollment.plan.durationDays;
  const streak = enrollment.lastCheckIn && isNextLocalDay(enrollment.lastCheckIn, now, env.timeZone)
    ? enrollment.streak + 1
    : 1;

  const updated = await prisma.$transaction(async (tx) => {
    await tx.readingCheckIn.create({
      data: {
        enrollmentId: enrollment.id,
        dayNumber: enrollment.currentDay,
        localDate: today,
        completedAt: now,
      },
    });

    return tx.userPlanEnrollment.update({
      where: { id: enrollment.id },
      data: {
        completedDays,
        currentDay: isCompleted
          ? enrollment.plan.durationDays
          : Math.min(enrollment.currentDay + 1, enrollment.plan.durationDays),
        streak,
        lastCheckIn: now,
        completedAt: isCompleted ? now : null,
      },
      include: {
        plan: { include: { days: { orderBy: { dayNumber: 'asc' } } } },
        checkIns: { orderBy: { dayNumber: 'asc' } },
      },
    });
  });

  res.json({ success: true, data: { enrollment: updated } });
});
