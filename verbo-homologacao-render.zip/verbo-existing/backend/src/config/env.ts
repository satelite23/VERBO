import dotenv from 'dotenv';

dotenv.config();

function required(key: string, fallback?: string): string {
  const value = process.env[key] ?? fallback;
  if (value === undefined || value.trim() === '') {
    throw new Error(`Variável de ambiente obrigatória ausente: ${key}`);
  }
  return value;
}

function integer(key: string, fallback: number) {
  const value = Number(process.env[key] ?? fallback);
  if (!Number.isInteger(value) || value < 1) throw new Error(`${key} deve ser um inteiro positivo.`);
  return value;
}

function boolean(key: string, fallback: boolean) {
  const value = process.env[key];
  if (value === undefined) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(value.toLowerCase());
}

const nodeEnv = process.env.NODE_ENV ?? 'development';
const jwtSecret = required('JWT_SECRET');
if (nodeEnv === 'production' && jwtSecret.length < 32) {
  throw new Error('JWT_SECRET deve ter pelo menos 32 caracteres em produção.');
}

export const env = {
  port: Number(process.env.PORT ?? 4000),
  nodeEnv,
  frontendUrl: process.env.FRONTEND_URL ?? 'http://localhost:5173',
  databaseUrl: required('DATABASE_URL'),
  jwtSecret,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? '7d',
  timeZone: process.env.APP_TIME_ZONE ?? 'America/Sao_Paulo',

  aiProvider: (process.env.AI_PROVIDER ?? 'local').toLowerCase(),
  aiFallbackToLocal: boolean('AI_FALLBACK_TO_LOCAL', true),
  aiTimeoutMs: integer('AI_TIMEOUT_MS', 30_000),
  generationLimitMonthly: integer('GENERATION_LIMIT_MONTHLY', 3),
  proGenerationLimit: integer('PRO_GENERATION_LIMIT', 300),
  churchGenerationLimit: integer('CHURCH_GENERATION_LIMIT', 1000),
  anthropicApiKey: process.env.ANTHROPIC_API_KEY ?? '',
  anthropicModel: process.env.ANTHROPIC_MODEL ?? process.env.AI_MODEL ?? 'claude-sonnet-4-6',
  openAiApiKey: process.env.OPENAI_API_KEY ?? '',
  openAiModel: process.env.OPENAI_MODEL ?? 'gpt-4.1-mini',
  geminiApiKey: process.env.GEMINI_API_KEY ?? '',
  geminiModel: process.env.GEMINI_MODEL ?? 'gemini-2.5-flash-lite',

  bibleProvider: (process.env.BIBLE_PROVIDER ?? 'local').toLowerCase(),
  bibleFallbackToLocal: boolean('BIBLE_FALLBACK_TO_LOCAL', true),
  bibleApiKey: process.env.BIBLE_API_KEY ?? '',
  bibleApiBaseUrl: process.env.BIBLE_API_BASE_URL ?? 'https://rest.api.bible/v1',
  bibleIds: {
    ARC: process.env.BIBLE_ID_ARC ?? '',
    ARA: process.env.BIBLE_ID_ARA ?? '',
    NVI: process.env.BIBLE_ID_NVI ?? '',
    NVT: process.env.BIBLE_ID_NVT ?? '',
    NTLH: process.env.BIBLE_ID_NTLH ?? '',
  } as Record<string, string>,

  mercadoPagoAccessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN ?? '',
  mercadoPagoWebhookSecret: process.env.MERCADO_PAGO_WEBHOOK_SECRET ?? '',
  proMonthlyCents: integer('PRO_MONTHLY_CENTS', 2990),
  proAnnualCents: integer('PRO_ANNUAL_CENTS', 25116),
  churchMonthlyCents: integer('CHURCH_MONTHLY_CENTS', 9990),
  churchAnnualCents: integer('CHURCH_ANNUAL_CENTS', 83916),

  resendApiKey: process.env.RESEND_API_KEY ?? '',
  emailFrom: process.env.EMAIL_FROM ?? 'Verbo <nao-responda@verbo.app>',
  isProd: nodeEnv === 'production',
};
