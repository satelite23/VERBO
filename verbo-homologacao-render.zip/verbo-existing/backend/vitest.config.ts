import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    clearMocks: true,
    env: {
      NODE_ENV: 'test',
      DATABASE_URL: 'postgresql://test:test@localhost:5432/verbo_test',
      JWT_SECRET: 'test-secret-with-at-least-thirty-two-characters',
      FRONTEND_URL: 'http://localhost:5173',
      APP_TIME_ZONE: 'America/Sao_Paulo',
    },
  },
});
