const baseUrl = (process.env.STAGING_API_URL ?? '').replace(/\/$/, '');
if (!baseUrl.startsWith('https://')) {
  console.error('Defina STAGING_API_URL com a URL HTTPS completa, incluindo /api.');
  process.exit(1);
}

const email = `smoke.${Date.now()}@example.com`;
const password = 'Smoke-Seguro-123';
let token = '';
let assertions = 0;

function assert(condition, message) {
  assertions += 1;
  if (!condition) throw new Error(`ASSERT: ${message}`);
}
async function api(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    method: options.method ?? 'GET',
    headers: { 'Content-Type': 'application/json', ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}) },
    ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
  });
  const payload = await response.json().catch(() => ({}));
  if (response.status !== (options.expected ?? 200)) {
    throw new Error(`${options.method ?? 'GET'} ${path}: ${response.status}\n${JSON.stringify(payload)}`);
  }
  return payload;
}

async function run() {
  const ready = await api('/ready');
  assert(ready.status === 'ready', 'API pronta');
  assert(ready.data.database === true, 'PostgreSQL conectado');
  assert(ready.data.integrations.ai.configured === true, 'IA configurada');
  assert(ready.data.integrations.bible.configured === true, 'fonte bíblica configurada');
  assert(ready.data.integrations.billing.configured === true, 'Mercado Pago configurado');
  assert(ready.data.integrations.email.configured === true, 'Resend configurado');

  const registration = await api('/auth/register', {
    method: 'POST', expected: 201,
    body: { name: 'Smoke Homologação', email, password },
  });
  token = registration.data.token;
  await api('/auth/me', {
    method: 'PATCH', token,
    body: { profileType: 'CREATOR', bibleVersion: 'NVI', goals: ['DEVOTIONALS', 'POSTS'], onboardingCompleted: true },
  });

  const devotional = await api('/devotionals/generate', {
    method: 'POST', expected: 201, token, body: { theme: 'esperanca' },
  });
  assert(devotional.data.devotional.bibleSource === 'api-bible', 'devocional usa API.Bible');
  assert(!String(devotional.data.devotional.aiProvider).startsWith('local'), 'devocional usa IA externa');

  const post = await api('/posts/generate', {
    method: 'POST', expected: 201, token,
    body: { theme: 'paz', format: 'FEED', templateId: 'illuminated' },
  });
  assert(post.data.post.bibleSource === 'api-bible', 'post usa API.Bible');
  assert(!String(post.data.post.aiProvider).startsWith('local'), 'post usa IA externa');

  const prayer = await api('/prayers', {
    method: 'POST', expected: 201, token, body: { title: 'Smoke de homologação' },
  });
  assert(Boolean(prayer.data.prayer.id), 'oração persistida');
  const billing = await api('/billing/status', { token });
  assert(billing.data.billingConfigured === true, 'checkout habilitado');

  await api('/auth/me', { method: 'DELETE', token, body: { password } });
  token = '';
  console.log(`Smoke de homologação aprovado: ${assertions} asserções.`);
}

run().catch(async (error) => {
  console.error(error);
  if (token) {
    try { await api('/auth/me', { method: 'DELETE', token, body: { password } }); } catch { /* limpeza best effort */ }
  }
  process.exit(1);
});
