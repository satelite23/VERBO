const baseUrl = process.env.E2E_API_URL ?? 'http://127.0.0.1:4000/api';
const email = `qa.${Date.now()}@verbo.test`;
const initialPassword = 'Senha-Segura-123';
const newPassword = 'Nova-Senha-456';
let token = '';
let assertions = 0;

function assert(condition, message) {
  assertions += 1;
  if (!condition) throw new Error(`ASSERT: ${message}`);
}

async function api(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    method: options.method ?? 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
    },
    ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
  });
  const payload = await response.json().catch(() => ({}));
  const expected = Array.isArray(options.expected) ? options.expected : [options.expected ?? 200];
  if (!expected.includes(response.status)) {
    throw new Error(`${options.method ?? 'GET'} ${path}: esperado ${expected.join('/')}, recebido ${response.status}\n${JSON.stringify(payload)}`);
  }
  return { status: response.status, payload };
}

async function run() {
  console.log('1/12 saúde e autenticação');
  const health = await api('/health');
  assert(health.payload.success === true, 'health check');
  const ready = await api('/ready');
  assert(ready.payload.status === 'ready' && ready.payload.data.database === true, 'readiness com PostgreSQL');
  const registration = await api('/auth/register', {
    method: 'POST', expected: 201,
    body: { name: 'Pessoa QA', email, password: initialPassword, role: 'CHURCH_ADMIN' },
  });
  token = registration.payload.data.token;
  assert(registration.payload.data.user.role === 'USER', 'cadastro não eleva privilégio');

  console.log('2/12 onboarding e perfil');
  const profile = await api('/auth/me', {
    method: 'PATCH', token,
    body: { profileType: 'CHURCH', bibleVersion: 'NVI', goals: ['DEVOTIONALS', 'POSTS'], onboardingCompleted: true },
  });
  assert(profile.payload.data.user.onboardingCompleted === true, 'onboarding completo');
  assert(profile.payload.data.user.bibleVersion === 'NVI', 'versão bíblica persistida');

  console.log('3/12 devocional editável');
  const themes = await api('/devotionals/themes', { token });
  assert(themes.payload.data.themes.includes('esperanca'), 'temas disponíveis');
  const generatedDevotional = await api('/devotionals/generate', {
    method: 'POST', expected: 201, token, body: { theme: 'esperanca' },
  });
  const devotional = generatedDevotional.payload.data.devotional;
  assert(devotional.bibleSource === 'local-demo', 'fonte demonstrativa identificada');
  const editedDevotional = await api(`/devotionals/${devotional.id}`, {
    method: 'PATCH', token, body: { title: 'Esperança revisada pela pessoa QA' },
  });
  assert(editedDevotional.payload.data.devotional.title.includes('revisada'), 'devocional editado');

  console.log('4/12 editor visual e regras do plano');
  const generatedPost = await api('/posts/generate', {
    method: 'POST', expected: 201, token,
    body: { theme: 'paz', format: 'FEED', templateId: 'illuminated', bgColor: '#12162A', accentColor: '#C9A24B' },
  });
  const post = generatedPost.payload.data.post;
  const editedPost = await api(`/posts/${post.id}`, {
    method: 'PATCH', token,
    body: { templateId: 'minimal', fontFamily: 'fraunces', textAlign: 'center', fontScale: 105, overlayOpacity: 45 },
  });
  assert(editedPost.payload.data.post.templateId === 'minimal', 'design salvo');
  await api(`/posts/${post.id}`, { method: 'PATCH', token, expected: 403, body: { templateId: 'frame' } });
  await api(`/posts/${post.id}`, { method: 'PATCH', token, expected: 403, body: { logoUrl: 'data:image/png;base64,AAAA' } });

  console.log('5/12 pedidos de oração');
  const prayerCreated = await api('/prayers', {
    method: 'POST', expected: 201, token, body: { title: 'Pedido de QA', description: 'Fluxo ponta a ponta' },
  });
  const prayerId = prayerCreated.payload.data.prayer.id;
  const prayerUpdated = await api(`/prayers/${prayerId}`, { method: 'PATCH', token, body: { isAnswered: true } });
  assert(prayerUpdated.payload.data.prayer.answeredAt, 'data de resposta registrada');
  const prayers = await api('/prayers', { token });
  assert(prayers.payload.data.prayers.some((item) => item.id === prayerId), 'pedido listado');

  console.log('6/12 planos e check-in idempotente');
  const plans = await api('/reading-plans', { token });
  assert(plans.payload.data.plans.length === 3, 'seed criou três planos');
  const planId = plans.payload.data.plans[0].id;
  const enrollment = await api('/reading-plans/enroll', { method: 'POST', expected: 201, token, body: { planId } });
  assert(enrollment.payload.data.enrollment.currentDay === 1, 'plano iniciado no dia 1');
  const checkIn = await api('/reading-plans/checkin', { method: 'POST', token, body: { planId } });
  const completed = checkIn.payload.data.enrollment.completedDays;
  const duplicateCheckIn = await api('/reading-plans/checkin', { method: 'POST', token, body: { planId } });
  assert(duplicateCheckIn.payload.data.enrollment.completedDays === completed, 'check-in duplicado não avança');

  console.log('7/12 catálogo e checkout desconfigurado');
  const billing = await api('/billing/status', { token });
  assert(billing.payload.data.plan === 'FREE', 'plano padrão gratuito');
  assert(billing.payload.data.entitlements.watermark === true, 'marca-d’água no gratuito');
  await api('/billing/checkout', { method: 'POST', token, expected: 503, body: { plan: 'PRO', cycle: 'MONTHLY' } });

  console.log('8/12 limite mensal no backend');
  await api('/devotionals/generate', { method: 'POST', expected: 201, token, body: { theme: 'gratidao' } });
  await api('/posts/generate', { method: 'POST', expected: 429, token, body: { theme: 'fe', templateId: 'minimal' } });

  console.log('9/12 recuperação de senha');
  const forgot = await api('/auth/forgot-password', { method: 'POST', body: { email } });
  const resetUrl = forgot.payload.data?.developmentResetUrl;
  assert(resetUrl, 'link de desenvolvimento retornado');
  const resetToken = new URL(resetUrl).searchParams.get('token');
  assert(resetToken, 'token presente no link');
  await api('/auth/reset-password', { method: 'POST', body: { token: resetToken, password: newPassword } });
  await api('/auth/me', { token, expected: 401 });

  console.log('10/12 novo login após revogação');
  const login = await api('/auth/login', { method: 'POST', body: { email, password: newPassword } });
  token = login.payload.data.token;
  const me = await api('/auth/me', { token });
  assert(me.payload.data.user.email === email, 'novo token válido');

  console.log('11/12 isolamento e exclusões');
  await api(`/prayers/${prayerId}`, { method: 'DELETE', token });
  const ownPosts = await api('/posts', { token });
  assert(ownPosts.payload.data.posts.every((item) => item.userId === login.payload.data.user.id), 'conteúdo isolado por usuário');

  console.log('12/12 exclusão LGPD da conta');
  await api('/auth/me', { method: 'DELETE', token, body: { password: newPassword } });
  await api('/auth/me', { token, expected: 401 });

  console.log(`QA E2E aprovado: ${assertions} asserções.`);
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
