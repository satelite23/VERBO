#!/usr/bin/env sh
set -eu
: "${DATABASE_URL:?Defina DATABASE_URL para um banco PostgreSQL exclusivo de QA}"
: "${JWT_SECRET:?Defina JWT_SECRET com pelo menos 32 caracteres}"

if [ "${SKIP_NPM_CI:-0}" != "1" ]; then
  npm ci
fi
npx prisma generate
npx prisma migrate deploy
npm run prisma:seed
npm run build

PORT="${PORT:-4000}" NODE_ENV=test node dist/server.js > /tmp/verbo-qa-api.log 2>&1 &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM

attempt=0
until curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 30 ]; then
    cat /tmp/verbo-qa-api.log
    exit 1
  fi
  sleep 1
done

E2E_API_URL="http://127.0.0.1:${PORT}/api" node scripts/e2e-smoke.mjs
