import { afterEach, describe, expect, it, vi } from 'vitest';
import { env } from '../src/config/env';
import { generateDevotional } from '../src/services/ai.service';
import { fetchVerseFromExternalApi, getVerseByTheme } from '../src/services/bible.service';

const original = {
  aiProvider: env.aiProvider,
  aiFallbackToLocal: env.aiFallbackToLocal,
  geminiApiKey: env.geminiApiKey,
  bibleProvider: env.bibleProvider,
  bibleApiKey: env.bibleApiKey,
  bibleNviId: env.bibleIds.NVI,
};

afterEach(() => {
  env.aiProvider = original.aiProvider;
  env.aiFallbackToLocal = original.aiFallbackToLocal;
  env.geminiApiKey = original.geminiApiKey;
  env.bibleProvider = original.bibleProvider;
  env.bibleApiKey = original.bibleApiKey;
  env.bibleIds.NVI = original.bibleNviId;
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('fonte bíblica', () => {
  it('marca claramente o conteúdo local como demonstração', async () => {
    env.bibleProvider = 'local';
    const verse = await getVerseByTheme('fé', 'NVI');
    expect(verse.source).toBe('local-demo');
    expect(verse.version).toBe('DEMO');
    expect(verse.requestedVersion).toBe('NVI');
    expect(verse.passageId).toMatch(/^[A-Z0-9]+\./);
  });

  it('consulta uma passagem específica na API.Bible pelo backend', async () => {
    env.bibleProvider = 'api_bible';
    env.bibleApiKey = 'test-key';
    env.bibleIds.NVI = 'nvi-test-id';
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({
      data: {
        id: 'JHN.3.16',
        reference: 'João 3:16',
        content: '<p>Porque Deus amou o mundo.</p>',
        copyright: 'Tradução de teste',
      },
      meta: { fumsId: 'fums-test' },
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
    vi.stubGlobal('fetch', fetchMock);

    const verse = await fetchVerseFromExternalApi('João 3:16', 'NVI', 'JHN.3.16');

    expect(fetchMock).toHaveBeenCalledOnce();
    expect(String(fetchMock.mock.calls[0][0])).toContain('/bibles/nvi-test-id/passages/JHN.3.16');
    expect(verse).toMatchObject({
      ref: 'João 3:16',
      texto: 'Porque Deus amou o mundo.',
      version: 'NVI',
      source: 'api-bible',
      copyright: 'Tradução de teste',
    });
  });
});

describe('adaptadores editoriais', () => {
  it('usa geração local determinística sem chave externa', async () => {
    env.aiProvider = 'local';
    const result = await generateDevotional('esperança', 'Ana', 'ARC');
    expect(result.provider).toBe('local');
    expect(result.model).toBe('template-v1');
    expect(result.reflection).toContain('Ana');
    expect(result.verse.source).toBe('local-demo');
  });

  it('valida a saída JSON do Gemini antes de retorná-la', async () => {
    env.aiProvider = 'gemini';
    env.geminiApiKey = 'gemini-test';
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: JSON.stringify({
        title: 'Esperança para hoje',
        reflection: 'A esperança cristã nos ajuda a atravessar dias difíceis com confiança e humildade. Ela não ignora os problemas, mas oferece um ponto firme para escolher o próximo passo com sabedoria e apoio da comunidade.',
        prayer: 'Senhor, renova minha esperança e ajuda-me a caminhar com humildade e constância. Amém.',
        question: 'Qual pequeno passo de esperança você pode praticar hoje?',
      }) }] } }],
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
    vi.stubGlobal('fetch', fetchMock);

    const result = await generateDevotional('esperança', undefined, 'ARC');
    expect(result.provider).toBe('gemini');
    expect(result.title).toBe('Esperança para hoje');
    expect(fetchMock).toHaveBeenCalledOnce();
  });

  it('volta ao gerador local quando a saída externa é inválida', async () => {
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => undefined);
    env.aiProvider = 'gemini';
    env.aiFallbackToLocal = true;
    env.geminiApiKey = 'gemini-test';
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: '{"title":"incompleto"}' }] } }],
    }), { status: 200, headers: { 'Content-Type': 'application/json' } })));

    const result = await generateDevotional('paz', undefined, 'ARC');
    expect(result.provider).toBe('local-fallback');
    expect(result.reflection.length).toBeGreaterThan(80);
    expect(consoleSpy).toHaveBeenCalled();
    consoleSpy.mockRestore();
  });
});
