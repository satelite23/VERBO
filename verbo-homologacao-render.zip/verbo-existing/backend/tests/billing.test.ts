import { createHmac } from 'node:crypto';
import type { Request } from 'express';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { env } from '../src/config/env';
import { mapMercadoPagoStatus } from '../src/controllers/billing.controller';
import { verifyMercadoPagoSignature } from '../src/controllers/mercado-pago-webhook.controller';
import { getPlanAmount, planCatalog } from '../src/services/plan.service';
import { createPreapproval } from '../src/services/mercado-pago.service';

const originalSecret = env.mercadoPagoWebhookSecret;
const originalAccessToken = env.mercadoPagoAccessToken;
afterEach(() => {
  env.mercadoPagoWebhookSecret = originalSecret;
  env.mercadoPagoAccessToken = originalAccessToken;
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('planos comerciais', () => {
  it('aplica limites e marca-d’água por plano', () => {
    const catalog = planCatalog();
    expect(catalog.FREE.watermark).toBe(true);
    expect(catalog.FREE.templates).toEqual(['illuminated', 'minimal']);
    expect(catalog.PRO.watermark).toBe(false);
    expect(catalog.CHURCH.customLogo).toBe(true);
    expect(catalog.CHURCH.monthlyGenerationLimit).toBeGreaterThan(catalog.PRO.monthlyGenerationLimit);
  });

  it('resolve preços mensais e anuais em reais', () => {
    expect(getPlanAmount('PRO', 'MONTHLY')).toBe(29.9);
    expect(getPlanAmount('CHURCH', 'MONTHLY')).toBe(99.9);
    expect(getPlanAmount('PRO', 'ANNUAL')).toBeGreaterThan(200);
  });

  it('mapeia os estados do Mercado Pago', () => {
    expect(mapMercadoPagoStatus('authorized')).toBe('ACTIVE');
    expect(mapMercadoPagoStatus('paused')).toBe('PAUSED');
    expect(mapMercadoPagoStatus('cancelled')).toBe('CANCELLED');
    expect(mapMercadoPagoStatus('pending')).toBe('PENDING');
  });
});

describe('cliente Mercado Pago', () => {
  it('cria uma assinatura pendente com referência e recorrência mensal', async () => {
    env.mercadoPagoAccessToken = 'access-token-test';
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({
      id: 'preapproval-123',
      status: 'pending',
      external_reference: 'external-123',
      init_point: 'https://www.mercadopago.com.br/subscriptions/checkout',
    }), { status: 201, headers: { 'Content-Type': 'application/json' } }));
    vi.stubGlobal('fetch', fetchMock);

    const result = await createPreapproval({
      email: 'pessoa@exemplo.com',
      reason: 'Verbo Pro — mensal',
      externalReference: 'external-123',
      amount: 29.9,
      cycle: 'MONTHLY',
    });

    expect(result.status).toBe('pending');
    const [url, options] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toBe('https://api.mercadopago.com/preapproval');
    expect(options.headers).toEqual(expect.objectContaining({
      Authorization: 'Bearer access-token-test',
      'Content-Type': 'application/json',
    }));
    expect(JSON.parse(String(options.body))).toEqual(expect.objectContaining({
      external_reference: 'external-123',
      payer_email: 'pessoa@exemplo.com',
      status: 'pending',
      auto_recurring: expect.objectContaining({ frequency: 1, frequency_type: 'months', transaction_amount: 29.9, currency_id: 'BRL' }),
    }));
  });
});

describe('assinatura de webhook', () => {
  it('valida o HMAC no formato exigido pelo provedor', () => {
    env.mercadoPagoWebhookSecret = 'webhook-secret-test';
    const dataId = 'PREAPPROVAL-ABC';
    const requestId = 'request-123';
    const ts = '1784050000';
    const manifest = `id:${dataId.toLowerCase()};request-id:${requestId};ts:${ts};`;
    const signature = createHmac('sha256', env.mercadoPagoWebhookSecret).update(manifest).digest('hex');
    const request = {
      header(name: string) {
        if (name === 'x-signature') return `ts=${ts},v1=${signature}`;
        if (name === 'x-request-id') return requestId;
        return undefined;
      },
    } as unknown as Request;

    expect(verifyMercadoPagoSignature(request, dataId)).toBe(true);
  });

  it('rejeita assinatura alterada', () => {
    env.mercadoPagoWebhookSecret = 'webhook-secret-test';
    const request = {
      header(name: string) {
        if (name === 'x-signature') return 'ts=1784050000,v1=0000000000000000000000000000000000000000000000000000000000000000';
        if (name === 'x-request-id') return 'request-123';
        return undefined;
      },
    } as unknown as Request;
    expect(verifyMercadoPagoSignature(request, 'preapproval-abc')).toBe(false);
  });
});
