import { describe, expect, it } from 'vitest';
import {
  buildSequentialPlan,
  GOSPEL_BOOKS,
  NEW_TESTAMENT_BOOKS,
  PLAN_IDS,
} from '../prisma/seed';

describe('planos de leitura padrão', () => {
  it('usa UUIDs válidos e estáveis', () => {
    const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    Object.values(PLAN_IDS).forEach((id) => expect(id).toMatch(uuid));
  });

  it('distribui todo o Novo Testamento em 90 dias', () => {
    const days = buildSequentialPlan(90, NEW_TESTAMENT_BOOKS);
    expect(days).toHaveLength(90);
    expect(days[0]).toMatchObject({ dayNumber: 1, reference: 'Mateus 1–3' });
    expect(days.at(-1)).toMatchObject({ dayNumber: 90, reference: 'Apocalipse 21–22' });
  });

  it('distribui todos os Evangelhos em 30 dias', () => {
    const days = buildSequentialPlan(30, GOSPEL_BOOKS);
    expect(days).toHaveLength(30);
    expect(days[0].reference).toBe('Mateus 1–3');
    expect(days.at(-1)?.reference).toBe('João 20–21');
  });

  it('rejeita duração maior que o total de capítulos', () => {
    expect(() => buildSequentialPlan(4, [['Filemom', 1]])).toThrow();
  });
});
