import { describe, expect, it } from 'vitest';
import { dayDistance, isNextLocalDay, localDateKey } from '../src/utils/calendar';

describe('calendário no fuso do produto', () => {
  it('mantém o dia anterior antes da meia-noite em São Paulo', () => {
    const instant = new Date('2026-07-15T02:30:00.000Z');
    expect(localDateKey(instant, 'America/Sao_Paulo')).toBe('2026-07-14');
  });

  it('reconhece dias locais consecutivos', () => {
    const previous = new Date('2026-07-14T12:00:00.000Z');
    const current = new Date('2026-07-15T12:00:00.000Z');
    expect(dayDistance(previous, current, 'America/Sao_Paulo')).toBe(1);
    expect(isNextLocalDay(previous, current, 'America/Sao_Paulo')).toBe(true);
  });

  it('não considera intervalo de dois dias como sequência', () => {
    const previous = new Date('2026-07-13T12:00:00.000Z');
    const current = new Date('2026-07-15T12:00:00.000Z');
    expect(isNextLocalDay(previous, current, 'America/Sao_Paulo')).toBe(false);
  });
});
