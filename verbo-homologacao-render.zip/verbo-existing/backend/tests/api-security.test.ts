import request from 'supertest';
import { beforeEach, describe, expect, it, vi } from 'vitest';

const db = vi.hoisted(() => ({
  userFindUnique: vi.fn(),
  userCreate: vi.fn(),
  userUpdate: vi.fn(),
  postFindMany: vi.fn(),
  postFindFirst: vi.fn(),
  postUpdate: vi.fn(),
  subscriptionFindUnique: vi.fn(),
}));

vi.mock('../src/config/db', () => ({
  prisma: {
    user: {
      findUnique: db.userFindUnique,
      create: db.userCreate,
      update: db.userUpdate,
    },
    post: {
      findMany: db.postFindMany,
      findFirst: db.postFindFirst,
      update: db.postUpdate,
    },
    subscription: {
      findUnique: db.subscriptionFindUnique,
    },
  },
}));

import app from '../src/app';
import { signToken } from '../src/services/token.service';

describe('segurança da API', () => {
  beforeEach(() => {
    db.userFindUnique.mockReset();
    db.userCreate.mockReset();
    db.userUpdate.mockReset();
    db.postFindMany.mockReset();
    db.postFindFirst.mockReset();
    db.postUpdate.mockReset();
    db.subscriptionFindUnique.mockReset();
    db.subscriptionFindUnique.mockResolvedValue(null);
  });

  it('sempre cria cadastro público com papel USER', async () => {
    db.userFindUnique.mockResolvedValue(null);
    db.userCreate.mockImplementation(async ({ data }: { data: Record<string, unknown> }) => ({
      id: '68db7238-3bcc-42f1-8725-078d4059d8e9',
      ...data,
      profileType: 'PERSONAL',
      bibleVersion: 'ARC',
      goals: [],
      onboardingCompleted: false,
      sessionVersion: 0,
      createdAt: new Date('2026-07-14T12:00:00Z'),
    }));

    const response = await request(app).post('/api/auth/register').send({
      name: 'Pessoa Teste',
      email: 'PESSOA@EXEMPLO.COM',
      password: 'senha-forte-123',
      role: 'CHURCH_ADMIN',
    });

    expect(response.status).toBe(201);
    expect(response.body.data.user.role).toBe('USER');
    expect(db.userCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ role: 'USER', email: 'pessoa@exemplo.com' }),
      }),
    );
  });

  it('rejeita senha curta no cadastro', async () => {
    const response = await request(app).post('/api/auth/register').send({
      name: 'Pessoa Teste',
      email: 'pessoa@exemplo.com',
      password: '123456',
    });

    expect(response.status).toBe(422);
    expect(db.userCreate).not.toHaveBeenCalled();
  });

  it('protege rotas sem token', async () => {
    const response = await request(app).get('/api/posts');
    expect(response.status).toBe(401);
  });

  it('filtra listagens pelo usuário contido no token', async () => {
    db.postFindMany.mockResolvedValue([]);
    const userId = 'd27ed6df-e18e-45a9-a696-3edbc653f4de';
    db.userFindUnique.mockResolvedValue({
      id: userId,
      email: 'pessoa@exemplo.com',
      role: 'USER',
      sessionVersion: 0,
    });
    const token = signToken({
      id: userId,
      email: 'pessoa@exemplo.com',
      role: 'USER',
      sessionVersion: 0,
    });

    const response = await request(app)
      .get('/api/posts')
      .set('Authorization', `Bearer ${token}`);

    expect(response.status).toBe(200);
    expect(db.postFindMany).toHaveBeenCalledWith(
      expect.objectContaining({ where: { userId } }),
    );
  });

  it('revoga um token quando a versão de sessão muda', async () => {
    const userId = 'd27ed6df-e18e-45a9-a696-3edbc653f4de';
    db.userFindUnique.mockResolvedValue({
      id: userId,
      email: 'pessoa@exemplo.com',
      role: 'USER',
      sessionVersion: 1,
    });
    const token = signToken({
      id: userId,
      email: 'pessoa@exemplo.com',
      role: 'USER',
      sessionVersion: 0,
    });

    const response = await request(app)
      .get('/api/posts')
      .set('Authorization', `Bearer ${token}`);

    expect(response.status).toBe(401);
    expect(db.postFindMany).not.toHaveBeenCalled();
  });

  it('permite atualizar somente campos seguros do perfil', async () => {
    const userId = 'd27ed6df-e18e-45a9-a696-3edbc653f4de';
    const authUser = {
      id: userId,
      email: 'pessoa@exemplo.com',
      role: 'USER',
      sessionVersion: 0,
    };
    db.userFindUnique.mockResolvedValue(authUser);
    db.userUpdate.mockImplementation(async ({ data }: { data: Record<string, unknown> }) => ({
      ...authUser,
      name: 'Pessoa Atualizada',
      profileType: data.profileType,
      churchName: null,
      bibleVersion: data.bibleVersion,
      goals: data.goals,
      onboardingCompleted: data.onboardingCompleted,
      createdAt: new Date('2026-07-14T12:00:00Z'),
    }));
    const token = signToken({ ...authUser, role: 'USER' });

    const response = await request(app)
      .patch('/api/auth/me')
      .set('Authorization', `Bearer ${token}`)
      .send({
        profileType: 'CHURCH',
        bibleVersion: 'NVI',
        goals: ['POSTS', 'DEVOTIONALS'],
        onboardingCompleted: true,
        role: 'CHURCH_ADMIN',
      });

    expect(response.status).toBe(200);
    expect(db.userUpdate).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.not.objectContaining({ role: 'CHURCH_ADMIN' }),
    }));
    expect(response.body.data.user.profileType).toBe('CHURCH');
  });

  it('aceita apenas imagens raster seguras no editor visual', async () => {
    const userId = 'd27ed6df-e18e-45a9-a696-3edbc653f4de';
    const authUser = { id: userId, email: 'pessoa@exemplo.com', role: 'USER', sessionVersion: 0 };
    db.userFindUnique.mockResolvedValue(authUser);
    db.postFindFirst.mockResolvedValue({ id: 'post-1', userId });
    db.subscriptionFindUnique.mockResolvedValue({ plan: 'CHURCH', status: 'ACTIVE', currentPeriodEnd: null });
    db.postUpdate.mockImplementation(async ({ data }: { data: Record<string, unknown> }) => ({ id: 'post-1', ...data }));
    const token = signToken({ ...authUser, role: 'USER' });

    const accepted = await request(app)
      .patch('/api/posts/post-1')
      .set('Authorization', `Bearer ${token}`)
      .send({
        templateId: 'editorial',
        imageUrl: 'data:image/png;base64,AAAA',
        logoUrl: 'data:image/webp;base64,AAAA',
        fontFamily: 'fraunces',
        textAlign: 'left',
        overlayOpacity: 55,
        fontScale: 110,
      });
    expect(accepted.status).toBe(200);
    expect(db.postUpdate).toHaveBeenCalled();

    const rejected = await request(app)
      .patch('/api/posts/post-1')
      .set('Authorization', `Bearer ${token}`)
      .send({ logoUrl: 'data:image/svg+xml;base64,PHN2Zz4=' });
    expect(rejected.status).toBe(422);
  });

  it('bloqueia template premium para o plano gratuito', async () => {
    const userId = 'd27ed6df-e18e-45a9-a696-3edbc653f4de';
    const authUser = { id: userId, email: 'pessoa@exemplo.com', role: 'USER', sessionVersion: 0 };
    db.userFindUnique.mockResolvedValue(authUser);
    db.subscriptionFindUnique.mockResolvedValue(null);
    const token = signToken({ ...authUser, role: 'USER' });

    const response = await request(app)
      .patch('/api/posts/post-1')
      .set('Authorization', `Bearer ${token}`)
      .send({ templateId: 'frame' });

    expect(response.status).toBe(403);
    expect(db.postUpdate).not.toHaveBeenCalled();
  });
});
