-- AlterTable
ALTER TABLE "devotionals"
  ADD COLUMN "bibleVersion" TEXT NOT NULL DEFAULT 'DEMO',
  ADD COLUMN "bibleSource" TEXT NOT NULL DEFAULT 'local-demo',
  ADD COLUMN "bibleCopyright" TEXT,
  ADD COLUMN "aiProvider" TEXT NOT NULL DEFAULT 'local',
  ADD COLUMN "aiModel" TEXT NOT NULL DEFAULT 'template-v1',
  ADD COLUMN "promptVersion" TEXT NOT NULL DEFAULT 'devotional-v1';

-- AlterTable
ALTER TABLE "posts"
  ADD COLUMN "bibleVersion" TEXT NOT NULL DEFAULT 'DEMO',
  ADD COLUMN "bibleSource" TEXT NOT NULL DEFAULT 'local-demo',
  ADD COLUMN "bibleCopyright" TEXT,
  ADD COLUMN "aiProvider" TEXT NOT NULL DEFAULT 'local',
  ADD COLUMN "aiModel" TEXT NOT NULL DEFAULT 'template-v1',
  ADD COLUMN "promptVersion" TEXT NOT NULL DEFAULT 'post-v1';
