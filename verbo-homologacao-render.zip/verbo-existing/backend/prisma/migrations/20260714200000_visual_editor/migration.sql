-- AlterTable
ALTER TABLE "posts"
  ALTER COLUMN "templateId" SET DEFAULT 'illuminated',
  ALTER COLUMN "bgColor" SET DEFAULT '#12162A',
  ALTER COLUMN "accentColor" SET DEFAULT '#C9A24B',
  ADD COLUMN "logoUrl" TEXT,
  ADD COLUMN "fontFamily" TEXT NOT NULL DEFAULT 'fraunces',
  ADD COLUMN "textAlign" TEXT NOT NULL DEFAULT 'center',
  ADD COLUMN "overlayOpacity" INTEGER NOT NULL DEFAULT 45,
  ADD COLUMN "fontScale" INTEGER NOT NULL DEFAULT 100;

UPDATE "posts" SET "templateId" = 'illuminated' WHERE "templateId" = 'classic';
