-- CreateEnum
CREATE TYPE "Role" AS ENUM ('USER', 'CHURCH_ADMIN');

-- CreateEnum
CREATE TYPE "PostFormat" AS ENUM ('FEED', 'STORY', 'WHATSAPP');

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "role" "Role" NOT NULL DEFAULT 'USER',
    "churchName" TEXT,
    "bibleVersion" TEXT NOT NULL DEFAULT 'ARC',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "devotionals" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "theme" TEXT NOT NULL,
    "verseRef" TEXT NOT NULL,
    "verseText" TEXT NOT NULL,
    "reflection" TEXT NOT NULL,
    "prayer" TEXT NOT NULL,
    "question" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "devotionals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "posts" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "theme" TEXT NOT NULL,
    "verseRef" TEXT NOT NULL,
    "verseText" TEXT NOT NULL,
    "caption" TEXT NOT NULL,
    "format" "PostFormat" NOT NULL DEFAULT 'FEED',
    "templateId" TEXT NOT NULL DEFAULT 'classic',
    "bgColor" TEXT NOT NULL DEFAULT '#2F3E6E',
    "accentColor" TEXT NOT NULL DEFAULT '#B08D57',
    "imageUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "posts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "prayer_requests" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "prayDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isAnswered" BOOLEAN NOT NULL DEFAULT false,
    "answeredAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "prayer_requests_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reading_plans" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "durationDays" INTEGER NOT NULL,
    "isSystem" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "reading_plans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reading_plan_days" (
    "id" TEXT NOT NULL,
    "planId" TEXT NOT NULL,
    "dayNumber" INTEGER NOT NULL,
    "reference" TEXT NOT NULL,
    "description" TEXT,

    CONSTRAINT "reading_plan_days_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_plan_enrollments" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "planId" TEXT NOT NULL,
    "currentDay" INTEGER NOT NULL DEFAULT 1,
    "completedDays" INTEGER NOT NULL DEFAULT 0,
    "streak" INTEGER NOT NULL DEFAULT 0,
    "lastCheckIn" TIMESTAMP(3),
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "user_plan_enrollments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reading_check_ins" (
    "id" TEXT NOT NULL,
    "enrollmentId" TEXT NOT NULL,
    "dayNumber" INTEGER NOT NULL,
    "localDate" TEXT NOT NULL,
    "completedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "reading_check_ins_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE INDEX "devotionals_userId_createdAt_idx" ON "devotionals"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "posts_userId_createdAt_idx" ON "posts"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "prayer_requests_userId_prayDate_idx" ON "prayer_requests"("userId", "prayDate");

-- CreateIndex
CREATE UNIQUE INDEX "reading_plan_days_planId_dayNumber_key" ON "reading_plan_days"("planId", "dayNumber");

-- CreateIndex
CREATE INDEX "user_plan_enrollments_userId_startedAt_idx" ON "user_plan_enrollments"("userId", "startedAt");

-- CreateIndex
CREATE UNIQUE INDEX "user_plan_enrollments_userId_planId_key" ON "user_plan_enrollments"("userId", "planId");

-- CreateIndex
CREATE INDEX "reading_check_ins_enrollmentId_completedAt_idx" ON "reading_check_ins"("enrollmentId", "completedAt");

-- CreateIndex
CREATE UNIQUE INDEX "reading_check_ins_enrollmentId_dayNumber_key" ON "reading_check_ins"("enrollmentId", "dayNumber");

-- CreateIndex
CREATE UNIQUE INDEX "reading_check_ins_enrollmentId_localDate_key" ON "reading_check_ins"("enrollmentId", "localDate");

-- AddForeignKey
ALTER TABLE "devotionals" ADD CONSTRAINT "devotionals_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "posts" ADD CONSTRAINT "posts_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "prayer_requests" ADD CONSTRAINT "prayer_requests_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reading_plan_days" ADD CONSTRAINT "reading_plan_days_planId_fkey" FOREIGN KEY ("planId") REFERENCES "reading_plans"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_plan_enrollments" ADD CONSTRAINT "user_plan_enrollments_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_plan_enrollments" ADD CONSTRAINT "user_plan_enrollments_planId_fkey" FOREIGN KEY ("planId") REFERENCES "reading_plans"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reading_check_ins" ADD CONSTRAINT "reading_check_ins_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES "user_plan_enrollments"("id") ON DELETE CASCADE ON UPDATE CASCADE;

