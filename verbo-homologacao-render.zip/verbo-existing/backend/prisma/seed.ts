import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const PLAN_IDS = {
  newTestament90: '10000000-0000-4000-8000-000000000090',
  gospels30: '10000000-0000-4000-8000-000000000030',
  psalms7: '10000000-0000-4000-8000-000000000007',
} as const;

export const NEW_TESTAMENT_BOOKS: Array<[string, number]> = [
  ['Mateus', 28],
  ['Marcos', 16],
  ['Lucas', 24],
  ['João', 21],
  ['Atos', 28],
  ['Romanos', 16],
  ['1 Coríntios', 16],
  ['2 Coríntios', 13],
  ['Gálatas', 6],
  ['Efésios', 6],
  ['Filipenses', 4],
  ['Colossenses', 4],
  ['1 Tessalonicenses', 5],
  ['2 Tessalonicenses', 3],
  ['1 Timóteo', 6],
  ['2 Timóteo', 4],
  ['Tito', 3],
  ['Filemom', 1],
  ['Hebreus', 13],
  ['Tiago', 5],
  ['1 Pedro', 5],
  ['2 Pedro', 3],
  ['1 João', 5],
  ['2 João', 1],
  ['3 João', 1],
  ['Judas', 1],
  ['Apocalipse', 22],
];

export const GOSPEL_BOOKS = NEW_TESTAMENT_BOOKS.slice(0, 4);

async function main() {
  console.log('🌱 Semeando planos de leitura padrão...');

  const newTestamentDays = buildSequentialPlan(90, NEW_TESTAMENT_BOOKS);
  const gospelDays = buildSequentialPlan(30, GOSPEL_BOOKS);

  const novoTestamento90 = await upsertSystemPlan({
    id: PLAN_IDS.newTestament90,
    name: 'Novo Testamento em 90 dias',
    description: 'Percorra os 260 capítulos do Novo Testamento em três meses, em ordem bíblica.',
    durationDays: 90,
    days: newTestamentDays,
  });

  const evangelhos30 = await upsertSystemPlan({
    id: PLAN_IDS.gospels30,
    name: 'Os 4 Evangelhos em 30 dias',
    description: 'Conheça a vida de Jesus lendo os 89 capítulos de Mateus, Marcos, Lucas e João.',
    durationDays: 30,
    days: gospelDays,
  });

  const salmos7 = await upsertSystemPlan({
    id: PLAN_IDS.psalms7,
    name: 'Salmos de Confiança — 7 dias',
    description: 'Uma semana meditando em Salmos que fortalecem a fé.',
    durationDays: 7,
    days: [
      { dayNumber: 1, reference: 'Salmos 23', description: 'O Senhor é o meu pastor' },
      { dayNumber: 2, reference: 'Salmos 27', description: 'O Senhor é a minha luz e a minha salvação' },
      { dayNumber: 3, reference: 'Salmos 34', description: 'Bendirei ao Senhor em todo tempo' },
      { dayNumber: 4, reference: 'Salmos 46', description: 'Deus é o nosso refúgio e a nossa fortaleza' },
      { dayNumber: 5, reference: 'Salmos 91', description: 'Habitar no esconderijo do Altíssimo' },
      { dayNumber: 6, reference: 'Salmos 121', description: 'Elevo os meus olhos para os montes' },
      { dayNumber: 7, reference: 'Salmos 139', description: 'Tu me sondas e me conheces' },
    ],
  });

  console.log('✅ Planos criados:', [novoTestamento90.name, evangelhos30.name, salmos7.name].join(', '));
}

async function upsertSystemPlan(input: {
  id: string;
  name: string;
  description: string;
  durationDays: number;
  days: Array<{ dayNumber: number; reference: string; description: string | null }>;
}) {
  return prisma.$transaction(async (tx) => {
    const plan = await tx.readingPlan.upsert({
      where: { id: input.id },
      update: {
        name: input.name,
        description: input.description,
        durationDays: input.durationDays,
        isSystem: true,
      },
      create: {
        id: input.id,
        name: input.name,
        description: input.description,
        durationDays: input.durationDays,
        isSystem: true,
      },
    });

    await tx.readingPlanDay.deleteMany({ where: { planId: plan.id } });
    await tx.readingPlanDay.createMany({
      data: input.days.map((day) => ({ ...day, planId: plan.id })),
    });
    return plan;
  });
}

/** Distribui todos os capítulos informados, em ordem, pelo número exato de dias. */
export function buildSequentialPlan(
  duration: number,
  books: Array<[string, number]>,
): Array<{ dayNumber: number; reference: string; description: null }> {
  const chapters = books.flatMap(([book, count]) =>
    Array.from({ length: count }, (_, index) => ({ book, chapter: index + 1 })),
  );

  if (duration < 1 || duration > chapters.length) {
    throw new Error('A duração precisa estar entre 1 e o total de capítulos do plano.');
  }

  const baseSize = Math.floor(chapters.length / duration);
  const extraDays = chapters.length % duration;
  let cursor = 0;

  return Array.from({ length: duration }, (_, index) => {
    const size = baseSize + (index < extraDays ? 1 : 0);
    const group = chapters.slice(cursor, cursor + size);
    cursor += size;
    return {
      dayNumber: index + 1,
      reference: collapseReferences(group),
      description: null,
    };
  });
}

function collapseReferences(group: Array<{ book: string; chapter: number }>) {
  const ranges: Array<{ book: string; start: number; end: number }> = [];
  for (const chapter of group) {
    const previous = ranges.at(-1);
    if (previous?.book === chapter.book && previous.end + 1 === chapter.chapter) {
      previous.end = chapter.chapter;
    } else {
      ranges.push({ book: chapter.book, start: chapter.chapter, end: chapter.chapter });
    }
  }

  return ranges
    .map(({ book, start, end }) => `${book} ${start}${end > start ? `–${end}` : ''}`)
    .join('; ');
}

if (require.main === module) {
  main()
    .catch((error) => {
      console.error(error);
      process.exit(1);
    })
    .finally(async () => {
      await prisma.$disconnect();
    });
}
