# Fonte bíblica e IA responsável — Verbo

**Data:** 14 de julho de 2026  
**Status:** implementação concluída e validada em modo local/teste

## Arquitetura

```text
Tema escolhido
      ↓
Referência canônica do banco curado
      ↓
Fonte bíblica (local-demo ou API.Bible)
      ↓
Texto e referência verificados
      ↓
Gerador editorial (local, Anthropic, OpenAI ou Gemini)
      ↓
Validação Zod da saída JSON
      ↓
Persistência com proveniência completa
```

## Fonte bíblica

- `local`: mantém o banco demonstrativo e marca `version=DEMO` e `source=local-demo`.
- `api_bible`: consulta no backend o endpoint de passagens da API.Bible por Bible ID e Passage ID.
- A chave nunca é enviada ao React.
- IDs canônicos foram mapeados para as referências do banco temático.
- IDs das traduções ficam em variáveis de ambiente porque dependem do acesso liberado na conta API.Bible.
- Texto recebido é limpo e validado antes do uso.
- Copyright e identificador FUMS são capturados quando disponíveis.
- Falhas podem interromper a geração ou cair no modo demonstrativo, conforme configuração.

Documentação oficial usada:

- https://docs.api.bible/guides/bibles/
- https://docs.api.bible/guides/passages/
- https://docs.api.bible/guides/search/

## Geração editorial

Provedores disponíveis:

- `local`
- `anthropic`
- `openai`
- `gemini`

Cada adaptador:

1. Recebe o texto bíblico já escolhido pela camada anterior.
2. É instruído a não criar, completar ou modificar versículos.
3. Deve devolver apenas JSON.
4. Tem sua resposta analisada e validada por Zod.
5. Não pode persistir conteúdo incompleto.
6. Pode usar fallback local se a configuração permitir.

## Segurança editorial

O prompt-base evita:

- Promessas absolutas.
- Manipulação e culpa.
- Diagnóstico clínico.
- Substituição de orientação profissional ou pastoral.
- Atribuição de novas falas a Deus.
- Criação ou alteração do texto bíblico.

## Proveniência

Devocionais e posts agora registram:

- Tradução bíblica usada.
- Fonte bíblica.
- Copyright.
- Provedor de IA.
- Modelo.
- Versão do prompt.

A interface informa quando o texto é demonstrativo e precisa de conferência.

## Limites e custo

`GENERATION_LIMIT_MONTHLY` controla o total inicial de devocionais e posts gerados por usuário no mês. O padrão é 10 e poderá ser substituído pelas regras dos planos comerciais.

## Testes

Foram validados:

- Marcação explícita do texto local como demonstração.
- Contrato de passagem da API.Bible.
- Limpeza de HTML do texto externo.
- Geração local.
- Saída estruturada do Gemini.
- Rejeição de JSON incompleto.
- Fallback local em falha externa.

## Configuração pendente para uso real

1. Criar conta e obter chave da API.Bible.
2. Listar as Bíblias liberadas para essa chave.
3. Preencher os IDs das traduções realmente licenciadas.
4. Escolher um provedor de IA e preencher sua chave.
5. Desabilitar fallback em homologação para testar falhas reais, se desejado.
6. Validar copyright e requisitos de atribuição com o plano contratado.
