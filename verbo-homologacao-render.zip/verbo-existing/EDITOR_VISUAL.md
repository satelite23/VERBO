# Editor visual e exportação — Verbo

> **Atualização:** planos e Mercado Pago também foram implementados. Consulte `PLANOS_E_MERCADO_PAGO.md`.

**Data:** 14 de julho de 2026  
**Status:** concluído

## Recursos implementados

### Formatos

- Feed 1:1 — exportação 1080 × 1080.
- Stories 9:16 — exportação 1080 × 1920.
- WhatsApp 9:16 — exportação 1080 × 1920.

### Templates

- **Iluminura:** cartão em pergaminho como elemento de assinatura.
- **Essencial:** composição limpa e contemplativa.
- **Editorial:** eixo lateral e hierarquia de revista.
- **Moldura:** composição clássica delimitada pelo dourado.

### Controles

- Quatro paletas iniciais.
- Cores de fundo e destaque livres.
- Fraunces, Inter e IBM Plex Mono.
- Alinhamento à esquerda, centro ou direita.
- Escala tipográfica de 70% a 140%.
- Intensidade de sobreposição sobre imagem.
- Alteração de formato dentro do editor.
- Legenda editável e copiável.

### Imagens

- Upload de fundo em PNG, JPEG ou WebP.
- Upload de logo em PNG ou WebP.
- Redimensionamento realizado no navegador.
- Compressão da imagem de fundo.
- Transparência preservada no logo PNG.
- SVG rejeitado pelo backend.
- Limites de tamanho validados no cliente e servidor.

### Exportação

- PNG de alta resolução.
- PDF com as dimensões do formato selecionado.
- Fontes aguardadas antes da captura.
- Bibliotecas de exportação carregadas sob demanda para não aumentar o carregamento inicial.

### Persistência

São salvos no post:

- Template.
- Formato.
- Paleta.
- Fundo e destaque.
- Imagem.
- Logo.
- Tipografia.
- Alinhamento.
- Sobreposição.
- Escala do texto.
- Legenda.

## Decisão para o MVP

Imagens são redimensionadas e persistidas como Data URL. Isso entrega um editor funcional sem exigir infraestrutura de arquivos nesta fase.

Antes de escala pública, migrar para Cloudflare R2, AWS S3 ou serviço equivalente, armazenando apenas a URL no PostgreSQL. Essa migração reduzirá tamanho de registros e tráfego da API.

## Segurança

- Corpo JSON limitado a 3 MB.
- Apenas Data URLs raster PNG/JPEG/WebP ou URLs HTTPS são aceitas.
- Logo limitado a aproximadamente 300 KB após processamento.
- Fundo limitado a aproximadamente 1,4 MB após processamento.
- Arquivo original limitado a 10 MB no navegador.
- Conteúdo SVG não é aceito.

## Validação

- Frontend lint aprovado.
- Frontend typecheck aprovado.
- Frontend build aprovado.
- Backend lint aprovado.
- Backend typecheck aprovado.
- Backend build aprovado.
- 19 testes automatizados aprovados.
- Auditorias npm sem vulnerabilidades conhecidas.

## Próxima fase

Planos comerciais e Mercado Pago:

1. Modelar Gratuito, Pro e Igreja.
2. Transformar o limite mensal em regra por plano.
3. Aplicar marca-d’água conforme o plano.
4. Implementar checkout e recorrência.
5. Validar webhooks com assinatura.
6. Criar pausa, cancelamento e retorno.
