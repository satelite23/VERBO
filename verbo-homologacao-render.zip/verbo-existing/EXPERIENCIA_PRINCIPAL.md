# Experiência principal — Verbo

> **Atualização:** as fases de fonte bíblica/IA e editor visual também foram concluídas. Consulte `FONTE_BIBLICA_IA.md` e `EDITOR_VISUAL.md`.

**Data:** 14 de julho de 2026  
**Fase:** concluída sobre a base estabilizada

## Entregas

### Aquisição e confiança

- Landing page pública alinhada ao sistema visual do Verbo.
- Hero, recursos, funcionamento, abordagem responsável e CTA do Beta Fundadores.
- Termos de uso e política de privacidade iniciais, identificados como textos de beta sujeitos a revisão jurídica.
- Consentimento obrigatório no cadastro.

### Onboarding

- Fluxo protegido de três etapas.
- Escolha entre uso pessoal, igreja, criador e ministério.
- Seleção de objetivos: devocionais, posts, oração e leitura.
- Preferência entre ARC, ARA, NVI, NVT e NTLH.
- Geração e salvamento do primeiro devocional sobre esperança.
- Redirecionamento automático de contas incompletas para o onboarding.

### Perfil e configurações

- Persistência de perfil, objetivos e tradução bíblica no PostgreSQL.
- Página de configurações para editar nome, igreja/projeto, perfil, objetivos e tradução.
- Exclusão permanente de conta após confirmação de senha.
- Campos administrativos continuam inacessíveis pelo perfil público.

### Recuperação de senha

- Solicitação com resposta genérica para evitar enumeração de e-mails.
- Token aleatório de 256 bits.
- Armazenamento somente do hash SHA-256.
- Expiração em 30 minutos e uso único.
- Envio opcional via Resend.
- Link de teste devolvido apenas fora de produção quando o e-mail não está configurado.
- Redefinição incrementa a versão da sessão e revoga JWTs anteriores.

### Dashboard

- Saudação e data.
- Contadores de leitura, sequência e orações ativas.
- Devocional mais recente.
- Progresso do plano ativo.
- Pedidos de oração recentes.
- Quantidade de posts e devocionais.
- Atalhos para os quatro fluxos principais.

### Devocionais

- Resultado integralmente editável.
- Edição de título, referência, texto bíblico, reflexão, oração e aplicação.
- Salvamento no histórico.
- Cópia para a área de transferência.
- Download em `.txt`.
- Aviso de revisão bíblica, editorial e pastoral.

### Posts

- Preview de Feed, Story e WhatsApp.
- Paletas alinhadas ao design system.
- Edição de título interno, legenda, fundo e destaque.
- Salvamento no histórico.
- Cópia de versículo e legenda.
- Editor PNG/PDF explicitamente mantido para a próxima fase.

### Navegação

- Landing em `/`.
- Aplicativo autenticado em `/app`.
- Módulos em `/app/devocionais`, `/app/posts`, `/app/oracao` e `/app/leitura`.
- Configurações em `/app/configuracoes`.
- Redirecionamentos mantidos para rotas antigas.

## Banco e API

- Enum `ProfileType` adicionado.
- Campos `goals`, `bibleVersion`, `onboardingCompleted` e `sessionVersion` persistidos no usuário.
- Tabela `password_reset_tokens` criada.
- Segunda migração Prisma versionada.
- Endpoints de perfil, recuperação, redefinição e exclusão de conta adicionados.
- Endpoint de edição de devocional adicionado.
- Autorização agora valida usuário e versão de sessão em cada requisição protegida.

## Validação

| Verificação | Resultado |
|---|---|
| Backend lint | Aprovado |
| Backend typecheck | Aprovado |
| Backend testes | 13/13 aprovados |
| Backend build | Aprovado |
| Backend npm audit | 0 vulnerabilidades |
| Frontend lint | Aprovado |
| Frontend typecheck | Aprovado |
| Frontend build | Aprovado |
| Frontend npm audit | 0 vulnerabilidades |

## Limitações conscientes

- As traduções escolhidas são apenas preferências até a integração de uma fonte licenciada.
- O banco local contém resumos demonstrativos e não deve ser divulgado como tradução oficial.
- O envio real de recuperação depende de `RESEND_API_KEY`.
- JWT ainda fica em `localStorage`; a migração para cookies HttpOnly permanece recomendada.
- Docker e migrações ainda precisam de um teste em PostgreSQL real fora do sandbox.
- A interface ainda não exporta imagens em PNG/PDF.

## Próxima fase recomendada

**Fonte bíblica + IA responsável**, antes do editor visual:

1. Selecionar e configurar a fonte bíblica licenciada.
2. Mapear IDs das traduções suportadas.
3. Separar referência/texto bíblico da geração editorial.
4. Implementar adaptador de IA com saída validada por Zod.
5. Criar fallback e limites de geração.
6. Registrar versão do modelo, prompt e fonte bíblica em cada conteúdo.
7. Adicionar testes de contrato e falhas externas.

Depois disso, avançar para templates, identidade visual, PNG/PDF e Mercado Pago.
