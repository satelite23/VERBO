# Auditoria inicial — Verbo

> **Atualização:** os bloqueios técnicos desta auditoria foram tratados na primeira rodada de estabilização. Consulte `ESTABILIZACAO_TECNICA.md` para o resultado validado.

**Data:** 14 de julho de 2026  
**Base analisada:** React 18 + Vite + Tailwind / Express + Prisma + PostgreSQL

## Resumo executivo

O projeto recebido é uma base funcional de MVP, não apenas um protótipo visual. Frontend e backend compilam com sucesso e a separação de responsabilidades é clara. Os fluxos existentes cobrem cadastro, login, devocionais, posts, pedidos de oração e planos de leitura.

Ainda não está pronto para produção. Há bloqueios de banco, segurança, Docker e produto que devem ser corrigidos antes de conectar IA, API bíblica ou pagamentos.

## Validações executadas

| Verificação | Resultado |
|---|---|
| Download e extração | Aprovado |
| Estrutura do projeto | 84 entradas no pacote recebido |
| Instalação do backend | Aprovada |
| Build TypeScript do backend | Aprovado |
| Validação do schema Prisma | Aprovada |
| Geração do Prisma Client | Aprovada |
| Instalação do frontend | Aprovada |
| Build TypeScript/Vite do frontend | Aprovado |
| Auditoria npm do backend | 0 vulnerabilidades conhecidas |
| Auditoria npm do frontend | 1 moderada e 1 alta, relacionadas à versão do Vite/esbuild |
| Lint do backend | Não executa: ESLint não está instalado/configurado |
| Lint do frontend | Não executa: ESLint não está instalado/configurado |
| Testes automatizados | Não existem |
| Execução via Docker | Não validada no sandbox, que não possui Docker |

## O que já está implementado

### Backend

- Cadastro e login com JWT e bcrypt.
- Endpoint de usuário autenticado.
- Isolamento de devocionais, posts e orações por usuário.
- Geração local de devocionais por templates.
- Geração local de legendas por tema.
- Banco local de referências por tema para desenvolvimento.
- CRUD de devocionais, posts e pedidos de oração.
- Planos de leitura, matrícula e check-in diário.
- Validação com Zod.
- Helmet, CORS, rate limiting e tratamento central de erros.
- Schema PostgreSQL estruturado com Prisma.

### Frontend

- Cadastro e login.
- Proteção de rotas.
- Dashboard com atalhos.
- Geração e histórico de devocionais.
- Geração, preview e histórico de posts.
- Paletas e formatos Feed, Story e WhatsApp.
- Pedidos de oração e marcação como respondidos.
- Matrícula e progresso em planos de leitura.
- Navegação responsiva com menu móvel.
- Parte relevante da identidade Night/Parchment/Gold.

## Bloqueios críticos — prioridade P0

### 1. Não há migração Prisma versionada

O pacote contém `schema.prisma`, mas não contém `prisma/migrations`. O Docker executa `prisma migrate deploy`; sem migrações, um banco novo não recebe as tabelas necessárias.

**Correção:** criar e versionar a migração inicial antes de executar o ambiente completo.

### 2. IDs dos planos são incompatíveis com a API

O seed usa IDs como `plan-nt-90`, porém o endpoint de matrícula exige `z.string().uuid()`. Assim, os planos aparecem na tela, mas a matrícula pode ser rejeitada pela validação.

**Correção:** adotar UUIDs estáveis no seed ou remover a exigência de UUID. A recomendação é manter UUIDs.

### 3. Elevação de privilégio no cadastro

O backend aceita `role: CHURCH_ADMIN` na rota pública de cadastro. Mesmo que o frontend atual não envie esse campo, qualquer cliente HTTP pode enviá-lo.

**Correção:** toda conta pública deve nascer como `USER`. A promoção para administrador deve ocorrer por convite ou rota administrativa protegida.

### 4. Docker do frontend usa servidor de desenvolvimento

A imagem executa `vite --host` em vez de gerar arquivos estáticos e servi-los com um servidor de produção. Isso também expõe a versão vulnerável do Vite apontada pelo `npm audit`.

**Correção:** build multi-stage e entrega por Nginx/Caddy, além da atualização das dependências.

### 5. Integrações de IA e Bíblia são apenas stubs

Preencher `ANTHROPIC_API_KEY` ou `BIBLE_API_KEY` não ativa as integrações. As funções retornam `null` e o app continua usando templates e o JSON local.

**Correção:** implementar adaptadores reais, validação de saída e fallback explícito.

## Riscos altos — prioridade P1

- JWT armazenado em `localStorage`, exposto em caso de XSS; não há refresh token nem revogação de sessão.
- Senha mínima de seis caracteres e ausência de recuperação de senha.
- Ausência de verificação de e-mail.
- Rate limit genérico de 300 requisições também protege login, mas é permissivo contra força bruta.
- Segredo JWT de exemplo está escrito diretamente no `docker-compose.yml`.
- Não existem `.env.example`, apesar de o README instruir copiá-los.
- Não há limites de geração por usuário ou plano.
- Não há paginação no histórico.
- Não há trilha individual de dias concluídos no plano; existe apenas um contador agregado.
- Cálculo de sequência usa datas do servidor e precisa de regra explícita de fuso horário.
- O seed “Novo Testamento em 90 dias” não percorre todo o Novo Testamento; ele alterna apenas sete livros.
- O seed “4 Evangelhos em 30 dias” não cobre todos os capítulos dos quatro Evangelhos.
- Falhas nas chamadas iniciais de algumas páginas não são tratadas visualmente.
- Exclusões não pedem confirmação.

## Lacunas de produto em relação ao plano aprovado

### Essenciais para o MVP

- Landing page pública.
- Onboarding por perfil e objetivo.
- Escolha e persistência da tradução bíblica.
- Entrada por tema, sentimento ou referência.
- Sugestões de texto antes de salvar.
- Edição de devocionais e posts no frontend.
- Copiar e baixar conteúdo.
- Biblioteca bíblica verificada/licenciada.
- Exibição da leitura bíblica do dia.
- Configurações de perfil e conta.
- Recuperação de senha.
- Termos de uso, privacidade e exclusão de conta.

### Fluxo visual de posts

- Galeria real de templates.
- Imagem de fundo e upload de logotipo.
- Identidade visual da igreja.
- Editor visual de texto, fonte, alinhamento e cores.
- Exportação PNG/PDF.
- Marca-d’água no plano gratuito.
- Armazenamento dos arquivos exportados.

### Comercial

- Planos Gratuito, Pro e Igreja.
- Contadores e bloqueios por plano.
- Mercado Pago e webhooks.
- Tela de upgrade, pausa e cancelamento.
- Assinatura anual.

## Decisão recomendada

Manter esta base de React/Vite + Express/Prisma, conforme solicitado. Não misturar o projeto com a base Next.js/Supabase iniciada anteriormente.

A ordem de execução deve ser:

1. **Estabilização:** migrações, seed, segurança do cadastro, ambientes, lint, testes e Docker de produção.
2. **Experiência principal:** onboarding, perfil, tradução bíblica, devocionais editáveis e histórico.
3. **Fonte bíblica e IA:** adaptadores reais e validação teológica/editorial.
4. **Editor visual:** templates, identidade, preview e exportação.
5. **Monetização:** limites, planos, Mercado Pago e webhooks.
6. **Lançamento:** analytics, e-mails, LGPD, QA e deploy.

## Critério para avançar à IA e pagamentos

A próxima fase só deve começar quando:

- Banco novo puder ser criado pelas migrações versionadas.
- Cadastro, login e autorização estiverem testados.
- Seed dos planos estiver correto.
- Frontend e backend passarem em build e lint.
- Docker usar configuração de produção.
- Houver ao menos testes de integração para autenticação e isolamento por usuário.
