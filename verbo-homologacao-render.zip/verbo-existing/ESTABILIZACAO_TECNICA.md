# Estabilização técnica — Verbo

> **Atualização:** a fase seguinte de experiência principal também foi concluída. Consulte `EXPERIENCIA_PRINCIPAL.md`.

**Data:** 14 de julho de 2026  
**Base:** React/Vite + Express/Prisma/PostgreSQL

## Resultado

A primeira rodada de estabilização foi concluída. Frontend e backend passam em lint, verificação de tipos e build. O backend possui 11 testes automatizados aprovados e as duas auditorias de dependências retornam zero vulnerabilidades conhecidas.

## Correções realizadas

### Banco de dados

- Criada e versionada a migração Prisma inicial.
- Adicionado histórico individual de check-ins de leitura.
- Adicionado contador real de dias concluídos.
- Adicionados `updatedAt` e `answeredAt` onde necessário.
- Melhorados índices por usuário e data.
- Schema Prisma formatado, validado e Prisma Client regenerado.

### Planos de leitura

- IDs demonstrativos foram substituídos por UUIDs estáveis.
- “Novo Testamento em 90 dias” agora distribui os 260 capítulos em ordem bíblica.
- “Os 4 Evangelhos em 30 dias” agora distribui os 89 capítulos em ordem.
- Seed tornou-se idempotente e atualiza os dias dos planos padrão.
- A API registra cada dia concluído e impede mais de um check-in na mesma data local.
- Sequência diária calculada no fuso `America/Sao_Paulo`.
- Frontend passou a mostrar a referência da leitura do dia e progresso por leituras concluídas.

### Cadastro e autenticação

- Removida a possibilidade de solicitar `CHURCH_ADMIN` no cadastro público.
- Toda conta pública nasce como `USER`.
- E-mails são normalizados para minúsculas.
- Senha mínima aumentada de 6 para 8 caracteres.
- Custo do bcrypt aumentado para 12.
- Comparação de senha também ocorre quando o e-mail não existe, reduzindo diferença de tempo.
- JWT limitado a HS256, com emissor e público definidos.
- Produção rejeita `JWT_SECRET` com menos de 32 caracteres.
- Rate limit específico aplicado a login e cadastro.

### Validação e API

- Limites de tamanho adicionados a nome, e-mail, tema, conteúdo e pedidos.
- Cores de post validadas no formato hexadecimal.
- Identificadores de template validados.
- Filtros de mês e ano de oração validados.
- Marcação de oração respondida agora registra `answeredAt`.
- Temas com acentos são normalizados na busca bíblica local.
- CORS aceita apenas origens configuradas.
- Corpo JSON reduzido a 1 MB.
- `X-Powered-By` desativado.
- Encerramento gracioso adicionado para SIGINT e SIGTERM.

### Frontend

- Chamadas iniciais agora tratam erros e desmontagem de componentes.
- Exclusões pedem confirmação e tratam falhas.
- Sessão local corrompida é limpa sem quebrar o aplicativo.
- Contexto de autenticação separado do provider para Fast Refresh limpo.
- Paleta alinhada aos tokens oficiais Night, Parchment, Gold, Sage e Rose.
- Vite atualizado para 8.1.4.
- Dependências vulneráveis do ambiente anterior removidas.

### Docker e ambientes

- Criados `.env.example` na raiz, no backend e no frontend.
- Segredos removidos dos valores fixos do Compose.
- Docker Compose exige senha do PostgreSQL e segredo JWT.
- Frontend ganhou build multi-stage e Nginx de produção.
- O servidor de desenvolvimento do Vite não é mais exposto no contêiner.
- Nginx configurado para SPA, cache de arquivos e proxy `/api`.
- Healthchecks adicionados ao frontend e backend.
- Migração e seed executados na inicialização do backend em Docker.
- `.dockerignore` e `.gitignore` adicionados.

### Qualidade

- ESLint moderno instalado e configurado nos dois projetos.
- Scripts `lint` e `typecheck` funcionais.
- Vitest e Supertest adicionados ao backend.
- Testes cobrem calendário, seed, UUIDs, cadastro, privilégios, senha, JWT e isolamento por usuário.
- README reescrito conforme a estrutura real.

## Validação final

| Verificação | Resultado |
|---|---|
| Prisma schema validate | Aprovado |
| Migração inicial gerada | Aprovado — 173 linhas SQL |
| Backend lint | Aprovado — sem erros ou avisos |
| Backend typecheck | Aprovado |
| Backend testes | 11/11 aprovados |
| Backend build | Aprovado |
| Backend npm audit | 0 vulnerabilidades |
| Frontend lint | Aprovado — sem erros ou avisos |
| Frontend typecheck | Aprovado |
| Frontend build | Aprovado — Vite 8.1.4 |
| Frontend npm audit | 0 vulnerabilidades |
| Docker Compose YAML | Estrutura validada |

## Limitações desta validação

O sandbox não possui o executável Docker nem uma instância PostgreSQL ativa. Portanto:

- As imagens Docker foram revisadas estruturalmente, mas não construídas no sandbox.
- A migração foi gerada e validada pelo Prisma, mas não aplicada a um PostgreSQL real nesta sessão.
- O teste final `docker compose up --build` deve ser executado em uma máquina com Docker antes da publicação.

## Riscos conhecidos mantidos para fases posteriores

- JWT ainda fica em `localStorage`; migrar para cookies HttpOnly antes de escala pública.
- Não há recuperação de senha nem verificação de e-mail.
- API bíblica licenciada ainda não está integrada.
- Chamada real de IA ainda não está implementada.
- Não há cobrança, planos comerciais nem Mercado Pago.
- Não há editor visual nem exportação PNG/PDF.
- Não há testes de interface no frontend.

## Próxima fase recomendada

**Experiência principal e onboarding:**

1. Landing page pública.
2. Onboarding por perfil e objetivo.
3. Escolha da tradução bíblica.
4. Perfil e configurações.
5. Recuperação de senha.
6. Devocionais editáveis, copiáveis e exportáveis em texto.
7. Dashboard de hábito com leitura, oração e atividade recente.

A integração de IA e Bíblia deve vir depois que essa experiência estiver navegável e testada de ponta a ponta.
